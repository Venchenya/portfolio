#!/usr/bin/env node
// 一键启动器（面向非技术演示者）
//
// 为什么需要它：项目本身 `npm start` 就能跑，但看项目的人（HR、面试官）
// 通常不装 Node、不会配 .env、也不清楚端口被占用怎么办。这个脚本把四件事做完：
//   1) 检查 Node 版本与运行环境
//   2) 没有 API Key 也能跑（自动进入本地演示引擎，无需任何配置）
//   3) 端口被占用自动顺延
//   4) 服务就绪后自动打开浏览器，并打印演示账号
//
// 用法：node start-demo.mjs        （或双击 启动演示.bat / Start-Demo.command）
//       node start-demo.mjs --reset   重置演示数据（旧库备份到 data/backup/）

import { spawn } from 'node:child_process';
import { existsSync, readFileSync, mkdirSync, renameSync, statSync } from 'node:fs';
import net from 'node:net';
import http from 'node:http';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = path.dirname(fileURLToPath(import.meta.url));
process.chdir(ROOT);

const ARGS = new Set(process.argv.slice(2));
const RESET = ARGS.has('--reset');
const NO_OPEN = ARGS.has('--no-browser') || process.env.NO_OPEN === '1';

/* ---------------- 终端输出 ---------------- */
const TTY = process.stdout.isTTY && !process.env.NO_COLOR;
const paint = (code) => (s) => (TTY ? `\x1b[${code}m${s}\x1b[0m` : String(s));
const bold = paint('1');
const dim = paint('2');
const cyan = paint('36');
const green = paint('32');
const yellow = paint('33');
const red = paint('31');

const out = (s = '') => console.log(s);
const step = (n, t) => out(`\n${cyan(`[${n}/4]`)} ${bold(t)}`);
const ok = (k, v) => out(`      ${k} ${dim('·')} ${green(v)}`);
const warn = (k, v) => out(`      ${k} ${dim('·')} ${yellow(v)}`);
const bad = (k, v) => out(`      ${k} ${dim('·')} ${red(v)}`);

function banner() {
  out('');
  out(dim('  ────────────────────────────────────────────────'));
  out(`  ${bold('星禾数智 · AI 辅助招聘平台')}  ${dim('本地演示版 v2.0')}`);
  out(dim('  ────────────────────────────────────────────────'));
}

function die(msg, hints = []) {
  out('');
  out(red('  ✕ ' + msg));
  for (const h of hints) out(dim('    ' + h));
  out('');
  process.exit(1);
}

/* ---------------- 1. 环境检查 ---------------- */
function checkNode() {
  const [maj, min] = process.versions.node.split('.').map(Number);
  const okVersion = maj > 22 || (maj === 22 && min >= 5);
  if (!okVersion) {
    die(`Node.js 版本过低（当前 v${process.versions.node}）`, [
      '本项目使用 Node 22 内置的 node:sqlite，需要 22.5 或更高版本。',
      '下载：https://nodejs.org/  （选 LTS 即可，安装后重新双击启动）',
    ]);
  }
  // 22.5 ~ 22.12 的 node:sqlite 需要实验开关；22.13+ 已默认开启
  const needFlag = maj === 22 && min < 13;
  ok('Node.js', `v${process.versions.node}${needFlag ? '（加 --experimental-sqlite）' : ''}`);
  return needFlag ? ['--experimental-sqlite'] : [];
}

function readEnvFile() {
  if (!existsSync('.env')) return {};
  const env = {};
  for (const line of readFileSync('.env', 'utf8').split(/\r?\n/)) {
    if (!line || line.trim().startsWith('#')) continue;
    const i = line.indexOf('=');
    if (i > 0) env[line.slice(0, i).trim()] = line.slice(i + 1).trim();
  }
  return env;
}

function backupDb() {
  const dir = path.join(ROOT, 'data');
  const dbFile = path.join(dir, 'app.db');
  if (!existsSync(dbFile)) return;
  const backupDir = path.join(dir, 'backup');
  mkdirSync(backupDir, { recursive: true });
  const stamp = new Date().toISOString().replace(/[-:T]/g, '').slice(0, 14);
  for (const [i, suffix] of ['', '-shm', '-wal'].entries()) {
    const src = dbFile + suffix;
    if (existsSync(src)) renameSync(src, path.join(backupDir, `app-${stamp}.db${i === 0 ? '' : suffix}`));
  }
  ok('演示数据', `已重置，旧库备份到 data/backup/app-${stamp}.db`);
}

function checkData() {
  const dbFile = path.join(ROOT, 'data', 'app.db');
  if (RESET) return backupDb();
  if (!existsSync(dbFile)) {
    ok('数据文件', '首次运行，将自动建库并写入演示数据');
    return;
  }
  const kb = Math.round(statSync(dbFile).size / 1024);
  ok('数据文件', `已有数据库 data/app.db（${kb} KB），沿用现有数据`);
}

function checkAI() {
  const env = readEnvFile();
  const configured = !!(env.LLM_API_KEY && env.LLM_BASE_URL && env.LLM_MODEL);
  if (configured) {
    ok('大模型', `${env.LLM_MODEL} 已配置（密钥不显示）`);
  } else {
    warn('大模型', '未配置 .env → 使用本地演示引擎，无需 API Key');
    out(dim('                  结果会标注「演示引擎」，只做字面匹配并引用简历原文'));
  }
}

/* ---------------- 2. 选端口 ---------------- */
function canListen(port) {
  return new Promise((resolve) => {
    const srv = net.createServer();
    srv.once('error', () => resolve(false));
    srv.once('listening', () => srv.close(() => resolve(true)));
    srv.listen(port, '127.0.0.1');
  });
}

async function pickPort() {
  for (const port of [3000, 3100, 3200, 3300, 3400]) {
    if (await canListen(port)) {
      ok('端口', String(port));
      return port;
    }
    warn('端口', `${port} 已被占用，顺延`);
  }
  die('3000–3400 端口均被占用', ['请关闭占用端口的程序后重试']);
}

/* ---------------- 3. 启动服务 ---------------- */
function healthOk(port, timeout = 800) {
  return new Promise((resolve) => {
    const req = http.get({ host: '127.0.0.1', port, path: '/health', timeout }, (res) => {
      let body = '';
      res.on('data', (c) => (body += c));
      res.on('end', () => {
        try {
          resolve(JSON.parse(body).ok === true);
        } catch {
          resolve(false);
        }
      });
    });
    req.on('error', () => resolve(false));
    req.on('timeout', () => {
      req.destroy();
      resolve(false);
    });
  });
}

function openBrowser(url) {
  if (NO_OPEN) return;
  const cmd =
    process.platform === 'win32'
      ? ['cmd', ['/c', 'start', '', url]]
      : process.platform === 'darwin'
        ? ['open', [url]]
        : ['xdg-open', [url]];
  try {
    const child = spawn(cmd[0], cmd[1], { detached: true, stdio: 'ignore' });
    child.on('error', () => out(dim('      （自动打开失败，请手动复制上面的地址）')));
    child.unref();
  } catch {
    out(dim('      （自动打开失败，请手动复制上面的地址）'));
  }
}

function accounts(mode) {
  out('');
  out(dim('  演示账号（密码均为 Passw0rd!）'));
  out(`    ${bold('liqiang')}    用人经理    岗位需求 / 推荐反馈`);
  out(`    ${bold('wangmin')}    招聘专员    上传简历 / 核对推荐 / 结果登记`);
  out(`    ${bold('zhangwei')}   招聘经理    分配 / 看板 / 提醒 / 留痕`);
  out(`    ${bold('admin')}      系统管理员  账号 / 数据治理 / 系统参数`);
  out('');
  if (mode === 'demo') {
    out(yellow('  当前是演示模式：未接大模型，AI 对照由本地规则生成（结果标注「演示引擎」）。'));
    out(dim('  想切到真实模型：把 .env.example 复制为 .env，填入 LLM_API_KEY 后重新启动。'));
  } else {
    out(green('  当前已接入大模型，AI 对照为真实调用结果。'));
  }
  out('');
  out(dim('  提示：关闭本窗口（或按 Ctrl+C）即停止服务。'));
  out('');
}

/* ---------------- main ---------------- */
banner();

out('');
out(bold('  环境检查'));
const nodeFlags = checkNode();
checkData();
checkAI();

step(2, '选择端口');
const port = await pickPort();
const url = `http://localhost:${port}`;

step(3, '启动服务');
out(`      ${dim('地址')} ${cyan(url)}`);

const child = spawn(process.execPath, [...nodeFlags, 'server/app.mjs'], {
  cwd: ROOT,
  stdio: ['ignore', 'pipe', 'pipe'],
  env: { ...process.env, PORT: String(port) },
});

let ready = false;
let serverLog = '';
const forward = (buf) => {
  const s = buf.toString();
  serverLog += s;
  if (!ready) return; // 就绪前的启动日志不刷屏，出错时再回放
  process.stdout.write(s);
};
child.stdout.on('data', forward);
child.stderr.on('data', forward);

child.on('exit', (code) => {
  if (!ready) {
    out('');
    out(red(`  ✕ 服务启动失败（退出码 ${code}）`));
    if (serverLog.trim()) {
      out(dim('  ---- 服务输出 ----'));
      out(serverLog.trim().split(/\r?\n/).slice(-12).join('\n'));
    }
    out('');
    process.exit(code || 1);
  }
  out('');
  out(dim('  服务已停止。'));
  process.exit(0);
});

const startedAt = Date.now();
let tries = 0;
const timer = setInterval(async () => {
  tries += 1;
  if (await healthOk(port)) {
    clearInterval(timer);
    ready = true;
    const secs = ((Date.now() - startedAt) / 1000).toFixed(1);
    step(4, `打开浏览器（服务就绪 ${secs}s）`);
    openBrowser(url);
    out(`      ${green('✓')} 若浏览器没有自动打开，手动访问 ${cyan(url)}`);
    accounts(readEnvFile().LLM_API_KEY ? 'llm' : 'demo');
    return;
  }
  if (tries > 50) {
    clearInterval(timer);
    out('');
    out(red('  ✕ 服务 15 秒内未就绪，可能是端口被代理拦截或启动异常。'));
    out(dim('    可手动执行：node server/app.mjs 查看详细报错'));
    out('');
    try { child.kill(); } catch { /* ignore */ }
    process.exit(1);
  }
}, 300);

for (const sig of ['SIGINT', 'SIGTERM']) {
  process.on(sig, () => {
    try { child.kill(); } catch { /* ignore */ }
  });
}
