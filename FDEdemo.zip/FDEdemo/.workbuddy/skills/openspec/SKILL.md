---
name: openspec
description: 用 OpenSpec（规范驱动开发）管理本项目的变更提案。当用户说「openspec」「提个提案」「写个 spec/规范」「按 OpenSpec 流程做」「opsx」「变更提案」「归档变更」时使用。负责调用已安装的 openspec CLI，在 openspec/changes 下创建提案、规范、设计、任务，并做状态查询与校验。
license: MIT
metadata:
  workspace: D:\FDE训练营
  openspec_cli: openspec
  initialized: 2026-10-24
---

# OpenSpec 工作流（本项目已初始化）

本项目根目录 `D:\FDE训练营` 已执行 `openspec init`（v1.15.0，schema: spec-driven，产物语言 zh-CN）。
OpenSpec 目录：`openspec/`（`specs/` 主规范、`changes/` 变更提案、`config.yaml` 配置）；通用技能在 `.agents/skills/`。

## 定位判断（先做，不可跳过）

1. 运行 `openspec context --json`，读 `root.path` 是否为 `D:\FDE训练营`。
2. `"root": null` → 说明未初始化，**不要**自动 init，先问用户。
3. 若报 `Declared in ...` / `Invalid store declaration` → 是 store 解析问题，把错误与修复建议原样告诉用户，不要当未初始化处理。

## 常用命令（CLI 已在 PATH）

| 目的 | 命令 |
| --- | --- |
| 版本 | `openspec --version` |
| 健康检查 | `openspec doctor` |
| 工作上下文 | `openspec context --json` |
| 列出变更/规范 | `openspec list` / `openspec list --specs` |
| 新建变更目录 | `openspec new change <kebab-name>` |
| 产物完成度 | `openspec status --change <name>` |
| 取产物写作指引 | `openspec instructions <proposal\|specs\|design\|tasks\|apply\|archive> --change <name> --json` |
| 校验 | `openspec validate <name>` / `--all` / `--strict` |
| 查看 | `openspec show <name>` |
| 归档 | `openspec archive <name>`（会更新主 specs） |

若 `openspec` 不在 PATH：`C:\Users\szpu\.workbuddy\binaries\node\versions\22.22.2-6\openspec.cmd`。

## 变更产物的标准结构

```
openspec/changes/<change-name>/
├── proposal.md                     ## Why / ## What Changes / ## Impact
├── specs/<capability-path>/spec.md ## ADDED Requirements + ### Requirement: + #### Scenario:
├── design.md                       （可选，技术方案）
└── tasks.md                        ## 1. 分组 + - [ ] 1.1 任务
```

硬性校验规则（`openspec validate` 会报错）：
- 至少一个 delta；位于 `specs/<capability>/spec.md`，用 `## ADDED Requirements`（或 MODIFIED/REMOVED/RENAMED）开头；
- 每条 `### Requirement:` 至少一个 `#### Scenario:`（WHEN/THEN）；
- 纯文档/工具类变更无规范改动时，在 `.openspec.yaml` 设 `skip_specs: true`。

## 工作流映射

| 用户意图 | 动作 |
| --- | --- |
| 先想清楚（explore） | 读代码与 `openspec/specs`，与用户讨论方案，**不写文件** |
| 提提案（propose） | `openspec new change <name>` → 按结构写 proposal / specs / design / tasks → `openspec status` → `openspec validate` |
| 实施（apply） | 先 `openspec status` 与 `openspec instructions apply --change <name>`，再按 tasks 逐项执行并勾选 |
| 验证（verify） | `openspec validate <name> --strict`；核对实现与规范场景是否一致 |
| 归档（archive） | 确认任务全完成 → `openspec archive <name>` |

规划边界：propose 阶段**只产出规划文件，不改项目代码**；实施需用户再明确要求。

## 本项目约束

- 产物语言：简体中文（`openspec/config.yaml` 已设），结构标题与 SHALL/MUST 保留英文。
- 既有交付物（BRD/PRD/原型 HTML/归档目录）**不得**被 OpenSpec 流程改动。
- 一次变更只解决一件事；跨需求请拆多个 change。
- 校验通过前不要 `archive`；归档会写入主规范，属于不可逆动作，执行前先向用户确认。
