# AI 质量评测（OpenJudge）

对本项目的 AI 简历分析能力做自动化评测。评测链路：

```
人工标注样本 → 调真实接口 → OpenJudge 打分 → 报告
```

## 装了什么

| 组件 | 版本/位置 | 说明 |
|---|---|---|
| `py-openjudge` | 0.2.4 | PyPI 官方包，装在隔离 venv `.workbuddy/tmp/ojvenv` |
| `openjudge` 技能 | `~/.workbuddy/skills/openjudge` | 官方 `skills/openjudge-core/01-graders-and-pipeline` |
| `openjudge-eval` 技能 | `~/.workbuddy/skills/openjudge-eval` | 官方 `skills/eval_pipeline` 全 9 个子工作流 |

技能来源：<https://github.com/agentscope-ai/OpenJudge>（commit `c2fdc38`）。

> 官方文档写「Python >=3.10 且 <3.13」，但 PyPI 上 0.2.4 的 `requires_python` 只有 `>=3.10`，
> 实测 Python 3.13.14 全流程可用，`python-Levenshtein`、`scikit-learn` 都有 Windows wheel。

## 快速开始

```bash
# 1) 生成人工标注的评测集（27 条）
python eval/build_dataset.py

# 2) 调真实应用接口，产出逐题输入输出
.workbuddy/tmp/ojvenv/Scripts/python.exe eval/target_client.py \
  --out eval/runs/run-YYYYMMDD-NN/outputs.jsonl

# 3) OpenJudge 打分（自动从 .env 读取裁判模型配置）
.workbuddy/tmp/ojvenv/Scripts/python.exe eval/run_eval.py \
  --outputs eval/runs/run-YYYYMMDD-NN/outputs.jsonl \
  --results eval/runs/run-YYYYMMDD-NN/results.jsonl \
  --summary eval/runs/run-YYYYMMDD-NN/summary.json

# 4) 生成 HTML 报告
python eval/report.py
```

## 文件说明

| 文件 | 作用 |
|---|---|
| `build_dataset.py` | 27 条样本 + 人工标注（每条四个条件的期望结论）。**标签全部手写，不用 LLM 生成** |
| `dataset.jsonl` | 生成的数据集，供 `coverage_check.py` 与评测共用 |
| `target_client.py` | 登录 → `POST /upload` → 解析 `/check/:id`，走真实业务链路 |
| `graders.py` | 4 个函数 grader + 2 个裁判 grader |
| `run_eval.py` | 两轮评测（样本级 + 条目级）与汇总 |
| `report.py` | 渲染单文件 HTML 报告 |
| `runs/<id>/` | 每批次的 `outputs.jsonl` / `results.jsonl` / `summary.json` / `report.html` |

## 评分标准

| Grader | 类型 | 判什么 | 通过阈值 |
|---|---|---|---|
| `conclusion_accuracy` | 函数 | 结论与人工标注的一致率（disputed 条目不计入分母） | ≥ 0.75 |
| `quote_grounding` | 函数 | **硬门禁**：非「信息不足」结论必须有可定位引用 | = 1.00 |
| `no_rejection_language` | 函数 | **硬门禁**：「待核实」中不得出现淘汰建议 | = 1.00 |
| `score_calibration` | 函数 | 参考分落在人工区间 | ≥ 0.50 |
| `evidence_supports` | 裁判 | 逐条判断「引用是否真的支持结论」 | ≥ 0.75 |
| `faithfulness` | 裁判 | 整份输出是否忠实、无编造 | ≥ 0.70 |

硬门禁不通过直接判 `fail`，不允许被平均分掩盖。

### 为什么「确定性优先」

引用可定位、是否出现淘汰词、分数是否落在区间，这些都能用规则判定，用大模型只会引入噪音。
只有「引用是否支持结论」需要语义理解，才交给裁判。

## 裁判模型

配置在 `.env`：

```
JUDGE_BASE_URL=https://api.deepseek.com
JUDGE_MODEL=deepseek-v4-pro      # 裁判
LLM_MODEL=deepseek-flash         # 被测（业务模型）
LLM_API_KEY=sk-...               # JUDGE_API_KEY 缺省时复用这个
```

**裁判 ≠ 被评**是硬规则：同一模型自评会显著抬高通过率。P13 系统参数页会显示是否已分离。

### 已知适配

DeepSeek 只支持 `response_format={"type":"json_object"}`，不接受 OpenJudge 默认下发的
`json_schema`（会 400 `This response_format type is unavailable now`）。
`graders.py:build_judge_model` 在实例级把 `parse` 换成 `create + json_object`，
OpenJudge 自身的「按 content 解析 JSON」fallback 会接管后续处理。

## 覆盖情况

```
python ~/.workbuddy/skills/openjudge-eval/01-eval-design/scripts/coverage_check.py \
  --dataset eval/dataset.jsonl
```

当前判定 `thin_coverage`：五个维度各有 5~7 条（达到「可测量」下限），
但「维度 × 难度」每格不足 10 条，**按切片报出的数字只能当方向性信号**。

## 不在本评测范围内

见报告第七节。简要说：裁判本身未经人工校准（无 TPR/TNR）、单次运行无重复采样、
未做提示词回归 A/B、未覆盖 PDF 解析与长文本场景。
