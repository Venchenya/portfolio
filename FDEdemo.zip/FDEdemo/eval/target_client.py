# -*- coding: utf-8 -*-
"""调用真实应用接口，产出逐题输入/输出。

走的是产品真实链路：登录 → POST /upload（multipart）→ 302 到 /check/:id → 解析页面。
不直接读数据库，避免「评测绕过界面」导致结论失真。
"""
import json
import re
import sys
import time
import urllib.parse

import requests
from lxml import html as LH

CONCL = ("匹配", "信息不足", "不符合")
EMPTY_QUOTE_HINT = "简历未在相应位置体现"


class Target:
    def __init__(self, base, login, password):
        self.base = base.rstrip("/")
        self.s = requests.Session()
        # 本机代理会劫持 127.0.0.1 请求，必须绕过
        self.s.trust_env = False
        self.login = login
        self.password = password

    def signin(self):
        r = self.s.post(
            f"{self.base}/login",
            data={"login": self.login, "password": self.password},
            allow_redirects=False,
            timeout=20,
        )
        if r.status_code not in (302, 303):
            raise RuntimeError(f"登录失败 status={r.status_code} body={r.text[:200]}")
        if not self.s.cookies:
            raise RuntimeError("登录成功但未拿到会话 Cookie")
        return True

    def upload(self, job_id, name, text):
        """真实上传接口：multipart，等同用户在页面上粘贴简历后点提交。"""
        files = {"file": ("", b"", "application/octet-stream")}  # 空文件，走 textarea 路径
        data = {"jobId": str(job_id), "name": name, "text": text, "go": "1"}
        r = self.s.post(
            f"{self.base}/upload",
            data=data,
            files=files,
            allow_redirects=False,
            timeout=120,
        )
        loc = r.headers.get("location", "")
        if r.status_code not in (302, 303):
            raise RuntimeError(f"上传失败 status={r.status_code} body={r.text[:300]}")
        m = re.search(r"/check/(\d+)", loc)
        if not m:
            # 被业务规则拒绝时也会 302 回 /upload?err=...
            q = urllib.parse.parse_qs(urllib.parse.urlparse(loc).query)
            reason = (q.get("err") or q.get("msg") or [""])[0]
            raise RuntimeError(f"未生成核对记录：{urllib.parse.unquote_plus(reason) or loc}")
        return int(m.group(1)), urllib.parse.unquote_plus(loc)

    def check(self, app_id):
        """抓取核对详情页，解析出结构化分析结果。"""
        r = self.s.get(f"{self.base}/check/{app_id}", timeout=30)
        r.raise_for_status()
        return parse_check_page(r.text, app_id)


def parse_check_page(page, app_id):
    doc = LH.fromstring(page)
    out = {"app_id": app_id, "items": [], "score": None, "weight_sum": None, "status": None}

    # 分析状态：AI 逐项对照标题后的 pill（ok / degraded / 无）
    for h3 in doc.xpath("//h3"):
        if "AI 逐项对照" in (h3.text_content() or ""):
            row = h3.getparent()
            for p in row.xpath(".//span[contains(@class, 'pill')]"):
                t = (p.text_content() or "").strip()
                if t in ("ok", "degraded", "无"):
                    out["status"] = t
            for sub in row.xpath(".//span[contains(@class, 'sub')]"):
                txt = sub.text_content() or ""
                m = re.search(r"参考分\s*(\d+|—)", txt)
                if m:
                    v = m.group(1)
                    out["score"] = None if v == "—" else int(v)
                m2 = re.search(r"权重合计\s*(\d+)", txt)
                if m2:
                    out["weight_sum"] = int(m2.group(1))
            break

    for q in doc.xpath("//div[@class='quote']"):
        block = q.getparent()
        conclusion = None
        for p in block.xpath(".//span[contains(@class, 'pill')]"):
            t = (p.text_content() or "").strip()
            if t in CONCL:
                conclusion = t
                break
        cond = ""
        bs = block.xpath(".//b")
        if bs:
            cond = (bs[0].text_content() or "").strip()
        weight = None
        typ = None
        for p in block.xpath(".//span[contains(@class, 'pill')]"):
            t = (p.text_content() or "").strip()
            m = re.search(r"(必备|加分)\s*·\s*权重\s*(\d+)", t)
            if m:
                typ, weight = m.group(1), int(m.group(2))
        quote = (q.text_content() or "").strip()
        if EMPTY_QUOTE_HINT in quote:
            quote = ""
        to_verify = ""
        subs = block.xpath(".//div[contains(@class, 'sub')]")
        if subs:
            to_verify = (subs[0].text_content() or "").replace("待核实：", "").strip()
        out["items"].append({
            "cond": cond, "type": typ, "weight": weight,
            "conclusion": conclusion, "quote": quote, "to_verify": to_verify,
        })
    return out


def main():
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--base", default="http://127.0.0.1:3000")
    ap.add_argument("--dataset", default="eval/dataset.jsonl")
    ap.add_argument("--out", required=True)
    ap.add_argument("--job", type=int, default=1)
    ap.add_argument("--only", default="", help="逗号分隔的用例 id，便于单条调试")
    args = ap.parse_args()

    rows = [json.loads(l) for l in open(args.dataset, encoding="utf-8") if l.strip()]
    if args.only:
        keep = {x.strip() for x in args.only.split(",") if x.strip()}
        rows = [r for r in rows if r["id"] in keep]

    t = Target(args.base, "wangmin", "Passw0rd!")
    t.signin()
    print(f"已登录 {args.base}，开始 {len(rows)} 条真实调用", flush=True)

    out = []
    for i, r in enumerate(rows, 1):
        rec = {"id": r["id"], "stratum": r["stratum"], "dimension": r["dimension"],
               "difficulty": r["difficulty"], "name": r["name"], "resume": r["resume"],
               "job_items": r["job_items"], "expected_conclusions": r["expected_conclusions"],
               "expected_score": r["expected_score"], "score_range": r["score_range"],
               "disputed": r["disputed"], "label_note": r["label_note"]}
        started = time.time()
        try:
            app_id, loc = t.upload(args.job, r["name"], r["resume"])
            parsed = t.check(app_id)
            rec.update({"ok": True, "app_id": app_id, "redirect": loc,
                        "elapsed_s": round(time.time() - started, 2), **parsed})
            got = [x["conclusion"] for x in parsed["items"]]
            mark = "OK " if got == r["expected_conclusions"] else "DIFF"
            print(f"[{i}/{len(rows)}] {r['id']:4s} {mark} 分={parsed['score']} 期望={r['expected_score']} "
                  f"{got} 用时{rec['elapsed_s']}s", flush=True)
        except Exception as e:
            rec.update({"ok": False, "error": f"{type(e).__name__}: {e}",
                        "elapsed_s": round(time.time() - started, 2)})
            print(f"[{i}/{len(rows)}] {r['id']:4s} ERROR {e}", flush=True)
        out.append(rec)

    with open(args.out, "w", encoding="utf-8", newline="\n") as f:
        for rec in out:
            f.write(json.dumps(rec, ensure_ascii=False) + "\n")
    okn = sum(1 for x in out if x.get("ok"))
    print(f"\n完成：{okn}/{len(out)} 条成功，写入 {args.out}")


if __name__ == "__main__":
    sys.exit(main())
