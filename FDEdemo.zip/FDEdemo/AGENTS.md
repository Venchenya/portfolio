# 项目约定（AGENTS.md）

本文件供 AI 编码助手（WorkBuddy 等）阅读。项目根目录：`D:\FDE训练营`。

## OpenSpec：规范驱动开发

本项目已初始化 OpenSpec（`schema: spec-driven`，产物语言 zh-CN）。

- 主规范：`openspec/specs/`
- 变更提案：`openspec/changes/`
- 配置：`openspec/config.yaml`
- 通用技能：`.agents/skills/openspec-*`（explore / propose / apply / update / archive / sync-specs）
- WorkBuddy 侧入口：`.workbuddy/skills/openspec/SKILL.md`

### 何时使用

用户提出「要改什么、加什么功能」时，先产出 OpenSpec 变更提案再动代码：

1. `openspec context --json` 确认根目录
2. `openspec new change <kebab-name>`
3. 写 `proposal.md`、`specs/<capability>/spec.md`、`design.md`、`tasks.md`
4. `openspec status --change <name>` → `openspec validate <name>`
5. 实施后 `openspec archive <name>`（先向用户确认）

### 规则

- 规划阶段只写规划文件，不改业务代码。
- 每条 Requirement 至少一个 Scenario。
- 产物用简体中文，`SHALL/MUST` 与结构标题保留英文。
- 不要修改既有交付物：`业务需求文档_总册_v2.0.*`、`第五组-产品需求文档_PRD_v2.0.*`、`AI辅助招聘平台_原型_v2.0.html`、`归档_v1.0/`。

## 本项目当前交付物（v2.0）

| 文件 | 说明 |
| --- | --- |
| `业务需求文档_总册_v2.0.docx/.md` | BRD 总册，四角色 + 分级授权 |
| `第五组-产品需求文档_PRD_v2.0.docx/.md` | PRD 14 章 |
| `AI辅助招聘平台_原型_v2.0.html` | 单文件可交互原型 |
