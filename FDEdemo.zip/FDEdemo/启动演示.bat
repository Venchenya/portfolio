@echo off
rem ============================================================
rem  One-click launcher (Windows). No npm install, no API Key needed.
rem  All user-facing messages are printed by Node (UTF-8) so this
rem  file stays pure ASCII - cmd.exe mangles non-ASCII batch files.
rem ============================================================
chcp 65001 >nul
setlocal
cd /d "%~dp0"
title AI Recruitment Platform - Local Demo

set "NODE_EXE="
where node >nul 2>nul
if %errorlevel%==0 set "NODE_EXE=node"

if not defined NODE_EXE (
  for %%P in (
    "%ProgramFiles%\nodejs\node.exe"
    "%ProgramFiles(x86)%\nodejs\node.exe"
    "%LOCALAPPDATA%\Programs\nodejs\node.exe"
    "%APPDATA%\nvm\current\node.exe"
  ) do (
    if not defined NODE_EXE if exist "%%~P" set "NODE_EXE=%%~P"
  )
)

if not defined NODE_EXE (
  echo.
  echo   [!] Node.js not found. The full app needs Node.js 22.5 or newer.
  echo.
  echo   1^) Install Node.js LTS from https://nodejs.org/ then double-click this file again.
  echo      No API Key is required: without .env the app runs a local demo engine.
  echo   2^) Or open the static prototype right now ^(single HTML file^).
  echo.
  for %%F in ("%~dp0*.html") do start "" "%%~fF"
  pause
  exit /b 0
)

"%NODE_EXE%" start-demo.mjs %*
set "CODE=%errorlevel%"

echo.
if not "%CODE%"=="0" echo   Startup failed ^(exit code %CODE%^). Please screenshot the message above.
pause
exit /b %CODE%
