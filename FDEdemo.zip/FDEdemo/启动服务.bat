@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
cd /d "%~dp0"

echo ==========================================
echo   AI 辅助招聘平台 - 本地启动
echo ==========================================
echo.

set "PORT=3000"
set "NODE_EXE="

where node >nul 2>nul
if !errorlevel!==0 (
  set "NODE_EXE=node"
) else (
  for %%P in (
    "%ProgramFiles%\nodejs\node.exe"
    "%ProgramFiles(x86)%\nodejs\node.exe"
    "%LOCALAPPDATA%\Programs\nodejs\node.exe"
  ) do (
    if not defined NODE_EXE if exist "%%~P" set "NODE_EXE=%%~P"
  )
)

if "!NODE_EXE!"=="" (
  echo [错误] 未找到 Node.js，请先安装 Node.js 22 或更高版本。
  echo        下载地址: https://nodejs.org/
  pause
  exit /b 1
)

for /f "delims=" %%v in ('"!NODE_EXE!" -v') do set "NODE_VER=%%v"
echo Node 版本: !NODE_VER!  ^(路径: !NODE_EXE!^)

rem 端口占用则顺延 3000 -^> 3100 -^> 3200
netstat -ano | findstr /C:":3000 " | findstr /C:"LISTENING" >nul 2>nul
if !errorlevel!==0 (
  set "PORT=3100"
  netstat -ano | findstr /C:":3100 " | findstr /C:"LISTENING" >nul 2>nul
  if !errorlevel!==0 set "PORT=3200"
)

echo 端口: !PORT!
echo 地址: http://localhost:!PORT!
echo.
echo 演示账号（密码均为 Passw0rd!）:
echo   liqiang   招聘经理    L2 管理级
echo   wangmin   招聘专员    L1 岗位级
echo   zhangwei  用人经理    L1 岗位级
echo   admin     系统管理员  L3 系统级
echo.
echo 提示: 关闭本窗口即停止服务。
echo ==========================================
echo.

rem 延迟 2 秒再打开浏览器，等 HTTP 服务就绪
start "" powershell -NoProfile -WindowStyle Hidden -Command "Start-Sleep -Seconds 2; Start-Process 'http://localhost:!PORT!/'"

set "PORT=!PORT!"
"!NODE_EXE!" server\app.mjs

echo.
echo 服务已停止。
pause
