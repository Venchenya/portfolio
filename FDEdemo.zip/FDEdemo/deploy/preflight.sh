#!/usr/bin/env bash
# ============================================================
# 部署前自检：确认 IP 对不对、22 通不通、密码对不对、系统是什么
# 用法：bash deploy/preflight.sh root@43.139.x.x [SSH端口]
# ============================================================
set -uo pipefail

TARGET="${1:-}"
SSH_PORT="${2:-22}"

red()  { printf '\033[1;31m✗\033[0m %s\n' "$*"; }
grn()  { printf '\033[1;32m✓\033[0m %s\n' "$*"; }
yel()  { printf '\033[1;33m!\033[0m %s\n' "$*"; }
ttl()  { printf '\n\033[1m%s\033[0m\n' "$*"; }

[ -n "$TARGET" ] || { echo "用法：bash deploy/preflight.sh root@<公网IP> [SSH端口]"; exit 1; }

HOST="${TARGET#*@}"
echo "目标：$TARGET   SSH 端口：$SSH_PORT"

# ---------- 1. IP 格式 ----------
ttl "1/4 公网 IP 格式"
if printf '%s' "$HOST" | grep -qE '^([0-9]{1,3}\.){3}[0-9]{1,3}$'; then
  grn "是 IPv4：$HOST"
else
  red "不像 IPv4：$HOST（应形如 43.139.12.34，不要带 http:// 或端口）"
  exit 1
fi

# ---------- 2. TCP 22 是否放行 ----------
ttl "2/4 SSH 端口连通性"
if command -v timeout >/dev/null 2>&1; then
  if timeout 6 bash -c "</dev/tcp/$HOST/$SSH_PORT" 2>/dev/null; then
    grn "TCP $HOST:$SSH_PORT 可达"
  else
    red "TCP $HOST:$SSH_PORT 连不上"
    echo "   → 90% 是控制台防火墙没放行 $SSH_PORT，或 IP 填错了"
    echo "   → 控制台：轻量应用服务器 → 详情 → 防火墙 → 确认有 TCP $SSH_PORT 允许规则"
    exit 1
  fi
else
  yel "本机无 timeout 命令，跳过 TCP 探测"
fi

# ---------- 3. 登录并采集信息 ----------
ttl "3/4 登录验证（会提示输入 root 密码）"
SSH_OPTS="-p $SSH_PORT -o StrictHostKeyChecking=accept-new -o ConnectTimeout=12 -o LogLevel=ERROR"
REMOTE_CMD='
echo "OS=$(. /etc/os-release 2>/dev/null && echo "$PRETTY_NAME" || echo unknown)"
echo "KERNEL=$(uname -r)"
echo "ARCH=$(uname -m)"
echo "CPU=$(nproc)"
echo "MEM=$(free -m 2>/dev/null | awk "/^Mem:/{print \$2\" MB\"}")"
echo "DISK=$(df -h / | awk "NR==2{print \$4\" 可用 / \"\$2\" 总\"}")"
echo "NODE=$(command -v node >/dev/null && node -v || echo 未安装)"
if command -v node >/dev/null 2>&1; then
  if node -e "import(\"node:sqlite\").then(()=>process.exit(0),()=>process.exit(1))" >/dev/null 2>&1; then
    echo "SQLITE=可用"
  else
    echo "SQLITE=不可用（需 Node 22.5+）"
  fi
fi
echo "PORT3000=$(ss -lntp 2>/dev/null | grep -c ":3000 " || echo 0)"
echo "SVC_HIRE=$(systemctl is-active hire 2>/dev/null || echo 未安装)"
echo "PKG=$(command -v apt-get >/dev/null && echo apt || (command -v dnf >/dev/null && echo dnf || (command -v yum >/dev/null && echo yum || echo 未知)))"
echo "PUBIP=$(curl -fsS --max-time 3 http://metadata.tencentyun.com/latest/meta-data/public-ipv4 2>/dev/null || hostname -I | awk "{print \$1}")"
'

INFO="$(ssh $SSH_OPTS "$TARGET" "$REMOTE_CMD" 2>&1)"
RC=$?
if [ $RC -ne 0 ]; then
  red "登录失败"
  echo "$INFO" | tail -5
  echo "   → Permission denied：密码不对，或改完密码没重启实例"
  echo "   → Connection refused：22 端口没放行"
  echo "   → Host key verification failed：执行 ssh-keygen -R $HOST 清掉旧指纹"
  exit 1
fi
grn "登录成功"
echo "$INFO" | sed 's/^/   /'

# ---------- 4. 结论 ----------
ttl "4/4 结论"
OS_LINE="$(echo "$INFO" | grep '^OS=' | cut -d= -f2-)"
SQLITE_LINE="$(echo "$INFO" | grep '^SQLITE=' | cut -d= -f2-)"
NODE_LINE="$(echo "$INFO" | grep '^NODE=' | cut -d= -f2-)"
PUB_LINE="$(echo "$INFO" | grep '^PUBIP=' | cut -d= -f2-)"
P3000="$(echo "$INFO" | grep '^PORT3000=' | cut -d= -f2-)"

echo "   系统：$OS_LINE"
echo "   Node：$NODE_LINE（sqlite：${SQLITE_LINE:-未检测}）"
echo "   公网 IP（服务器自报）：$PUB_LINE"

if [ "$SQLITE_LINE" = "可用" ]; then
  grn "Everything ready —— 直接跑部署："
  echo "      bash deploy/deploy.sh $TARGET $SSH_PORT"
else
  yel "Node 需要安装（install.sh 会自动处理），可直接部署"
  echo "      bash deploy/deploy.sh $TARGET $SSH_PORT"
fi

if [ "${P3000:-0}" = "0" ]; then
  yel "3000 端口当前未被占用（正常，尚未部署）"
else
  yel "3000 端口已被占用，部署时请换端口，例如：bash deploy/deploy.sh $TARGET 3100"
fi

echo
echo "提示：部署完成后若公网打不开，先在本机执行"
echo "      curl -m 5 http://$PUB_LINE:3000/health"
echo "   通 → 说明服务正常，问题在防火墙/安全组；不通 → 先看 journalctl -u hire -n 50"
