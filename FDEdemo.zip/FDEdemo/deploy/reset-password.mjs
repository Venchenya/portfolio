// 重置指定账号口令（部署后建议立即执行）
// 用法：node deploy/reset-password.mjs admin '新的强密码'
import { db, hashPassword, audit, migrate, seed } from '../server/db.mjs';

migrate();
// 空库视为首次运行，先建默认账号再重置，避免 "no such table"
if (db.prepare('SELECT COUNT(*) c FROM users').get().c === 0) {
  seed();
  console.log('检测到空数据库，已初始化默认账号');
}

const [login, pwd] = process.argv.slice(2);
if (!login || !pwd) {
  console.error('用法: node deploy/reset-password.mjs <登录名> <新密码>');
  console.error('示例: node deploy/reset-password.mjs admin \'Hr@2026#Strong\'');
  process.exit(1);
}
if (pwd.length < 8) {
  console.error('密码至少 8 位');
  process.exit(1);
}

const u = db.prepare('SELECT id, name, role FROM users WHERE login=?').get(login);
if (!u) {
  console.error(`没有登录名为 ${login} 的账号。现有账号：`);
  for (const r of db.prepare('SELECT login, name, role FROM users').all()) {
    console.error(`  ${r.login}  ${r.name}  ${r.role}`);
  }
  process.exit(1);
}

db.prepare('UPDATE users SET pwd=? WHERE id=?').run(hashPassword(pwd), u.id);
audit({ id: null, name: '运维', role: 'sys' }, 'sys', `重置账号口令：${login}`, 'user', u.id);
console.log(`已重置 ${u.name}（${login}）的口令。`);
