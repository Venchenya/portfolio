#!/usr/bin/env bash
# ============================================================
# AI 辅助招聘平台 —— 服务器端安装脚本
# 用法：bash deploy/install.sh
# 环境变量：
#   APP_DIR=/opt/hire   PORT=3000   WITH_LLM=0（不带密钥部署）
# 特性：幂等、可重复执行；不覆盖已有数据库与 .env
# ============================================================
set -euo pipefail

APP_DIR="${APP_DIR:-/opt/hire}"
APP_USER="${APP_USER:-hire}"
PORT="${PORT:-3000}"
WITH_LLM="${WITH_LLM:-1}"

blue() { printf '\033[1;34m[deploy]\033[0m %s\n' "$*"; }
warn() { printf '\033[1;33m[deploy]\033[0m %s\n' "$*"; }
die()  { printf '\033[1;31m[deploy]\033[0m %s\n' "$*" >&2; exit 1; }

[ "$(id -u)" = "0" ] || die "请用 root 运行：sudo bash deploy/install.sh"

SRC="$(cd "$(dirname "$0")/.." && pwd)"
[ -f "$SRC/server/app.mjs" ] || die "找不到 $SRC/server/app.mjs，请在项目根的 deploy/ 目录下执行"

# ---------- 1. 系统识别 ----------
if   command -v apt-get >/dev/null 2>&1; then PKG=apt
elif command -v dnf     >/dev/null 2>&1; then PKG=dnf
elif command -v yum     >/dev/null 2>&1; then PKG=yum
else die "只支持 apt / dnf / yum 系统，当前系统请手动安装 Node 22.5+"
fi
blue "包管理器：$PKG · 目标目录：$APP_DIR · 端口：$PORT"

# ---------- 2. Node（实测 node:sqlite 可用） ----------
node_ok() {
  command -v node >/dev/null 2>&1 || return 1
  node -e "import('node:sqlite').then(()=>process.exit(0),()=>process.exit(1))" >/dev/null 2>&1
}

if node_ok; then
  blue "已存在可用的 Node $(node -v)，跳过安装"
else
  warn "未检测到支持 node:sqlite 的 Node（需 22.5+），开始安装"
  if [ "$PKG" = "apt" ]; then
    apt-get update -y >/dev/null 2>&1 || true
    apt-get install -y curl ca-certificates >/dev/null 2>&1 || true
    curl -fsSL --max-time 60 https://deb.nodesource.com/setup_22.x -o /tmp/ns.sh 2>/dev/null && bash /tmp/ns.sh >/dev/null 2>&1 && apt-get install -y nodejs >/dev/null 2>&1 || warn "NodeSource 安装未成功，尝试官方二进制"
  else
    curl -fsSL --max-time 60 https://rpm.nodesource.com/setup_22.x -o /tmp/ns.sh 2>/dev/null && bash /tmp/ns.sh >/dev/null 2>&1 && $PKG install -y nodejs >/dev/null 2>&1 || warn "NodeSource 安装未成功，尝试官方二进制"
  fi

  if ! node_ok; then
    # 官方二进制：先查 v22 最新版本号，失败则用固定版本
    NODE_VER="$(curl -fsSL --max-time 20 https://nodejs.org/dist/latest-v22.x/SHASUMS256.txt 2>/dev/null \
      | grep -oE 'node-v[0-9]+\.[0-9]+\.[0-9]+-linux-x64\.tar\.gz' | head -1 \
      | sed 's/-linux-x64\.tar\.gz//')"
    [ -n "${NODE_VER:-}" ] || NODE_VER="v22.22.2"
    blue "下载 Node $NODE_VER 二进制包"

    GOT=""
    for base in https://npmmirror.com/mirrors/node https://nodejs.org/dist; do
      if curl -fsSL --max-time 180 -o /tmp/node.tgz "$base/$NODE_VER/node-$NODE_VER-linux-x64.tar.gz" 2>/dev/null; then
        GOT="$base"; break
      fi
    done
    [ -n "$GOT" ] || die "Node 下载失败（网络受限）。请手动安装 Node 22.5+ 后重跑本脚本"

    mkdir -p /usr/local/lib
    tar -xzf /tmp/node.tgz -C /usr/local/lib
    for b in node npm npx; do
      [ -e "/usr/local/lib/node-$NODE_VER-linux-x64/bin/$b" ] && \
        ln -sf "/usr/local/lib/node-$NODE_VER-linux-x64/bin/$b" "/usr/local/bin/$b"
    done
    rm -f /tmp/node.tgz
  fi

  node_ok || die "Node 安装后仍不支持 node:sqlite，请手动安装 Node 22.5+ 后重试（当前：$(node -v 2>/dev/null || echo 无)）"
  blue "Node 就绪：$(node -v)"
fi

# ---------- 3. 运行用户 ----------
if ! id -u "$APP_USER" >/dev/null 2>&1; then
  useradd --system --home-dir "$APP_DIR" --shell /usr/sbin/nologin "$APP_USER" 2>/dev/null \
    || useradd --system --home-dir "$APP_DIR" --shell /bin/false "$APP_USER" 2>/dev/null \
    || die "创建系统用户 $APP_USER 失败"
  blue "已创建系统用户 $APP_USER"
fi

# ---------- 4. 部署代码（保留 data 与 .env） ----------
if [ "$SRC" != "$APP_DIR" ]; then
  mkdir -p "$APP_DIR"
  for f in server test package.json README.md deploy; do
    [ -e "$SRC/$f" ] && cp -a "$SRC/$f" "$APP_DIR/"
  done
  blue "代码已同步到 $APP_DIR"
fi

mkdir -p "$APP_DIR/data"

# ---------- 5. 环境变量文件 ----------
if [ ! -f "$APP_DIR/.env" ]; then
  cat > "$APP_DIR/.env" <<'ENVEOF'
# 大模型配置（OpenAI 兼容接口）。LLM_API_KEY 留空则自动降级为「人工对照模式」。
LLM_BASE_URL=https://api.deepseek.com
LLM_MODEL=deepseek-flash
LLM_API_KEY=
ENVEOF
  warn "未找到 .env，已生成模板；LLM_API_KEY 为空 → 将以人工对照模式运行"
fi

if [ "$WITH_LLM" != "1" ]; then
  sed -i 's/^LLM_API_KEY=.*/LLM_API_KEY=/' "$APP_DIR/.env"
  warn "按 WITH_LLM=0 清空了 LLM_API_KEY（AI 走降级模式）"
fi

chown -R "$APP_USER:$APP_USER" "$APP_DIR"
chmod 600 "$APP_DIR/.env"
chmod 700 "$APP_DIR/data"

# ---------- 6. systemd ----------
NODE_BIN="$(command -v node)"
cat > /etc/systemd/system/hire.service <<SVCEOF
[Unit]
Description=AI 辅助招聘平台 (hire)
Documentation=file://$APP_DIR/README.md
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=$APP_USER
Group=$APP_USER
WorkingDirectory=$APP_DIR
Environment=NODE_ENV=production
Environment=PORT=$PORT
ExecStart=$NODE_BIN server/app.mjs
Restart=always
RestartSec=3
StandardOutput=journal
StandardError=journal
SyslogIdentifier=hire

# 加固：不可提权、独立 /tmp、系统目录只读、仅 data 可写
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=full
ProtectHome=true
ReadWritePaths=$APP_DIR $APP_DIR/data
LimitNOFILE=65535

[Install]
WantedBy=multi-user.target
SVCEOF

systemctl daemon-reload
systemctl enable hire >/dev/null 2>&1 || true
systemctl restart hire
blue "systemd 服务 hire 已启动"

# ---------- 7. 本机防火墙 ----------
if command -v ufw >/dev/null 2>&1 && ufw status 2>/dev/null | grep -q "Status: active"; then
  ufw allow "$PORT/tcp" >/dev/null 2>&1 && blue "ufw 已放行 $PORT/tcp"
fi
if command -v firewall-cmd >/dev/null 2>&1 && firewall-cmd --state >/dev/null 2>&1; then
  firewall-cmd --permanent --add-port="$PORT/tcp" >/dev/null 2>&1
  firewall-cmd --reload >/dev/null 2>&1
  blue "firewalld 已放行 $PORT/tcp"
fi

# ---------- 8. 健康检查 ----------
OK=0
for _ in $(seq 1 20); do
  if curl -fsS --max-time 2 "http://127.0.0.1:$PORT/health" >/dev/null 2>&1; then OK=1; break; fi
  sleep 1
done
if [ "$OK" != "1" ]; then
  warn "服务未在 20 秒内就绪，最近日志："
  journalctl -u hire -n 40 --no-pager 2>/dev/null || true
  die "启动失败，请把上面的日志发我"
fi

HEALTH="$(curl -fsS --max-time 3 "http://127.0.0.1:$PORT/health" 2>/dev/null || echo '{}')"
PUB_IP="$(curl -fsS --max-time 3 http://metadata.tencentyun.com/latest/meta-data/public-ipv4 2>/dev/null || true)"
[ -n "${PUB_IP:-}" ] || PUB_IP="$(hostname -I 2>/dev/null | awk '{print $1}')"

cat <<SUMMARY

============================================================
 部署完成
------------------------------------------------------------
 本机检查 : $(printf '%s' "$HEALTH" | tr -d '\n' | cut -c1-160)
 访问地址 : http://${PUB_IP}:${PORT}
 演示账号 : liqiang(用人经理) wangmin(招聘专员) zhangwei(招聘经理) admin(系统管理员)
 统一密码 : Passw0rd!
------------------------------------------------------------
 常用命令
   查看状态 : systemctl status hire
   实时日志 : journalctl -u hire -f
   重启服务 : systemctl restart hire
   改密钥   : vim $APP_DIR/.env 然后 systemctl restart hire
------------------------------------------------------------
 还需要你做一件事（否则公网打不开）：
   腾讯云控制台 → 轻量应用服务器 → 防火墙 → 添加规则
   应用类型选「自定义」协议 TCP 端口 ${PORT} 来源 0.0.0.0/0
============================================================
SUMMARY

if [ "$WITH_LLM" = "1" ] && grep -q "^LLM_API_KEY=.\+" "$APP_DIR/.env"; then
  warn "注意：本机已配置真实大模型密钥，公网可访问时请务必先改掉演示账号密码"
else
  warn "注意：当前为人工对照模式（无密钥），AI 分析不会调用模型"
fi
