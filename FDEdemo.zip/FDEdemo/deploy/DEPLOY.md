# 部署手册 · 腾讯云轻量应用服务器

项目是**零依赖 Node**（只有 `node:http` / `node:sqlite` / `node:zlib`），不需要 npm install、不需要数据库、不需要 Docker。整台机器上只需要装一个 **Node 22.5+**。

---

## 0. 先准备三样东西

| 项 | 在哪拿 | 说明 |
| --- | --- | --- |
| 公网 IP | 控制台实例详情页 | 形如 `43.139.x.x` |
| root 密码 | 控制台「重置密码」或首次创建时的短信 | 忘了就在控制台重置 |
| 放行 3000 端口 | 控制台 → 防火墙 → 添加规则 | **这步不做，服务起来了也打不开** |

防火墙规则填法：应用类型「自定义」、协议 **TCP**、端口 **3000**、来源 `0.0.0.0/0`。

---

## 1. 路线 A：本地一条命令（推荐）

在**你自己电脑**的项目目录里打开 Git Bash：

```bash
cd /d/FDE训练营
bash deploy/deploy.sh root@43.139.x.x
```

它会依次做四件事：打包（排除 `.env`、`data`、`node_modules`、`openspec`）→ scp 上传 → 远端解包 → 执行 `deploy/install.sh` 并打印结果。

中途会提示输一次 root 密码（或用密钥则免密）。脚本**可重复执行**，第二次跑不会覆盖服务器上的数据库和 `.env`。

指定端口：

```bash
bash deploy/deploy.sh root@43.139.x.x 8080
```

不带模型密钥部署（AI 走人工对照模式，避免密钥落在公网机器上）：

```bash
WITH_LLM=0 bash deploy/deploy.sh root@43.139.x.x
```

---

## 2. 路线 B：在服务器的 WebShell 里手动做

控制台点「登录」进 WebShell（root 身份），依次执行：

```bash
# 1) 装 Node 22（用官方二进制，国内走 npmmirror）
curl -fsSL https://npmmirror.com/mirrors/node/v22.22.2/node-v22.22.2-linux-x64.tar.gz -o /tmp/n.tgz
tar -xzf /tmp/n.tgz -C /usr/local/lib
ln -sf /usr/local/lib/node-v22.22.2-linux-x64/bin/node /usr/local/bin/node
ln -sf /usr/local/lib/node-v22.22.2-linux-x64/bin/npm  /usr/local/bin/npm
node -v          # 应输出 v22.22.2
node -e "import('node:sqlite').then(()=>console.log('sqlite OK'))"

# 2) 建目录与用户
useradd --system --home-dir /opt/hire --shell /usr/sbin/nologin hire || true
mkdir -p /opt/hire
```

然后**上传代码**：把本地 `.workbuddy/tmp/hire-*.tar.gz` 通过控制台的「上传文件」传到 `/tmp/`，再：

```bash
cd /opt/hire && tar -xzf /tmp/hire-*.tar.gz
# 单独放密钥文件（没有就走降级模式）
cat > /opt/hire/.env <<'EOF'
LLM_BASE_URL=https://api.deepseek.com
LLM_MODEL=deepseek-flash
LLM_API_KEY=你的key
EOF
chown -R hire:hire /opt/hire && chmod 600 /opt/hire/.env
bash /opt/hire/deploy/install.sh
```

`install.sh` 会自动写 systemd、放行防火墙、起服务、健康检查。

---

## 3. 部署完成后

访问 `http://公网IP:3000`，用下列账号登录（密码统一 `Passw0rd!`）：

| 账号 | 姓名 | 角色 | 层级 |
| --- | --- | --- | --- |
| `liqiang` | 李强 | 用人经理 | L1 |
| `wangmin` | 王敏 | 招聘专员 | L1 |
| `zhangwei` | 张伟 | 招聘经理 | L2 |
| `admin` | 管理员 | 系统管理员 | L3 |

> 公网部署**第一件事是改密码**：
> ```bash
> cd /opt/hire && node deploy/reset-password.mjs admin '你的强密码'
> ```
> 四个账号都改一遍。不改等于把系统交给扫描器。

常用运维命令：

```bash
systemctl status hire        # 状态
journalctl -u hire -f        # 实时日志
systemctl restart hire       # 重启
vim /opt/hire/.env           # 改密钥/模型，改完要 restart
```

在页面里确认模型是否接通：用 `admin` 登录 → **P13 系统参数** → 顶部「大模型接入」卡片 → 点「测试连通性」。返回「连通正常」说明密钥与模型都有效。

---

## 4. 可选：Nginx + 域名

```bash
apt install -y nginx
cp /opt/hire/deploy/nginx-hire.conf /etc/nginx/conf.d/hire.conf
nginx -t && systemctl reload nginx
```

有域名并已解析到该 IP 时上 HTTPS：

```bash
apt install -y certbot python3-certbot-nginx
certbot --nginx -d hire.example.com
```

上 HTTPS 后要把防火墙的 80/443 一起放行，3000 可以收回只监听本机。

---

## 5. 排障对照表

| 现象 | 原因 | 处理 |
| --- | --- | --- |
| 浏览器转圈/超时 | 安全组没放行 3000 | 控制台防火墙加 TCP 3000 |
| `curl 127.0.0.1:3000/health` 通、公网不通 | 同上（本机通说明服务没问题） | 同上 |
| 服务起不来、日志有 `ERR_UNKNOWN_BUILTIN_MODULE: node:sqlite` | Node 版本低于 22.5 或未带该模块 | `node -v` 确认；`install.sh` 会实测这个能力，重跑即可 |
| 日志 `EACCES: permission denied, open 'data/app.db'` | 目录属主不对 | `chown -R hire:hire /opt/hire && chmod 700 /opt/hire/data` |
| 日志 `EADDRINUSE` | 3000 被占 | `ss -lntp \| grep 3000` 找占用进程，或改用 `PORT=3100 bash deploy/install.sh` |
| 页面能开但 AI 分析返回「信息不足」且标 degraded | 密钥未配或模型名不对 | 页面 P13 点「测试连通性」看具体报错 |
| 上传 PDF 提示「未检测到文字层」 | 扫描件没有文字层 | 改贴文本，或二期接 `pdfjs-dist` |
| `node: command not found`（systemd 里） | unit 里写的是软链前的路径 | 重跑 `install.sh`，它会用 `command -v node` 重新写 unit |
| `Permission denied (publickey,password)`，密码确认没错 | 腾讯云 Ubuntu 镜像默认禁用 root 登录 | 改用 `ubuntu` 用户 + `sudo`，或在控制台开启 root 登录并重启 |
| 远端报 `/tmp/xxx: No such file`，但文件确实传了 | Git Bash 把 `/tmp/x` 自动改写成 Windows 路径 | 命令前加 `MSYS_NO_PATHCONV=1` |
| `systemctl reload caddy` 失败，日志提到 log 文件无法打开 | Caddy 的 systemd unit 有路径沙箱，自定义 `log` 指到白名单外会被拦 | 删掉 Caddyfile 里的 `log` 段，改用默认 journald 输出 |
| 反代 502 / 页面 404 | Caddy 起来了但上游没起，或 `reverse_proxy` 端口写错 | `systemctl is-active hire`；`curl 127.0.0.1:3000/health` |

看日志一次看全：

```bash
journalctl -u hire -n 80 --no-pager
journalctl -u caddy -n 40 --no-pager   # 用反代时
```

---

## 5.1 用 80 端口反代（推荐，地址不带端口）

轻量服务器防火墙入站默认只放行 22/80/443/3389，**3000 通常要手动加**。既然 80 本来就开，用它反代更省事，将来绑域名还能自动上 HTTPS。

`deploy/Caddyfile` 已备好：

```
:80 {
	encode zstd gzip
	reverse_proxy 127.0.0.1:3000
}
```

应用（在服务器上，`ubuntu` 用户）：

```bash
sudo cp /etc/caddy/Caddyfile /etc/caddy/Caddyfile.bak.$(date +%F-%H%M)
sudo cp deploy/Caddyfile /etc/caddy/Caddyfile
sudo caddy validate --config /etc/caddy/Caddyfile --adapter caddyfile
sudo systemctl reload caddy
curl -s -o /dev/null -w '%{http_code}\n' http://127.0.0.1/login   # 应为 200
```

> **不要**在 Caddyfile 里加自定义 `log` 路径。Caddy 的 unit 启用了 `ProtectSystem` 与路径白名单，指到 `/var/log/caddy/*.log` 会 reload 失败，且改目录属主也无效。默认写 journald 即可。

有域名后只需把 `:80` 换成 `你的域名`，Caddy 会自动申请并续期证书。

---

## 5.2 本次真实上线的踩坑记录（2026-10-25）

可复用的经验，按发现顺序：

1. **root 登录被禁用** — 腾讯云 Ubuntu 镜像 `PermitRootLogin` 关闭，用 root 密码连会报 `Permission denied`。实际要用 `ubuntu` 用户，再 `sudo`。部署脚本里的 `hire` 服务用户与这个无关。
2. **Git Bash 改写绝对路径** — `node cli push local /tmp/hire.env` 里，`/tmp/hire.env` 被 MSYS 转成 `C:/Users/.../Temp/hire.env` 发给远端，导致「本地文件明明存在、远端说找不到」。加 `MSYS_NO_PATHCONV=1` 解决。同理适用于 `scp`、`ssh` 里带 `/` 开头的参数。
3. **Caddy reload 两次失败** — 第一次是日志目录不存在/属主不对，修完仍失败；第二次查明是 systemd 沙箱的路径白名单。正解是**去掉自定义 log 段**，不要试图改 unit。
4. **`reset-password.mjs` 在空库上崩溃** — `db.mjs` 只导出 `migrate`/`seed`，建表是 `app.mjs` 显式调用的，模块加载不会自动执行。脚本已改为先 `migrate()`，空库时再 `seed()`。

---

## 6. 数据备份与迁移

数据只有一个 SQLite 文件（WAL 模式下还有 `-wal` / `-shm`）：

```bash
# 备份（在线安全）
systemctl stop hire
tar -czf /root/hire-backup-$(date +%F).tar.gz -C /opt/hire data .env
systemctl start hire

# 恢复
systemctl stop hire
tar -xzf /root/hire-backup-2026-10-25.tar.gz -C /opt/hire
chown -R hire:hire /opt/hire/data
systemctl start hire
```

---

## 7. 公网部署的安全底线

这个 MVP 是**演示/内网**定位，以下几项在公网环境必须知道：

1. **没有 HTTPS**，登录口令与 Cookie 明文传输。正式用必须上证书。
2. **没有 CSRF token**，表单可被跨站提交。
3. **演示密码是公开的**（写在 README 里），不改密码等于公开后台。
4. **`.env` 里有真实大模型密钥**，机器被拿到就等于密钥泄漏；可选 `WITH_LLM=0` 部署，或在云厂商侧给 key 设额度上限。
5. 服务以 `hire` 系统用户运行、`ProtectSystem=full`、禁止提权，但没有做容器隔离。

演示场景里最快补齐的是 1 和 3：域名 + certbot 上证书，四个账号改强密码。
