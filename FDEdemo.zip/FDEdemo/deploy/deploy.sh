#!/usr/bin/env bash
# ============================================================
# 本地一键部署：打包 → 上传 → 远端安装 → 健康检查
# 用法：
#   bash deploy/deploy.sh root@1.2.3.4            # 默认 3000 端口
#   bash deploy/deploy.sh root@1.2.3.4 3100       # 指定端口
#   WITH_LLM=0 bash deploy/deploy.sh root@1.2.3.4 # 不带模型密钥部署
# 前置：本地能 ssh 到目标机（密码或密钥均可）
# ============================================================
set -euo pipefail

TARGET="${1:-}"
PORT="${2:-${PORT:-3000}}"
WITH_LLM="${WITH_LLM:-1}"

red()  { printf '\033[1;31m[deploy]\033[0m %s\n' "$*"; }
blue() { printf '\033[1;34m[deploy]\033[0m %s\n' "$*" >&2; }
die()  { red "$*"; exit 1; }

[ -n "$TARGET" ] || die "用法：bash deploy/deploy.sh root@<公网IP> [端口]"

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
[ -f server/app.mjs ] || die "当前目录不像项目根：$ROOT"

SSH_OPTS="-o StrictHostKeyChecking=accept-new -o ConnectTimeout=15 -o ServerAliveInterval=15"
STAMP="$(date +%Y%m%d-%H%M%S)"
PKG=".workbuddy/tmp/hire-$STAMP.tar.gz"
mkdir -p .workbuddy/tmp

blue "1/4 打包（排除 .env / data / node_modules / openspec）"
tar -czf "$PKG" \
  --exclude='.env' \
  --exclude='data' \
  --exclude='node_modules' \
  --exclude='.workbuddy' \
  --exclude='openspec' \
  --exclude='dist' \
  --exclude='*.log' \
  server test package.json README.md deploy
blue "    包大小 $(du -h "$PKG" | cut -f1)  →  $PKG"

blue "2/4 上传到 $TARGET"
ssh $SSH_OPTS "$TARGET" "rm -rf /tmp/hire-deploy && mkdir -p /tmp/hire-deploy"
scp $SSH_OPTS "$PKG" "$TARGET:/tmp/hire-deploy/pkg.tar.gz" >/dev/null
if [ -f .env ]; then
  scp $SSH_OPTS .env "$TARGET:/tmp/hire-deploy/env" >/dev/null
  blue "    .env 已单独上传（远端将设为 600）"
else
  blue "    未找到本地 .env，远端将以人工对照模式启动"
fi

blue "3/4 远端解包并安装（幂等，不会覆盖已有数据库）"
ssh $SSH_OPTS "$TARGET" "bash -s" <<REMOTE
set -e
cd /tmp/hire-deploy
rm -rf src && mkdir -p src && tar -xzf pkg.tar.gz -C src
[ -f env ] && cp env src/.env
cd src
WITH_LLM=$WITH_LLM PORT=$PORT bash deploy/install.sh
REMOTE

blue "4/4 完成"
