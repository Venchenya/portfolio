// 极简 PDF 文本层提取（零依赖）：FlateDecode 解压 + Tj/TJ 文本算子抽取
// 局限：仅支持含文字层的 PDF；扫描件、复杂版式（多栏/表格）可能抽取不全 → 由调用方降级人工。
import { inflateSync, inflateRawSync } from 'node:zlib';

function unescapePdfString(s) {
  return s
    .replace(/\\([nrtbf])/g, (_, c) => ({ n: '\n', r: '\r', t: '\t', b: '\b', f: '\f' }[c] || c))
    .replace(/\\([0-7]{1,3})/g, (_, o) => String.fromCharCode(parseInt(o, 8)))
    .replace(/\\(.)/g, '$1');
}

function extractFromContent(content) {
  const out = [];
  // (...) Tj
  const tjs = /\((?:\\.|[^\\()])*\)\s*Tj/g;
  let m;
  while ((m = tjs.exec(content))) {
    const raw = m[0].replace(/\)\s*Tj$/, '').replace(/^\(/, '');
    out.push(unescapePdfString(raw));
  }
  // [ (a) -234 (b) ] TJ
  const tjsArr = /\[((?:[^\][\\]|\\.)*)\]\s*TJ/g;
  while ((m = tjsArr.exec(content))) {
    const parts = [...m[1].matchAll(/\((?:\\.|[^\\()])*\)/g)].map((x) => unescapePdfString(x[0].slice(1, -1)));
    if (parts.length) out.push(parts.join(''));
  }
  return out;
}

export function extractPdfText(buf) {
  if (!buf || buf.length < 100) return null;
  const latin = buf.toString('latin1');
  if (!latin.includes('%PDF')) return null;

  const chunks = [];
  const re = /stream\r?\n?/g;
  let m;
  while ((m = re.exec(latin))) {
    const start = m.index + m[0].length;
    const end = latin.indexOf('endstream', start);
    if (end < 0) break;
    const raw = buf.subarray(start, end);
    let data = null;
    try { data = inflateSync(raw); } catch { try { data = inflateRawSync(raw); } catch { data = raw; } }
    const text = data.toString('latin1');
    // 只保留可能含文本算子的流，避免把字体/图片流当正文
    if (/\b(Tj|TJ)\b/.test(text)) chunks.push(extractFromContent(text));
    re.lastIndex = end;
  }
  const text = chunks.flat().join('\n').replace(/[ \t]+\n/g, '\n').trim();
  if (text.replace(/\s/g, '').length < 20) return null;
  return text;
}
