// HTTP 基础能力：路由、表单解析、会话、权限、页面布局（零依赖）
import { randomBytes } from 'node:crypto';
import { db, audit, nowIso } from './db.mjs';

export class HttpError extends Error {
  constructor(status, message, extra) {
    super(message);
    this.status = status;
    this.extra = extra;
  }
}

export const esc = (s) =>
  String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

export function parseCookies(req) {
  const raw = req.headers.cookie || '';
  const out = {};
  raw.split(';').forEach((p) => {
    const i = p.indexOf('=');
    if (i > 0) out[p.slice(0, i).trim()] = decodeURIComponent(p.slice(i + 1).trim());
  });
  return out;
}

export function currentUser(req) {
  const token = parseCookies(req).sid;
  if (!token) return null;
  const row = db.prepare('SELECT u.* FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token=? AND s.expires_at>?').get(token, Date.now());
  if (!row || row.status !== 'active') return null;
  return row;
}

export function createSession(userId) {
  const token = randomBytes(24).toString('hex');
  const hours = Number(db.prepare("SELECT value FROM configs WHERE key='session_hours'").get()?.value || 8);
  db.prepare('INSERT INTO sessions (token,user_id,expires_at) VALUES (?,?,?)').run(token, userId, Date.now() + hours * 3600_000);
  return token;
}
export function destroySession(req) {
  const token = parseCookies(req).sid;
  if (token) db.prepare('DELETE FROM sessions WHERE token=?').run(token);
}

export async function readBody(req, limit = 8 * 1024 * 1024) {
  const chunks = [];
  let size = 0;
  for await (const c of req) {
    size += c.length;
    if (size > limit) throw new HttpError(413, '请求体过大（上限 8MB）');
    chunks.push(c);
  }
  return Buffer.concat(chunks);
}

export async function parseForm(req) {
  const type = req.headers['content-type'] || '';
  const buf = await readBody(req);
  if (type.includes('multipart/form-data')) return parseMultipart(buf, type);
  const out = {};
  for (const [k, v] of new URLSearchParams(buf.toString('utf8'))) out[k] = v;
  return out;
}

// 最小 multipart 解析：仅处理文本字段与单文件
function parseMultipart(buf, contentType) {
  const m = /boundary=(?:"([^"]+)"|([^;]+))/i.exec(contentType);
  if (!m) throw new HttpError(400, '缺少 multipart boundary');
  const boundary = Buffer.from('--' + (m[1] || m[2]).trim());
  const out = {};
  let pos = 0;
  while (true) {
    const start = buf.indexOf(boundary, pos);
    if (start < 0) break;
    const next = buf.indexOf(boundary, start + boundary.length);
    if (next < 0) break;
    const part = buf.slice(start + boundary.length + 2, next - 2);
    const sep = part.indexOf('\r\n\r\n');
    if (sep < 0) { pos = next; continue; }
    const head = part.slice(0, sep).toString('utf8');
    const body = part.slice(sep + 4);
    const nameM = /name="([^"]+)"/.exec(head);
    const fileM = /filename="([^"]*)"/.exec(head);
    if (nameM) {
      if (fileM) out[nameM[1] + '__file'] = { filename: fileM[1], data: body };
      else out[nameM[1]] = body.toString('utf8');
    }
    pos = next;
  }
  return out;
}

export const ROLE_NAME = { yr: '用人经理', zy: '招聘专员', jl: '招聘经理', sys: '系统管理员' };
export const LEVEL = { yr: 'L1 岗位级', zy: 'L1 岗位级', jl: 'L2 管理级', sys: 'L3 系统级' };
export const PAGE_ROLES = {
  '/jobs': ['yr'],
  '/assign': ['jl'],
  '/upload': ['zy'],
  '/check': ['zy'],
  '/dept': ['yr'],
  '/track': ['zy'],
  '/board': ['jl'],
  '/reminders': ['jl'],
  '/audit': ['jl'],
  '/config/biz': ['jl'],
  '/users': ['sys'],
  '/data': ['sys'],
  '/config/sys': ['sys'],
};

export function requireRole(user, roles, path = '') {
  if (!user) throw new HttpError(401, '请先登录');
  if (!roles.includes(user.role)) {
    audit(user, user.role, '越权访问被拦截', 'page', path, `role=${user.role}`);
    throw new HttpError(403, `该页面唯一归属：${roles.map((r) => ROLE_NAME[r]).join('/')}`);
  }
}

export function ownedJobs(user) {
  if (user.role === 'jl' || user.role === 'sys') return db.prepare('SELECT * FROM jobs ORDER BY id DESC').all();
  if (user.role === 'yr') return db.prepare('SELECT * FROM jobs WHERE owner_yr=? ORDER BY id DESC').all(user.id);
  return db.prepare('SELECT * FROM jobs WHERE owner_zy=? ORDER BY id DESC').all(user.id);
}

export function canSeeApp(user, app) {
  if (!app) return false;
  if (user.role === 'jl') return true;
  if (user.role === 'zy') return app.owner_zy === user.id;
  if (user.role === 'yr') {
    const job = db.prepare('SELECT owner_yr FROM jobs WHERE id=?').get(app.job_id);
    return !!job && job.owner_yr === user.id;
  }
  return false;
}

export function assertCanSeeApp(user, app, opts = {}) {
  if (!canSeeApp(user, app)) {
    audit(user, user.role, '越权访问被拦截', 'application', app?.id ?? '', 'data-scope');
    // 不泄露存在性
    throw new HttpError(403, '无权访问该候选人材料');
  }
  return app;
}

export const CSS = `
:root{
--font:"PingFang SC","HarmonyOS Sans SC","Microsoft YaHei","Source Han Sans SC",-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif;
--mono:"SFMono-Regular",Consolas,"Liberation Mono",Menlo,monospace;
--ink-950:#0C111D;--ink-900:#101828;--ink-800:#1D2939;--ink-700:#344054;
--ink-600:#475467;--ink-500:#667085;--ink-400:#98A2B3;--ink-300:#D0D5DD;
--ink-200:#EAECF0;--ink-100:#F2F4F7;--ink-50:#F9FAFB;
--brand-700:#0043CE;--brand-600:#0F62FE;--brand-100:#D1E0FF;--brand-50:#EDF5FF;
--ok-700:#027A48;--ok-50:#ECFDF3;--ok-line:#ABEFC6;
--wa-700:#B54708;--wa-50:#FFFAEB;--wa-line:#FEDF89;
--dg-700:#B42318;--dg-50:#FEF3F2;--dg-line:#FECDCA;
--bg:#F7F8FA;--s:#FFFFFF;
--r-sm:6px;--r:8px;--r-lg:12px;
--sh-xs:0 1px 2px rgba(16,24,40,.05);
--sh-sm:0 1px 3px rgba(16,24,40,.1),0 1px 2px rgba(16,24,40,.06);
--sh-lg:0 12px 16px -4px rgba(16,24,40,.08),0 4px 6px -2px rgba(16,24,40,.03);
--ring:0 0 0 4px rgba(15,98,254,.14);
--nav-w:248px;
--bd:var(--ink-200);--tx:var(--ink-900);--tx2:var(--ink-600);--tx3:var(--ink-500);
--p:var(--brand-600);--pd:var(--brand-700);--ps:var(--brand-50)
}
*{box-sizing:border-box;margin:0;padding:0}
html{-webkit-text-size-adjust:100%}
body{font-family:var(--font);background:var(--bg);color:var(--ink-900);font-size:14px;line-height:1.6;
-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale}
a{color:var(--brand-700);text-decoration:none}
a:hover{color:var(--brand-600)}
::selection{background:var(--brand-100);color:var(--ink-950)}

/* ---------- 排版 ---------- */
h1{font-size:22px;line-height:1.35;font-weight:600;letter-spacing:-.012em;color:var(--ink-900)}
h2{font-size:17px;line-height:1.4;font-weight:600;letter-spacing:-.008em}
h3{font-size:14px;line-height:1.45;font-weight:600;color:var(--ink-900)}
.sub{font-size:12.5px;line-height:1.65;color:var(--ink-500);font-weight:400}
.mono{font-family:var(--mono);font-variant-numeric:tabular-nums}

/* ---------- 骨架：侧栏 + 主区 ---------- */
.wrap{display:flex;min-height:100vh}
.side{width:var(--nav-w);background:var(--ink-950);position:fixed;inset:0 auto 0 0;z-index:30;
display:flex;flex-direction:column;border-right:1px solid rgba(255,255,255,.06)}
.brand{display:flex;align-items:center;gap:10px;padding:18px 18px 16px;border-bottom:1px solid rgba(255,255,255,.07)}
.brand .lg{width:30px;height:30px;flex:none;border-radius:8px;background:var(--brand-600);display:grid;place-items:center;
box-shadow:0 1px 2px rgba(0,0,0,.3),inset 0 1px 0 rgba(255,255,255,.16)}
.brand .lg svg{width:17px;height:17px}
.brand b{display:block;font-size:13.5px;font-weight:600;color:#fff;letter-spacing:.01em;line-height:1.3}
.brand span{display:block;font-size:9.5px;color:var(--ink-400);letter-spacing:.09em;text-transform:uppercase;margin-top:2px}
.nav{padding:14px 12px;flex:1;overflow:auto}
.nav-title{font-size:10px;font-weight:600;letter-spacing:.1em;text-transform:uppercase;color:var(--ink-500);padding:0 10px 8px}
.nav a{display:flex;align-items:center;gap:10px;padding:9px 10px;border-radius:var(--r);color:#C3CAD9;
font-size:13px;text-decoration:none;position:relative;transition:background .15s,color .15s}
.nav a svg{width:16px;height:16px;flex:none;opacity:.7;transition:opacity .15s}
.nav a span{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.nav a:hover{background:rgba(255,255,255,.055);color:#fff}
.nav a:hover svg{opacity:1}
.nav a.on{background:rgba(255,255,255,.09);color:#fff;font-weight:600}
.nav a.on svg{opacity:1}
.nav a.on::before{content:"";position:absolute;left:-12px;top:50%;transform:translateY(-50%);
width:3px;height:18px;background:var(--brand-600);border-radius:0 3px 3px 0}
.nav a:focus-visible{outline:2px solid var(--brand-600);outline-offset:1px}
.side-foot{padding:12px;border-top:1px solid rgba(255,255,255,.07)}
.u{display:flex;align-items:center;gap:10px;padding:9px 10px;border-radius:var(--r);background:rgba(255,255,255,.045);
border:1px solid rgba(255,255,255,.06)}
.u .av{width:30px;height:30px;flex:none;border-radius:50%;background:#1B2537;color:#fff;border:1px solid rgba(255,255,255,.14);
display:grid;place-items:center;font-size:12px;font-weight:600}
.u b{display:block;font-size:12.5px;font-weight:600;color:#fff;line-height:1.35}
.u span{display:block;font-size:10.5px;color:var(--ink-400);margin-top:1px}
.u .out{margin-left:auto;color:var(--ink-400);display:grid;place-items:center;padding:4px;border-radius:6px;transition:.15s}
.u .out:hover{background:rgba(255,255,255,.1);color:#fff}
.u .out svg{width:15px;height:15px}
.scope{margin-top:8px;font-size:10.5px;line-height:1.5;color:var(--ink-500);padding:0 4px}
.scope b{color:var(--ink-400);font-weight:500}

/* ---------- 主区 ---------- */
.main{margin-left:var(--nav-w);flex:1;min-width:0;display:flex;flex-direction:column}
.top{height:56px;flex:none;background:rgba(255,255,255,.86);backdrop-filter:saturate(180%) blur(10px);
-webkit-backdrop-filter:saturate(180%) blur(10px);border-bottom:1px solid var(--ink-200);
display:flex;align-items:center;gap:12px;padding:0 26px;position:sticky;top:0;z-index:20}
.crumb{display:flex;align-items:center;gap:7px;font-size:12.5px;color:var(--ink-400);min-width:0}
.crumb b{color:var(--ink-700);font-weight:500}
.crumb i{font-style:normal;color:var(--ink-300)}
.crumb .seal{display:inline-flex;align-items:center;gap:5px;height:21px;padding:0 8px;border-radius:5px;
background:var(--ink-100);color:var(--ink-600);font-size:10.5px;font-weight:600;letter-spacing:.02em}
.crumb .seal i{width:5px;height:5px;border-radius:50%;background:#12B76A;box-shadow:0 0 0 2px rgba(18,183,106,.16)}
.spacer{flex:1}
.top .who{font-size:12.5px;color:var(--ink-600);display:flex;align-items:center;gap:8px}
.top .who>span:first-child{width:26px;height:26px;flex:none;border-radius:50%;background:var(--brand-50);
border:1px solid var(--brand-100);color:var(--brand-700);display:grid;place-items:center;
font-size:11.5px;font-weight:600;line-height:1}
.top .who b{font-weight:600;color:var(--ink-900)}
.top .who .lv{font-size:10.5px;font-weight:600;color:var(--brand-700);background:var(--brand-50);
border:1px solid var(--brand-100);border-radius:5px;padding:1px 6px}
.top .hlink{font-size:11.5px;color:var(--ink-400);font-family:var(--mono);border:1px solid var(--ink-200);
border-radius:6px;padding:3px 8px;background:var(--s);transition:.15s}
.top .hlink:hover{color:var(--ink-700);border-color:var(--ink-300)}
.body{padding:26px 28px 60px;max-width:1240px;width:100%}
.body>h1{margin-bottom:6px}
.body>h1+.sub{margin:0 0 22px;padding-bottom:18px;border-bottom:1px solid var(--ink-200)}

/* ---------- 卡片 ---------- */
.card{background:var(--s);border:1px solid var(--ink-200);border-radius:var(--r-lg);padding:18px 20px;
margin-bottom:16px;box-shadow:var(--sh-xs)}
.card>h3:first-child{font-size:13.5px;font-weight:600;color:var(--ink-900);padding-bottom:12px;
margin-bottom:14px;border-bottom:1px solid var(--ink-100);display:flex;align-items:center;gap:8px;flex-wrap:wrap}
.card>h3:first-child .sub{font-weight:400}
.card>.row:first-child>.h3,.card>div:first-child>h3{font-size:13.5px}
.card .sub+.row,.card .sub+table,.card .sub+form{margin-top:2px}
.card>h3+.sub:last-child{padding:20px 0 6px;text-align:center;color:var(--ink-400);font-size:12.5px}
.card.fill{display:flex;flex-direction:column}
.card.fill>.doc{flex:1;max-height:none}

/* ---------- 徽章 ---------- */
.pill{display:inline-flex;align-items:center;gap:4px;height:22px;padding:0 8px;border-radius:5px;
font-size:11.5px;font-weight:600;letter-spacing:.005em;white-space:nowrap;border:1px solid transparent;
vertical-align:middle;line-height:1}
.b{background:var(--brand-50);color:var(--brand-700);border-color:var(--brand-100)}
.g{background:var(--ok-50);color:var(--ok-700);border-color:var(--ok-line)}
.a{background:var(--wa-50);color:var(--wa-700);border-color:var(--wa-line)}
.r{background:var(--dg-50);color:var(--dg-700);border-color:var(--dg-line)}
.n{background:var(--ink-100);color:var(--ink-600);border-color:var(--ink-200)}

/* ---------- 表格 ---------- */
table{width:100%;border-collapse:separate;border-spacing:0;font-size:13px}
th{text-align:left;font-size:11.5px;font-weight:600;letter-spacing:.03em;color:var(--ink-500);
padding:10px 12px;border-top:1px solid var(--ink-200);border-bottom:1px solid var(--ink-200);
background:var(--ink-50);white-space:nowrap}
th:first-child{border-top-left-radius:var(--r);border-left:1px solid var(--ink-200)}
th:last-child{border-top-right-radius:var(--r);border-right:1px solid var(--ink-200)}
td{padding:12px;border-bottom:1px solid var(--ink-100);color:var(--ink-700);vertical-align:middle}
tbody tr:last-child td{border-bottom:1px solid var(--ink-200)}
tbody tr{transition:background .12s}
tbody tr:hover td{background:var(--ink-50)}
td:first-child{border-left:1px solid transparent}
td b{color:var(--ink-900);font-weight:600}
table .sub{font-size:11.5px;color:var(--ink-400);margin-top:1px}

/* ---------- 表单 ---------- */
form.inline{display:inline}
label{display:block;font-size:12.5px;font-weight:500;color:var(--ink-700);margin:14px 0 6px}
input,textarea,select{width:100%;height:36px;padding:0 11px;border:1px solid var(--ink-300);border-radius:var(--r);
font-size:13px;font-family:inherit;color:var(--ink-900);background:var(--s);box-shadow:var(--sh-xs);
transition:border-color .15s,box-shadow .15s;outline:none}
input::placeholder,textarea::placeholder{color:var(--ink-400)}
textarea{height:auto;min-height:84px;padding:9px 11px;line-height:1.65;resize:vertical}
input:hover,textarea:hover,select:hover{border-color:var(--ink-400)}
input:focus,textarea:focus,select:focus{border-color:var(--brand-600);box-shadow:var(--ring)}
input:disabled,textarea:disabled,select:disabled{background:var(--ink-50);color:var(--ink-400);cursor:not-allowed}
select{appearance:none;-webkit-appearance:none;padding-right:30px;cursor:pointer;
background-image:url("data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='16' height='16' viewBox='0 0 16 16' fill='none'%3E%3Cpath d='M4 6.25 8 10.25l4-4' stroke='%23667085' stroke-width='1.5' stroke-linecap='round' stroke-linejoin='round'/%3E%3C/svg%3E");
background-repeat:no-repeat;background-position:right 9px center}
input[type=file]{height:auto;padding:7px 10px;background:var(--ink-50);cursor:pointer;font-size:12.5px;
color:var(--ink-600);box-shadow:none}
input[type=file]::file-selector-button{margin-right:10px;height:26px;padding:0 10px;border-radius:6px;
border:1px solid var(--ink-300);background:var(--s);font-family:inherit;font-size:12px;color:var(--ink-700);cursor:pointer}
input[type=checkbox]{width:15px;height:15px;accent-color:var(--brand-600);cursor:pointer}
input[type=number]{font-variant-numeric:tabular-nums}

/* ---------- 按钮 ---------- */
button{display:inline-flex;align-items:center;justify-content:center;gap:6px;height:34px;padding:0 14px;
border-radius:var(--r);border:1px solid var(--ink-300);background:var(--s);color:var(--ink-700);
font-size:13px;font-weight:500;font-family:inherit;cursor:pointer;white-space:nowrap;box-shadow:var(--sh-xs);
transition:background .15s,border-color .15s,box-shadow .15s}
button:hover{background:var(--ink-50);border-color:var(--ink-400)}
button:focus-visible{outline:none;box-shadow:var(--ring)}
button:active{background:var(--ink-100)}
button.p{background:var(--brand-600);border-color:var(--brand-600);color:#fff;
box-shadow:0 1px 2px rgba(16,24,40,.14),inset 0 1px 0 rgba(255,255,255,.12)}
button.p:hover{background:var(--brand-700);border-color:var(--brand-700)}
button.p:active{background:#003399}
button.d{color:var(--dg-700);border-color:var(--dg-line);background:var(--s)}
button.d:hover{background:var(--dg-50);border-color:#FDA29B}
button.g{background:#079455;border-color:#079455;color:#fff}
button.g:hover{background:#067647}

/* ---------- 布局工具 ---------- */
.row{display:flex;gap:8px;flex-wrap:wrap;align-items:center}
.grid{display:grid;gap:14px}
.g4{grid-template-columns:repeat(4,1fr)}
.g3{grid-template-columns:repeat(3,1fr)}
.g2{grid-template-columns:1fr 1fr}
.flex1{flex:1}
.grid>.card{margin-bottom:0}

/* ---------- 统计卡 ---------- */
.stat{background:var(--s);border:1px solid var(--ink-200);border-radius:var(--r-lg);padding:16px 18px;
box-shadow:var(--sh-xs);position:relative}
.stat .k{display:block;font-size:12px;font-weight:500;color:var(--ink-500);letter-spacing:.005em}
.stat .v{display:block;font-size:28px;font-weight:600;letter-spacing:-.025em;line-height:1.22;
margin:7px 0 3px;font-variant-numeric:tabular-nums;color:var(--ink-900)}
.stat .k:last-child{font-size:11.5px;font-weight:400;color:var(--ink-400);line-height:1.5;margin-top:2px}

/* ---------- 入口卡 ---------- */
.entries{display:grid;grid-template-columns:repeat(auto-fit,minmax(250px,1fr));gap:12px}
.entry{display:flex;align-items:flex-start;gap:12px;padding:14px 16px;border:1px solid var(--ink-200);
border-radius:var(--r);background:var(--s);box-shadow:var(--sh-xs);transition:border-color .15s,box-shadow .15s;color:inherit}
.entry:hover{border-color:#84ADFF;box-shadow:0 0 0 3px rgba(15,98,254,.07),var(--sh-sm);color:inherit}
.entry .ic{width:34px;height:34px;flex:none;border-radius:9px;background:var(--brand-50);color:var(--brand-700);
border:1px solid var(--brand-100);display:grid;place-items:center}
.entry .ic svg{width:17px;height:17px}
.entry b{display:block;font-size:13px;font-weight:600;color:var(--ink-900);line-height:1.4}
.entry span{display:block;font-size:11.5px;line-height:1.55;color:var(--ink-500);margin-top:3px}
.entry .ar{margin-left:auto;align-self:center;color:var(--ink-300);flex:none}
.entry .ar svg{width:14px;height:14px}
.entry:hover .ar{color:var(--brand-600)}

/* ---------- 提示条 ---------- */
.note,.ok,.err{display:block;padding:12px 14px;border-radius:var(--r);font-size:12.5px;line-height:1.7;
border:1px solid;border-left-width:3px;margin:12px 0}
.note{background:var(--wa-50);border-color:var(--wa-line);border-left-color:#F79009;color:#7A2E0E}
.ok{background:var(--ok-50);border-color:var(--ok-line);border-left-color:#12B76A;color:#054F31}
.err{background:var(--dg-50);border-color:var(--dg-line);border-left-color:#F04438;color:#7A271A}
.note b,.ok b,.err b{font-weight:600}
.card>.note:last-child,.card>.ok:last-child,.card>.err:last-child{margin-bottom:0}

/* ---------- 业务片段 ---------- */
.quote{background:var(--ink-50);border-left:3px solid var(--brand-600);border-radius:0 var(--r) var(--r) 0;
padding:10px 12px;font-size:12.5px;line-height:1.75;color:var(--ink-600);margin-top:8px;white-space:pre-wrap}
.doc{background:var(--s);border:1px solid var(--ink-200);border-radius:var(--r);padding:18px 20px;
white-space:pre-wrap;font-size:13px;line-height:1.9;color:var(--ink-700);max-height:560px;overflow:auto;
box-shadow:inset 0 1px 2px rgba(16,24,40,.04)}
.audit{font-family:var(--mono);font-size:11.5px;line-height:1.7;max-height:440px;overflow:auto;
background:var(--ink-50);border:1px solid var(--ink-200);border-radius:var(--r);padding:6px 12px}
.audit div{border-bottom:1px solid var(--ink-100);padding:7px 0;display:flex;gap:7px;flex-wrap:wrap;align-items:baseline}
.audit div:last-child{border-bottom:none}
.audit b{color:var(--ink-800);font-weight:600}

/* ---------- 看板 ---------- */
.kb{display:grid;grid-template-columns:repeat(5,minmax(158px,1fr));gap:12px;overflow-x:auto;padding-bottom:2px}
.col{background:var(--ink-50);border:1px solid var(--ink-200);border-radius:var(--r);padding:10px;min-height:200px}
.col>b{display:flex;align-items:center;gap:6px;font-size:12px;font-weight:600;color:var(--ink-700);
padding-bottom:9px;border-bottom:1px solid var(--ink-200);margin-bottom:2px;white-space:nowrap}
.col>b em{margin-left:auto;font-style:normal;font-size:10.5px;font-weight:600;color:var(--ink-500);
background:var(--s);border:1px solid var(--ink-200);border-radius:999px;padding:0 6px;line-height:16px}
.col>.sub{font-size:11px;color:var(--ink-400);padding:4px 0 2px}
.ci{background:var(--s);border:1px solid var(--ink-200);border-left:3px solid transparent;border-radius:var(--r-sm);
padding:10px;margin-top:8px;font-size:12.5px;box-shadow:var(--sh-xs);transition:box-shadow .15s}
.ci:hover{box-shadow:var(--sh-sm)}
.ci b{font-size:12.5px;color:var(--ink-900);font-weight:600}
.ci.bl{border-left-color:var(--dg-700);background:#FFFCFC}
.ci .row{margin-top:6px;gap:6px}
.ci .pill{height:19px;font-size:10.5px;padding:0 6px}

/* ---------- 空状态 ---------- */
.empty{padding:36px 16px;text-align:center;color:var(--ink-400);font-size:12.5px}

/* ---------- 登录 / 右侧分栏 ---------- */
body.auth-body{background:var(--s)}
.auth{display:grid;grid-template-columns:1.05fr .95fr;min-height:100vh}
.auth-brand{position:relative;background:var(--ink-950);color:#fff;padding:52px 54px 36px;
display:flex;flex-direction:column;overflow:hidden}
.auth-brand::before{content:"";position:absolute;inset:0;
background-image:linear-gradient(rgba(255,255,255,.028) 1px,transparent 1px),linear-gradient(90deg,rgba(255,255,255,.028) 1px,transparent 1px);
background-size:44px 44px;pointer-events:none}
.auth-brand::after{content:"";position:absolute;right:-170px;bottom:-190px;width:460px;height:460px;border-radius:50%;
background:radial-gradient(circle,rgba(15,98,254,.3),transparent 66%);pointer-events:none}
.auth-brand>*{position:relative;z-index:1}
.auth-top{display:flex;align-items:center;gap:11px;margin-bottom:auto}
.auth-top .lg{width:34px;height:34px;border-radius:9px;background:var(--brand-600);display:grid;place-items:center;
box-shadow:0 1px 3px rgba(0,0,0,.35),inset 0 1px 0 rgba(255,255,255,.18)}
.auth-top .lg svg{width:19px;height:19px}
.auth-top b{display:block;font-size:14px;font-weight:600;color:#fff;line-height:1.3}
.auth-top span{display:block;font-size:9.5px;letter-spacing:.1em;text-transform:uppercase;color:var(--ink-400);margin-top:2px}
.auth-hero{margin:52px 0 0}
.auth-eyebrow{display:inline-flex;align-items:center;gap:6px;font-size:11px;font-weight:600;letter-spacing:.04em;
color:#84ADFF;background:rgba(15,98,254,.14);border:1px solid rgba(15,98,254,.3);border-radius:999px;
padding:4px 11px;margin-bottom:20px}
.auth-hero h1{font-size:32px;line-height:1.32;font-weight:600;letter-spacing:-.022em;color:#fff}
.auth-hero p{margin-top:14px;font-size:13.5px;line-height:1.75;color:#98A2B3;max-width:420px}
.auth-points{list-style:none;margin:34px 0 0;display:grid;gap:13px;max-width:430px}
.auth-points li{display:flex;gap:11px;font-size:12.5px;line-height:1.6;color:#C3CAD9}
.auth-points li i{flex:none;width:18px;height:18px;border-radius:50%;background:rgba(18,183,106,.14);
border:1px solid rgba(18,183,106,.32);display:grid;place-items:center;margin-top:1px}
.auth-points li i svg{width:11px;height:11px;stroke:#32D583}
.auth-points li b{color:#fff;font-weight:600}
.auth-foot{margin-top:auto;padding-top:44px;font-size:10.5px;letter-spacing:.03em;color:#475467}
.auth-form{display:flex;align-items:center;justify-content:center;padding:44px 40px}
.auth-card{width:100%;max-width:392px}
.auth-card>h2{font-size:23px;font-weight:600;letter-spacing:-.015em}
.auth-card>.sub{margin:7px 0 26px}
.auth-card .err{margin:0 0 18px}
.auth-card form>button[type=submit],.auth-card form button.p{width:100%;height:40px;margin-top:22px;font-size:13.5px}
.auth-demo{margin-top:26px;padding-top:20px;border-top:1px solid var(--ink-200)}
.auth-demo>span{display:block;font-size:10.5px;font-weight:600;letter-spacing:.07em;
color:var(--ink-400);margin-bottom:10px}
.auth-demo table{font-size:12px}
.auth-demo th{background:transparent;border:none;padding:0 0 7px;font-size:10.5px;color:var(--ink-400);letter-spacing:.04em}
.auth-demo td{border:none;padding:4px 0;font-size:12px;color:var(--ink-600)}
.auth-demo code{font-family:var(--mono);font-size:11.5px;color:var(--ink-900);background:var(--ink-100);
padding:1.5px 6px;border-radius:5px}
.auth-note{margin-top:16px;font-size:11px;line-height:1.6;color:var(--ink-400)}

/* ---------- 居中页（403/404） ---------- */
.plain{min-height:100vh;display:grid;place-items:center;padding:40px}
.plain-inner{width:min(520px,100%)}
.plain .card{padding:26px 28px}
.plain h1{font-size:20px;margin-bottom:8px}
.plain .sub{margin-bottom:14px}

/* ---------- 响应式 ---------- */
@media(max-width:1180px){
.body{padding:22px 20px 52px}
.kb{grid-template-columns:repeat(3,minmax(170px,1fr))}
}
@media(max-width:960px){
:root{--nav-w:64px}
.brand{padding:18px 0;justify-content:center}
.brand>div,.nav-title,.u>div,.scope,.u .out{display:none}
.nav{padding:12px 10px}
.nav a{justify-content:center;padding:10px 0}
.nav a span{display:none}
.nav a.on::before{left:-10px}
.side-foot{padding:10px}
.u{justify-content:center;padding:8px 0}
.top{padding:0 16px}
.g4{grid-template-columns:repeat(2,1fr)}
.g3{grid-template-columns:1fr}
.g2{grid-template-columns:1fr}
.auth{grid-template-columns:1fr}
.auth-brand{display:none}
}
`;

/* ---------- 导航图标（16px 线性，Carbon 风格） ---------- */
const ICONS = {
  dash: '<rect x="2.5" y="2.5" width="4.6" height="4.6" rx="1.2"/><rect x="8.9" y="2.5" width="4.6" height="4.6" rx="1.2"/><rect x="2.5" y="8.9" width="4.6" height="4.6" rx="1.2"/><rect x="8.9" y="8.9" width="4.6" height="4.6" rx="1.2"/>',
  doc: '<path d="M9 2.5H4.6A1.6 1.6 0 0 0 3 4.1v7.8a1.6 1.6 0 0 0 1.6 1.6h6.8A1.6 1.6 0 0 0 13 11.9V6.5z"/><path d="M9 2.5v4h4"/><path d="M5.6 9.2h4.8M5.6 11.6h3"/>',
  check: '<path d="M6.2 2.6h3.6a.9.9 0 0 1 .9.9v.6h1.1A1.5 1.5 0 0 1 13.3 5.6v7.3a1.5 1.5 0 0 1-1.5 1.5H4.2a1.5 1.5 0 0 1-1.5-1.5V5.6a1.5 1.5 0 0 1 1.5-1.5h1.1v-.6a.9.9 0 0 1 .9-.9Z"/><path d="M5.7 8.5 7.1 10l3.3-3.3"/>',
  user: '<circle cx="8" cy="5.6" r="2.6"/><path d="M3.1 13.4c0-2.2 2.2-3.4 4.9-3.4s4.9 1.2 4.9 3.4"/>',
  upload: '<path d="M8 10.6V2.9"/><path d="M5.1 5.8 8 2.9l2.9 2.9"/><path d="M3 9.9v2.4a1.6 1.6 0 0 0 1.6 1.6h6.8A1.6 1.6 0 0 0 13 12.3V9.9"/>',
  clock: '<circle cx="8" cy="8" r="5.6"/><path d="M8 4.6V8l2.4 1.5"/>',
  swap: '<path d="M2.9 5.5h9.2"/><path d="M9.5 2.9 12.1 5.5 9.5 8.1"/><path d="M13.1 10.5H3.9"/><path d="M6.5 7.9 3.9 10.5 6.5 13.1"/>',
  board: '<rect x="2.5" y="2.5" width="11" height="11" rx="1.6"/><path d="M6.1 2.5v11M9.9 2.5v11"/>',
  bell: '<path d="M6.2 12.6a1.8 1.8 0 0 0 3.6 0"/><path d="M8 2.6c1.9 0 3.1 1.5 3.1 3.4 0 2.2.5 3.3 1.2 4.1H3.7c.7-.8 1.2-1.9 1.2-4.1C4.9 4.1 6.1 2.6 8 2.6Z"/>',
  list: '<path d="M5.7 4.1h7.5M5.7 8h7.5M5.7 11.9h7.5"/><circle cx="2.9" cy="4.1" r=".95" fill="currentColor" stroke="none"/><circle cx="2.9" cy="8" r=".95" fill="currentColor" stroke="none"/><circle cx="2.9" cy="11.9" r=".95" fill="currentColor" stroke="none"/>',
  db: '<ellipse cx="8" cy="4.2" rx="4.9" ry="1.9"/><path d="M3.1 4.2v7.6c0 1.05 2.2 1.9 4.9 1.9s4.9-.85 4.9-1.9V4.2"/><path d="M3.1 8c0 1.05 2.2 1.9 4.9 1.9s4.9-.85 4.9-1.9"/>',
  sliders: '<path d="M2.9 5.1h6.2M12.2 5.1h.9M2.9 10.9h.9M7 10.9h6.1"/><circle cx="10.6" cy="5.1" r="1.6"/><circle cx="5.4" cy="10.9" r="1.6"/>',
  out: '<path d="M9.6 2.9H4.4a1.5 1.5 0 0 0-1.5 1.5v7.2a1.5 1.5 0 0 0 1.5 1.5h5.2"/><path d="M10.4 8h4.3"/><path d="M12.3 5.7 14.7 8l-2.4 2.3"/>',
  tick: '<path d="M2.6 8.4 6.1 11.9 13.4 4.6"/>',
  spark: '<path d="M8 2.2v3.1M8 10.7v3.1M2.2 8h3.1M10.7 8h3.1"/><circle cx="8" cy="8" r="2.1"/>',
  lock: '<rect x="3.1" y="6.8" width="9.8" height="6.6" rx="1.5"/><path d="M5.4 6.8V5.1a2.6 2.6 0 0 1 5.2 0v1.7"/>',
  layers: '<path d="M8 2.4 2.6 5.2 8 8l5.4-2.8z"/><path d="M2.6 8.2 8 11l5.4-2.8"/><path d="M2.6 11.1 8 13.9l5.4-2.8"/>',
  chev: '<path d="M6 3.5 10.5 8 6 12.5"/>',
};

export const svg = (k, cls = '') =>
  `<svg class="${cls}" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${ICONS[k] || ''}</svg>`;

const NAV = {
  yr: [['/dashboard', '总览', 'dash'], ['/jobs', 'P1 岗位需求', 'doc'], ['/dept', 'P5 推荐与反馈', 'check']],
  zy: [['/dashboard', '总览', 'dash'], ['/upload', 'P3 简历上传', 'upload'], ['/check', 'P4 核对与推荐', 'check'], ['/track', 'P6 进度与结果', 'clock']],
  jl: [['/dashboard', '总览', 'dash'], ['/assign', 'P2 岗位分配', 'swap'], ['/board', 'P7 流程看板', 'board'], ['/reminders', 'P8 提醒中心', 'bell'], ['/audit', 'P9 留痕统计', 'list'], ['/config/biz', 'P12 业务规则', 'sliders']],
  sys: [['/dashboard', '总览', 'dash'], ['/users', 'P10 账号与角色', 'user'], ['/data', 'P11 数据治理', 'db'], ['/config/sys', 'P13 系统参数', 'sliders']],
};

const DATA_SCOPE = {
  yr: '本人提出的岗位',
  zy: '本人负责岗位',
  jl: '全部岗位业务数据',
  sys: '账号 / 参数 / 数据 / 审计',
};

function flashBlock(msg, err) {
  return (msg ? `<div class="ok">${esc(msg)}</div>` : '') + (err ? `<div class="err">${esc(err)}</div>` : '');
}

const LOGO = '<span class="lg">' + svg('layers') + '</span>';

function sideBar(user, active) {
  const nav = NAV[user.role] || [];
  const links = nav
    .map(([href, label, ic]) => `<a href="${href}" class="${active === href ? 'on' : ''}" title="${esc(label)}">${svg(ic)}<span>${esc(label)}</span></a>`)
    .join('');
  const initial = String(user.name || '?').slice(0, 1);
  return `<aside class="side">
  <div class="brand">${LOGO}<div><b>星禾数智</b><span>Talent Platform</span></div></div>
  <nav class="nav" aria-label="主导航"><div class="nav-title">工作台</div>${links}</nav>
  <div class="side-foot">
    <div class="u"><div class="av">${esc(initial)}</div>
      <div><b>${esc(user.name)}</b><span>${esc(ROLE_NAME[user.role])} · ${esc(LEVEL[user.role])}</span></div>
      <a class="out" href="/logout" title="退出登录" aria-label="退出登录">${svg('out')}</a></div>
    <div class="scope"><b>数据范围</b>：${esc(DATA_SCOPE[user.role] || '')}</div>
  </div>
</aside>`;
}

function topBar(user, active, title) {
  const nav = NAV[user.role] || [];
  const cur = nav.find(([href]) => href === active);
  const crumb = `<span>工作台</span><i>/</i><b>${esc(cur ? cur[1] : title)}</b>`;
  const initial = String(user.name || '?').slice(0, 1);
  return `<header class="top">
  <div class="crumb">${crumb}</div>
  <span class="seal"><i></i>v2.0 生产环境</span>
  <div class="spacer"></div>
  <div class="who"><span>${esc(initial)}</span><b>${esc(user.name)}</b><span class="lv">${esc(LEVEL[user.role])}</span></div>
  <a class="hlink" href="/health" title="服务健康检查">/health</a>
</header>`;
}

export function layout({ user, title, body, active = '', msg = '', err = '', shell = '' }) {
  const mode = shell || (user ? 'app' : 'plain');
  const head = `<!doctype html><html lang="zh-CN"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="color-scheme" content="light">
<title>${esc(title)} · AI 辅助招聘平台</title><style>${CSS}</style></head>`;

  if (mode === 'auth') {
    return `${head}<body class="auth-body">${body}</body></html>`;
  }
  if (mode === 'plain') {
    return `${head}<body><div class="plain"><div class="plain-inner">${flashBlock(msg, err)}${body}</div></div></body></html>`;
  }
  return `${head}<body>
<div class="wrap">
  ${sideBar(user, active)}
  <main class="main">
    ${topBar(user, active, title)}
    <div class="body">${flashBlock(msg, err)}${body}</div>
  </main>
</div></body></html>`;
}

export function q(req) {
  const u = new URL(req.url, 'http://x');
  return u.searchParams;
}
