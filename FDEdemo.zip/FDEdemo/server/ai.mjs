// AI 分析：真实调用大模型（OpenAI 兼容），服务端校验证据并计算参考分
// 密钥仅从本机 .env / 环境变量读取，绝不写入源码、页面或报告。
import { readFileSync, existsSync } from 'node:fs';
import { analyzeResumeDemo } from './demo-ai.mjs';

function loadEnv() {
  const out = { ...process.env };
  if (existsSync('.env')) {
    for (const line of readFileSync('.env', 'utf8').split('\n')) {
      const i = line.indexOf('=');
      if (i > 0 && !line.trim().startsWith('#')) out[line.slice(0, i).trim()] = line.slice(i + 1).trim();
    }
  }
  return out;
}
const ENV = loadEnv();
// 便于验证降级路径：DISABLE_LLM=1 时强制走人工对照
if (process.env.DISABLE_LLM === '1') ENV.LLM_API_KEY = '';
export const AI_CONFIGURED = !!(ENV.LLM_API_KEY && ENV.LLM_BASE_URL && ENV.LLM_MODEL);
export const AI_MODEL = ENV.LLM_MODEL || '';

/* 没有密钥时是否启用本地演示引擎（默认开启，便于无 Key 演示）。
   DEMO_AI=0 可关闭，恢复"AI 不可用 → 转人工对照、不给分数"的严格路径。 */
export const DEMO_AI_ENABLED = process.env.DEMO_AI !== '0';

/* 面向页面的脱敏视图：只给"是否配置 / 服务地址 / 模型名 / 密钥尾号"，绝不下发完整密钥 */
const KEY_MASK = (k) => (k ? `${k.slice(0, 3)}···${k.slice(-4)}` : '未配置');
const HOST_OF = (u) => { try { return new URL(u).host; } catch { return u || '未配置'; } };
export const AI_INFO = {
  configured: AI_CONFIGURED,
  baseUrl: ENV.LLM_BASE_URL || '',
  baseHost: HOST_OF(ENV.LLM_BASE_URL),
  model: AI_MODEL || '未配置',
  keyMasked: KEY_MASK(ENV.LLM_API_KEY),
  keyPresent: !!ENV.LLM_API_KEY,
  source: existsSync('.env') ? '.env 文件' : '环境变量',
  protocol: 'OpenAI 兼容 /chat/completions',
  timeoutMs: 30000,
};

/* ---------- 评测用裁判模型 ----------
   与业务模型分开配置：JUDGE_* 缺省时回退到 LLM_*。
   评测纪律要求裁判模型 ≠ 被评模型，否则通过率会虚高（见 eval/rubric.md）。
   密钥同样只做脱敏展示，绝不下发完整值。 */
const JUDGE_BASE_URL = ENV.JUDGE_BASE_URL || ENV.LLM_BASE_URL || '';
const JUDGE_MODEL = ENV.JUDGE_MODEL || '';
const JUDGE_API_KEY = ENV.JUDGE_API_KEY || ENV.LLM_API_KEY || '';
const JUDGE_CONFIGURED = !!(JUDGE_BASE_URL && JUDGE_MODEL && JUDGE_API_KEY);
const JUDGE_SAME_AS_TARGET = JUDGE_CONFIGURED && JUDGE_MODEL === AI_MODEL;

export const JUDGE_INFO = {
  configured: JUDGE_CONFIGURED,
  baseUrl: JUDGE_BASE_URL,
  baseHost: HOST_OF(JUDGE_BASE_URL),
  model: JUDGE_MODEL || '未配置',
  keyMasked: KEY_MASK(JUDGE_API_KEY),
  keyShared: !ENV.JUDGE_API_KEY && !!ENV.LLM_API_KEY,
  sameAsTarget: JUDGE_SAME_AS_TARGET,
  targetModel: AI_MODEL || '未配置',
  source: existsSync('.env') ? '.env 文件' : '环境变量',
  protocol: 'OpenAI 兼容 /chat/completions',
  dataset: 'eval/dataset.jsonl',
};

const COND = (c) => c.replace(/\s+/g, '');
const condense = (s) => String(s).replace(/\s+/g, '').replace(/[，。；：、,.;:!?！？（）()【】\[\]"'“”‘’]/g, '');

function prompt(items, resume) {
  const list = items.map((it, i) => `${i + 1}. [${it.type === 'must' ? '必备' : '加分'}] ${it.content}`).join('\n');
  return `你是招聘简历核对助手。请严格依据给定条件逐条对照简历原文，只输出 JSON，不要输出解释。
要求：
1) 每条条件给一个结论，只能是"匹配"、"信息不足"、"不符合"三者之一；
2) 结论为"匹配"或"不符合"时，必须在 resumeQuote 中原文摘录简历里的对应句子（逐字复制，不要改写、不要拼接）；
3) 简历未提及该条件时，结论必须是"信息不足"，resumeQuote 写空字符串；
4) 不得因为条件未满足就给出淘汰建议；不得编造简历中没有的内容。

条件：
${list}

简历原文：
"""
${resume}
"""

输出格式：
{"items":[{"index":1,"conclusion":"匹配","resumeQuote":"原文句子","toVerify":"需要向候选人核实的问题"}]}`;
}

export async function analyzeResume({ items, resume }) {
  if (!AI_CONFIGURED) {
    // 未配置模型：默认走本地演示引擎，保证没有 API Key 的机器也能演示完整闭环。
    // 演示结果 status='demo'，与真实模型结果在页面上明确区分。
    if (DEMO_AI_ENABLED) return analyzeResumeDemo({ items, resume });
    return { ok: false, reason: '未配置模型（缺少 LLM_API_KEY/LLM_BASE_URL/LLM_MODEL）', mode: 'unconfigured' };
  }
  const url = ENV.LLM_BASE_URL.replace(/\/$/, '') + '/chat/completions';
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 30000);
  const started = Date.now();
  let raw = '';
  try {
    const resp = await fetch(url, {
      method: 'POST',
      signal: controller.signal,
      headers: { 'content-type': 'application/json', authorization: 'Bearer ' + ENV.LLM_API_KEY },
      body: JSON.stringify({
        model: ENV.LLM_MODEL,
        temperature: 0,
        stream: false,
        messages: [
          { role: 'system', content: '你是严谨的招聘核对助手，只输出 JSON。' },
          { role: 'user', content: prompt(items, resume) },
        ],
      }),
    });
    raw = await resp.text();
    if (!resp.ok) return { ok: false, reason: `模型返回 ${resp.status}`, mode: 'error', raw: raw.slice(0, 200) };
  } catch (e) {
    return { ok: false, reason: '模型调用超时或网络失败：' + (e.name || e.message), mode: 'error' };
  } finally {
    clearTimeout(timer);
  }

  let content = '';
  try {
    const j = JSON.parse(raw);
    content = j.choices?.[0]?.message?.content ?? '';
  } catch {
    return { ok: false, reason: '模型响应不是合法 JSON', mode: 'error' };
  }
  const parsed = extractJson(content);
  if (!parsed || !Array.isArray(parsed.items)) return { ok: false, reason: '模型未按约定返回 items', mode: 'error', raw: content.slice(0, 200) };

  const resumeC = condense(resume);
  const results = [];
  let dropped = 0;
  for (let i = 0; i < items.length; i++) {
    const it = items[i];
    const got = parsed.items.find((x) => Number(x.index) === i + 1) || parsed.items[i] || {};
    let conclusion = String(got.conclusion || '').trim();
    if (!['匹配', '信息不足', '不符合'].includes(conclusion)) conclusion = '信息不足';
    const quote = String(got.resumeQuote || '').trim();
    let valid = conclusion === '信息不足' ? true : quote.length > 0 && resumeC.includes(condense(quote));
    if (conclusion === '信息不足' && quote && !resumeC.includes(condense(quote))) {
      // 信息不足场景允许空引用；有引用但定位不到则视为无效引用
      valid = false;
    }
    if (!valid) {
      dropped++;
      results.push({ ...it, conclusion: '信息不足', quote: '', to_verify: '模型结论缺少可定位的原文引用，已降级为待人工核对', dropped: true });
    } else {
      results.push({ ...it, conclusion, quote, to_verify: String(got.toVerify || '') || '需人工核实' });
    }
  }
  const tw = items.reduce((s, x) => s + x.weight, 0) || 100;
  const got = results.reduce((s, x) => s + (x.conclusion === '匹配' ? x.weight : x.conclusion === '信息不足' ? x.weight * 0.4 : 0), 0);
  return {
    ok: true,
    items: results,
    score: Math.min(100, Math.round((got / tw) * 100)),
    status: dropped ? 'degraded' : 'ok',
    dropped,
    ms: Date.now() - started,
    model: ENV.LLM_MODEL,
  };
}

function extractJson(text) {
  const s = String(text).trim().replace(/^```(?:json)?/i, '').replace(/```$/, '');
  try { return JSON.parse(s); } catch {}
  const a = s.indexOf('{');
  const b = s.lastIndexOf('}');
  if (a >= 0 && b > a) { try { return JSON.parse(s.slice(a, b + 1)); } catch {} }
  return null;
}

/* 连通性自检：只发一次极短请求，用于"模型设置"页的现场验证 */
export async function pingLLM() {
  return pingEndpoint({
    configured: AI_CONFIGURED,
    baseUrl: ENV.LLM_BASE_URL,
    apiKey: ENV.LLM_API_KEY,
    model: ENV.LLM_MODEL,
    missingHint: '未配置 LLM_API_KEY / LLM_BASE_URL / LLM_MODEL，当前以人工对照模式运行',
  });
}

/* 裁判模型自检：独立入口，便于在配置页分别验证两个角色 */
export async function pingJudge() {
  return pingEndpoint({
    configured: JUDGE_CONFIGURED,
    baseUrl: JUDGE_BASE_URL,
    apiKey: JUDGE_API_KEY,
    model: JUDGE_MODEL,
    missingHint: '未配置 JUDGE_MODEL（裁判模型），AI 质量评测不可用；业务分析不受影响',
  });
}

async function pingEndpoint({ configured, baseUrl, apiKey, model, missingHint }) {
  if (!configured) {
    return { ok: false, mode: 'unconfigured', reason: missingHint };
  }
  const url = String(baseUrl).replace(/\/$/, '') + '/chat/completions';
  const ctl = new AbortController();
  const timer = setTimeout(() => ctl.abort(), 15000);
  const started = Date.now();
  try {
    const resp = await fetch(url, {
      method: 'POST',
      signal: ctl.signal,
      headers: { 'content-type': 'application/json', authorization: 'Bearer ' + apiKey },
      body: JSON.stringify({
        model,
        temperature: 0,
        max_tokens: 16,
        stream: false,
        messages: [{ role: 'user', content: '请只回复：ok' }],
      }),
    });
    const txt = await resp.text();
    const ms = Date.now() - started;
    if (!resp.ok) {
      const brief = txt.replace(/\s+/g, ' ').slice(0, 180);
      return { ok: false, mode: 'error', status: resp.status, ms, reason: `模型返回 ${resp.status}：${brief}` };
    }
    let reply = '';
    let gotModel = model;
    try {
      const j = JSON.parse(txt);
      reply = String(j.choices?.[0]?.message?.content ?? '').trim().slice(0, 40);
      gotModel = j.model || gotModel;
    } catch { /* 非 JSON 也视为连通 */ }
    return { ok: true, mode: 'ok', ms, model: gotModel, reply: reply || '（空响应）', at: new Date().toISOString() };
  } catch (e) {
    return { ok: false, mode: 'error', ms: Date.now() - started, reason: '连接失败：' + (e.name === 'AbortError' ? '15s 超时' : e.message) };
  } finally {
    clearTimeout(timer);
  }
}
