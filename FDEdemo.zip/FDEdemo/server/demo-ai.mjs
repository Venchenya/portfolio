// 离线演示引擎：没有 API Key 时使用的本地兜底实现
//
// 目的：让一台没配模型的机器（HR、面试官、clone 下来的人）也能走完
//       「上传简历 → 逐项对照 → 人工核对 → 推荐」的完整闭环。
//
// 边界（必须在页面上诚实标注，不能冒充大模型）：
//   1) 只做字面匹配：关键片段命中率 + 年限规则 + 少量同义词，没有语义推理；
//   2) 引用一律从简历原文截取，绝不生成原文里没有的句子；
//   3) 结果 status = 'demo'，页面显示「演示引擎」，参考分仅作流程演示。
//
// 与 ai.mjs 的契约完全一致：{ ok, items, score, status, dropped, ms, model }

const PUNCT = /[\s，。；：、,.;:!?！？（）()【】\[\]"'“”‘’·—\-/|]/g;

// 只起连接作用、不携带条件信息的片段（去掉后剩下的才是"要匹配的东西"）
const NOISE = new Set([
  '以上', '以下', '优先', '具备', '具有', '拥有', '能够', '相关', '良好', '一定',
  '经验', '能力', '要求', '熟悉', '掌握', '精通', '负责', '主导', '参与', '完成',
  '工作', '项目', '进行', '以及', '或者', '并且', '至少', '不少于',
]);
const NOISE_CHAR = /[的了和与或及在对为把被而等中上下个条项份是很更最也都就还并则如若其之此该]/;

// 极简同义词/相关词表：只在"字面不同但业务上等价"时补一刀，避免演示结果过于保守
const SYNONYMS = [
  ['数据可视化', ['图表', '看板', '可视化', 'echarts']],
  ['可视化', ['图表', '看板', 'echarts']],
  ['组件库', ['组件', '图表引擎', '引擎', '自研']],
  ['前端', ['react', 'vue', 'typescript', 'javascript', 'web']],
  ['中大型', ['平台', '系统', '团队', '日活']],
  ['性能', ['首屏', '加载', '优化']],
  ['团队管理', ['负责人', '团队', '带人']],
  ['后端', ['java', 'go', 'node', '服务端']],
];

const norm = (s) => String(s).toLowerCase().replace(PUNCT, '');
const cjkOnly = (s) => String(s).replace(/[^\u4e00-\u9fa5]/g, '');

/* 从一条招聘条件里抽取"要匹配的东西"：英文技术词、中文双字片段、同义扩展、年限门槛 */
function keywordsOf(cond) {
  const n = norm(cond);
  const kws = new Set();
  const strong = new Set();

  for (const m of n.match(/[a-z][a-z0-9+.#]{1,}/g) || []) {
    if (!NOISE.has(m)) {
      kws.add(m);
      strong.add(m);
    }
  }

  const cn = cjkOnly(n);
  for (let i = 0; i + 2 <= cn.length; i++) {
    const g = cn.slice(i, i + 2);
    if (NOISE.has(g)) continue;
    if (NOISE_CHAR.test(g[0]) || NOISE_CHAR.test(g[1])) continue;
    kws.add(g);
  }

  for (const [key, words] of SYNONYMS) {
    if (n.includes(key) || cn.includes(key)) for (const w of words) strong.add(w);
  }

  const years = Number((String(cond).match(/(\d+)\s*年/) || [])[1] || 0);
  return { kws: [...kws], strong: [...strong], years };
}

/* 简历切句：保留原文，供引用使用（引用必须是原文连续子串） */
function sentencesOf(resume) {
  return String(resume)
    .split(/\n+|[。；;!?！？]/)
    .map((s) => s.trim())
    .filter((s) => norm(s).length >= 6 && !/^【.*】$/.test(s));
}

function maxYearsIn(text) {
  let max = 0;
  for (const m of String(text).matchAll(/(\d+(?:\.\d+)?)\s*年/g)) max = Math.max(max, Number(m[1]));
  return max;
}

const clipQuote = (s, max = 120) => {
  const t = String(s).trim();
  return t.length > max ? t.slice(0, max) : t;
};

const padToVerify = (cond) => `简历未直接体现，请向候选人核实：${String(cond).trim().replace(/[。；;,，]$/, '')}`;

/* 单句与单个条件的贴合度：强信号词 32% + 字面覆盖 45% + 年限 45%（上限 1）
   年限不单独判定整句：只有当这句本身带年限或带强信号词时，才把"经验够不够"算进来，
   避免"简历写了 8 年"就让所有条件一起过线。 */
function scoreSentence(sent, { kws, strong, years }, resumeYears) {
  const ns = norm(sent);
  const hit = kws.length ? kws.filter((k) => ns.includes(k)).length / kws.length : 0;
  const strongHit = strong.length ? strong.some((w) => ns.includes(w)) : false;
  const hasYear = /\d+\s*年/.test(sent);
  const yearEnough = years > 0 && resumeYears >= years;

  // 年限只在"这句已经命中实质内容"时才计分：
  // 否则「3 年以上团队管理经验」会被「6 年经验」这句话误判为匹配。
  const substantive = strongHit || hit >= 0.2;
  const yearBonus = yearEnough && substantive ? (hasYear ? 0.45 : 0.3) : yearEnough && hasYear ? 0.1 : 0;

  const signal = yearBonus + 0.32 * (strongHit ? 1 : 0) + 0.45 * hit;
  return { signal: Math.min(1, signal), strongHit, yearEnough };
}

/**
 * @param {{items: Array<{content:string,type:'must'|'plus',weight:number}>, resume: string}} input
 */
export function analyzeResumeDemo({ items, resume }) {
  const started = Date.now();
  const sents = sentencesOf(resume);
  const resumeYears = maxYearsIn(resume);

  const results = items.map((it) => {
    const spec = keywordsOf(it.content);
    let best = { sent: '', signal: 0 };

    for (const s of sents) {
      const got = scoreSentence(s, spec, resumeYears);
      // 同分时取更短的句子：更聚焦、更像"证据"
      if (got.signal > best.signal || (got.signal === best.signal && got.signal > 0 && s.length < best.sent.length)) {
        best = { sent: s, signal: got.signal };
      }
    }

    if (best.signal < 0.42) {
      return { ...it, conclusion: '信息不足', quote: '', to_verify: padToVerify(it.content), demo: true };
    }
    return {
      ...it,
      conclusion: '匹配',
      quote: clipQuote(best.sent),
      to_verify: '请面试时确认该经历的深度与本人贡献',
      demo: true,
    };
  });

  const tw = items.reduce((s, x) => s + Number(x.weight || 0), 0) || 100;
  const got = results.reduce(
    (s, x) => s + (x.conclusion === '匹配' ? Number(x.weight) : x.conclusion === '信息不足' ? Number(x.weight) * 0.4 : 0),
    0,
  );

  return {
    ok: true,
    items: results,
    score: Math.min(100, Math.round((got / tw) * 100)),
    status: 'demo',
    dropped: results.filter((x) => x.conclusion === '信息不足').length,
    ms: Date.now() - started,
    model: '本地演示引擎 v1（未接入大模型）',
    demo: true,
  };
}
