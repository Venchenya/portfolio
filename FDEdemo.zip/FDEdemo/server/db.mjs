// 数据库层：node:sqlite（Node 22 内置，零依赖）
// 说明：生产目标为 PostgreSQL 16（见 design.md / ADR-001 C4）；本地无 Docker/PG，
// 因此开发档使用 SQLite，SQL 保持可移植子集，迁移到 PG 时需替换自增与时间函数。
import { DatabaseSync } from 'node:sqlite';
import { scryptSync, randomBytes, timingSafeEqual } from 'node:crypto';
import { mkdirSync } from 'node:fs';
import { dirname, resolve } from 'node:path';

const DB_PATH = process.env.DB_PATH || resolve('data/app.db');
mkdirSync(dirname(DB_PATH), { recursive: true });

export const db = new DatabaseSync(DB_PATH);
db.exec('PRAGMA journal_mode = WAL;');
db.exec('PRAGMA foreign_keys = ON;');

export function hashPassword(pwd) {
  const salt = randomBytes(16).toString('hex');
  const hash = scryptSync(pwd, salt, 64).toString('hex');
  return `${salt}:${hash}`;
}
export function verifyPassword(pwd, stored) {
  const [salt, hash] = String(stored).split(':');
  if (!salt || !hash) return false;
  const calc = scryptSync(pwd, salt, 64);
  const orig = Buffer.from(hash, 'hex');
  return calc.length === orig.length && timingSafeEqual(calc, orig);
}

const SCHEMA = `
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  login TEXT NOT NULL UNIQUE,
  pwd TEXT NOT NULL,
  role TEXT NOT NULL CHECK(role IN ('yr','zy','jl','sys')),
  dept TEXT,
  status TEXT NOT NULL DEFAULT 'active',
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS sessions (
  token TEXT PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id),
  expires_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS jobs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  code TEXT NOT NULL UNIQUE,
  title TEXT NOT NULL,
  dept TEXT,
  duty TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'draft',  -- draft/confirmed/screening/closed
  owner_yr INTEGER NOT NULL REFERENCES users(id),
  owner_zy INTEGER REFERENCES users(id),
  version INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS job_items (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  job_id INTEGER NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
  type TEXT NOT NULL CHECK(type IN ('must','plus')),
  content TEXT NOT NULL,
  weight INTEGER NOT NULL,
  source TEXT NOT NULL DEFAULT 'job'
);
CREATE TABLE IF NOT EXISTS applications (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  job_id INTEGER NOT NULL REFERENCES jobs(id),
  name TEXT NOT NULL,
  contact TEXT,
  stage TEXT NOT NULL,
  status TEXT NOT NULL,           -- 待核对/已核对/已推荐/面试中/待入职/已入职/已终止
  owner_zy INTEGER REFERENCES users(id),
  version INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL,
  uploaded_by INTEGER,
  checked_at TEXT,
  handle_hours REAL,
  wait_hours REAL,
  hired_at TEXT,
  outdated INTEGER NOT NULL DEFAULT 0,
  UNIQUE(job_id, name)
);
CREATE TABLE IF NOT EXISTS resume_versions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  app_id INTEGER NOT NULL REFERENCES applications(id) ON DELETE CASCADE,
  version_no INTEGER NOT NULL,
  file_name TEXT,
  text TEXT NOT NULL,
  created_by INTEGER,
  created_at TEXT NOT NULL,
  UNIQUE(app_id, version_no)
);
CREATE TABLE IF NOT EXISTS analyses (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  app_id INTEGER NOT NULL REFERENCES applications(id) ON DELETE CASCADE,
  rv_id INTEGER NOT NULL REFERENCES resume_versions(id),
  score INTEGER,
  model TEXT,
  status TEXT NOT NULL,           -- ok/degraded/failed
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS analysis_items (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  analysis_id INTEGER NOT NULL REFERENCES analyses(id) ON DELETE CASCADE,
  cond TEXT NOT NULL,
  type TEXT NOT NULL,
  weight INTEGER NOT NULL,
  conclusion TEXT NOT NULL,       -- 匹配/信息不足/不符合
  quote TEXT,
  to_verify TEXT,
  source TEXT NOT NULL DEFAULT 'ai', -- ai/human_added
  edited INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS recommendations (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  app_id INTEGER NOT NULL REFERENCES applications(id) ON DELETE CASCADE,
  reason TEXT NOT NULL,
  gap TEXT,
  to_verify TEXT,
  status TEXT NOT NULL,           -- active/delete_pending/deleted
  submitted_at TEXT NOT NULL,
  deleted_at TEXT,
  deleted_reason TEXT,
  delete_requested_by INTEGER,
  delete_decided_by INTEGER
);
CREATE TABLE IF NOT EXISTS feedback (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  app_id INTEGER NOT NULL UNIQUE REFERENCES applications(id) ON DELETE CASCADE,
  result TEXT NOT NULL,           -- 同意面试/要求补充/不面试
  reason TEXT,
  created_at TEXT NOT NULL,
  created_by INTEGER
);
CREATE TABLE IF NOT EXISTS status_logs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  app_id INTEGER NOT NULL REFERENCES applications(id) ON DELETE CASCADE,
  from_status TEXT,
  to_status TEXT NOT NULL,
  operator INTEGER,
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS reminders (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  type TEXT NOT NULL,             -- ① ② ③
  job_id INTEGER,
  app_id INTEGER,
  text TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'open', -- open/handled/ignored
  dedupe_key TEXT NOT NULL,
  created_at TEXT NOT NULL,
  handled_at TEXT,
  handle_note TEXT
);
CREATE INDEX IF NOT EXISTS idx_rem_dedupe ON reminders(dedupe_key, status);
CREATE TABLE IF NOT EXISTS audit_logs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  at TEXT NOT NULL,
  actor_id INTEGER,
  actor TEXT NOT NULL,
  role TEXT NOT NULL,
  action TEXT NOT NULL,
  obj_type TEXT,
  obj_id TEXT,
  meta TEXT
);
CREATE TABLE IF NOT EXISTS configs (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL,
  scope TEXT NOT NULL,            -- biz/sys
  updated_by INTEGER,
  updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS access_requests (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  admin_id INTEGER NOT NULL,
  reason TEXT NOT NULL,
  status TEXT NOT NULL,           -- pending/approved/rejected
  approver_id INTEGER,
  expires_at INTEGER,
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS weight_changes (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  app_id INTEGER NOT NULL,
  item_id INTEGER NOT NULL,
  old_w INTEGER NOT NULL,
  new_w INTEGER NOT NULL,
  reason TEXT NOT NULL,
  actor_id INTEGER,
  created_at TEXT NOT NULL
);
`;

export function nowIso() {
  const d = new Date();
  const p = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}:${p(d.getSeconds())}`;
}

export function migrate() {
  db.exec(SCHEMA);
}

export function seed() {
  const count = db.prepare('SELECT COUNT(*) c FROM users').get().c;
  if (count > 0) return;
  const pwd = hashPassword('Passw0rd!');
  const ins = db.prepare('INSERT INTO users (name, login, pwd, role, dept, created_at) VALUES (?,?,?,?,?,?)');
  const t = nowIso();
  ins.run('李强', 'liqiang', pwd, 'yr', '数据产品部', t);
  ins.run('王敏', 'wangmin', pwd, 'zy', '人力资源部', t);
  ins.run('张伟', 'zhangwei', pwd, 'jl', '人力资源部', t);
  ins.run('管理员', 'admin', pwd, 'sys', '信息技术部', t);
  ins.run('陈立', 'chenli', pwd, 'zy', '人力资源部', t);

  const cfg = db.prepare('INSERT INTO configs (key, value, scope, updated_at) VALUES (?,?,?,?)');
  const defaults = [
    ['sla_hours', '24', 'biz'],
    ['auto_timeout', 'false', 'biz'],
    ['channel', '站内信+每日邮件', 'biz'],
    ['dedupe', 'true', 'biz'],
    ['split_reminders', 'true', 'biz'],
    ['email_digest', 'on', 'biz'],
    ['delete_requires_approval', 'true', 'biz'],
    ['weight_strict_on_check', 'false', 'biz'],
    ['mask_contact', 'true', 'sys'],
    ['retention', '永久（待确认）', 'sys'],
    ['export_approval', 'true', 'sys'],
    ['session_hours', '8', 'sys'],
    ['model_version', 'deepseek-flash', 'sys'],
    ['prompt_version', 'v1', 'sys'],
  ];
  for (const [k, v, s] of defaults) cfg.run(k, v, s, t);

  // 演示数据：一个已确认岗位 + 两位候选人（无分析，需真实调用 AI）
  const j = db
    .prepare('INSERT INTO jobs (code,title,dept,duty,status,owner_yr,owner_zy,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?)')
    .run('JR-101', '高级前端工程师', '数据产品部',
      '负责公司数据产品前端研发，承担可视化组件库建设与性能治理，与后端、算法协作推进功能上线。',
      'screening', 1, 2, t, t);
  const jobId = Number(j.lastInsertRowid);
  const items = [
    ['must', '5 年以上前端研发经验，主导过中大型 Web 项目', 40],
    ['must', '精通 TypeScript 与 React 技术栈', 30],
    ['must', '具备复杂数据可视化落地经验', 20],
    ['plus', '有组件库从 0 到 1 建设经验', 10],
  ];
  const itemIns = db.prepare('INSERT INTO job_items (job_id,type,content,weight) VALUES (?,?,?,?)');
  for (const [tp, c, w] of items) itemIns.run(jobId, tp, c, w);

  const a = db
    .prepare('INSERT INTO applications (job_id,name,contact,stage,status,owner_zy,created_at,uploaded_by) VALUES (?,?,?,?,?,?,?,?)')
    .run(jobId, '陈皓', '13800001111', '简历初筛', '待核对', 2, t, 2);
  const appId = Number(a.lastInsertRowid);
  const text = `陈皓
前端工程师 / 8 年经验

【工作经历】
2019.03 - 至今 某科技公司 前端负责人
· 主导数据看板平台研发，团队 8 人，日活 5 万
· 推进 React 16 到 18 版本升级，首屏从 4.2s 降至 1.6s
· 技术栈：TypeScript、React、Next.js、Redux
2016.07 - 2019.02 某互联网公司 前端工程师
· 基于 ECharts 自研图表引擎，覆盖 40+ 图表类型

【教育】
2012 - 2016 某大学 计算机科学与技术 本科`;
  db.prepare('INSERT INTO resume_versions (app_id,version_no,file_name,text,created_by,created_at) VALUES (?,?,?,?,?,?)')
    .run(appId, 1, 'chenhao.txt', text, 2, t);
  db.prepare('INSERT INTO status_logs (app_id,from_status,to_status,operator,created_at) VALUES (?,?,?,?,?)')
    .run(appId, null, '待核对', 2, t);
}

export function audit(actor, role, action, objType = '', objId = '', meta = '') {
  db.prepare('INSERT INTO audit_logs (at,actor_id,actor,role,action,obj_type,obj_id,meta) VALUES (?,?,?,?,?,?,?,?)')
    .run(nowIso(), actor?.id ?? null, actor ? actor.name : '系统', role || (actor?.role ?? 'sys'), action, objType, String(objId), meta);
}

export function getConfig(key) {
  const r = db.prepare('SELECT value FROM configs WHERE key=?').get(key);
  return r ? r.value : null;
}
export function setConfig(key, value, userId) {
  db.prepare('UPDATE configs SET value=?, updated_by=?, updated_at=? WHERE key=?').run(String(value), userId, nowIso(), key);
}
