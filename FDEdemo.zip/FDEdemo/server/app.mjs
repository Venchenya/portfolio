// AI 辅助招聘平台 MVP：零依赖 Node HTTP 服务（SSR）
// 依据：PRD v2.0 / 原型 v2.0 / openspec change build-recruitment-platform / ADR-001
import http from 'node:http';
import { readFileSync, readdirSync } from 'node:fs';
import { db, migrate, seed, audit, nowIso, hashPassword, verifyPassword } from './db.mjs';
import {
  HttpError, layout, esc, parseForm, currentUser, createSession, destroySession,
  requireRole, ROLE_NAME, LEVEL, ownedJobs, canSeeApp, assertCanSeeApp, q, svg,
} from './lib.mjs';
import { analyzeResume, AI_CONFIGURED, AI_MODEL, AI_INFO, JUDGE_INFO, DEMO_AI_ENABLED, pingLLM, pingJudge } from './ai.mjs';
import { extractPdfText } from './pdf.mjs';

migrate();
seed();

const PORT = Number(process.env.PORT || 3000);
const APP_MODE = AI_CONFIGURED ? '真实模型' : DEMO_AI_ENABLED ? '演示引擎' : '模拟/未配置';
const SLA = () => Number(db.prepare("SELECT value FROM configs WHERE key='sla_hours'").get()?.value || 24);
const CFG = (k) => db.prepare('SELECT value FROM configs WHERE key=?').get(k)?.value;

const hoursSince = (iso) => (iso ? (Date.now() - new Date(iso.replace(' ', 'T')).getTime()) / 36e5 : 0);
const hTxt = (h) => (h >= 24 ? (h / 24).toFixed(1) + ' 天' : h < 1 ? Math.max(1, Math.round(h * 60)) + ' 分钟' : h.toFixed(1) + ' 小时');

function send(res, status, body, headers = {}) {
  res.writeHead(status, { 'content-type': 'text/html; charset=utf-8', ...headers });
  res.end(body);
}
function json(res, obj, status = 200) {
  res.writeHead(status, { 'content-type': 'application/json; charset=utf-8' });
  res.end(JSON.stringify(obj, null, 2));
}
function redirect(res, to, msg, err) {
  const u = new URL(to, 'http://x');
  if (msg) u.searchParams.set('msg', msg);
  if (err) u.searchParams.set('err', err);
  res.writeHead(302, { location: u.pathname + (u.search || '') });
  res.end();
}

/* ---------- 领域辅助 ---------- */
function nextStage(status) {
  return ({ 待核对: '简历初筛', 已核对: '简历初筛', 已推荐: '部门对接', 面试中: '面试推进', 待入职: '入职推进', 已入职: '入职推进' }[status]) || '简历初筛';
}
function addReminder(type, jobId, appId, text) {
  const dedupe = `${type}:${jobId}:${appId}`;
  const open = db.prepare("SELECT id FROM reminders WHERE dedupe_key=? AND status='open'").get(dedupe);
  if (open && CFG('dedupe') !== 'false') return null;
  const r = db.prepare('INSERT INTO reminders (type,job_id,app_id,text,status,dedupe_key,created_at) VALUES (?,?,?,?,?,?,?)')
    .run(type, jobId, appId, text, 'open', dedupe + ':' + Date.now(), nowIso());
  audit({ id: null, name: '系统', role: 'sys' }, 'sys', `触发提醒${type}：${text}`, 'reminder', r.lastInsertRowid);
  return r;
}
function logStatus(appId, from, to, operator) {
  db.prepare('INSERT INTO status_logs (app_id,from_status,to_status,operator,created_at) VALUES (?,?,?,?,?)')
    .run(appId, from, to, operator?.id ?? null, nowIso());
}
function latestAnalysis(appId) {
  return db.prepare('SELECT * FROM analyses WHERE app_id=? ORDER BY id DESC LIMIT 1').get(appId);
}
function itemsOf(analysisId) {
  return db.prepare('SELECT * FROM analysis_items WHERE analysis_id=? ORDER BY id').all(analysisId);
}
function recalc(analysisId) {
  const items = itemsOf(analysisId);
  const tw = items.reduce((s, x) => s + x.weight, 0) || 100;
  const got = items.reduce((s, x) => s + (x.conclusion === '匹配' ? x.weight : x.conclusion === '信息不足' ? x.weight * 0.4 : 0), 0);
  const score = Math.min(100, Math.round((got / tw) * 100));
  db.prepare('UPDATE analyses SET score=? WHERE id=?').run(score, analysisId);
  return score;
}
function appRow(id) {
  return db.prepare(`SELECT a.*, j.title AS job_title, j.owner_yr, j.code AS job_code,
    u.name AS owner_name FROM applications a JOIN jobs j ON j.id=a.job_id
    LEFT JOIN users u ON u.id=a.owner_zy WHERE a.id=?`).get(id);
}
const BADGE = (s) => ({
  待核对: 'n', 已核对: 'b', 已推荐: 'b', 面试中: 'b', 待入职: 'a', 已入职: 'g', 已终止: 'r',
  draft: 'n', confirmed: 'a', screening: 'b', closed: 'g', pending: 'a', approved: 'g', rejected: 'r', delete_pending: 'a', deleted: 'r', active: 'b',
}[s] || 'n');
const JOB_ST = { draft: '草稿', confirmed: '已确认', screening: '筛选中', closed: '已结束' };

/* ---------- 页面片段 ---------- */
function flash(req) {
  return { msg: q(req).get('msg') || '', err: q(req).get('err') || '' };
}
function page(req, user, title, active, body) {
  const { msg, err } = flash(req);
  return layout({ user, title, active, body, msg, err });
}
function stat(k, v, d = '') {
  return `<div class="stat"><div class="k">${esc(k)}</div><div class="v">${esc(v)}</div><div class="k">${esc(d)}</div></div>`;
}

/* ---------- 路由 ---------- */
const routes = [];
const route = (method, pattern, roles, handler) => routes.push({ method, pattern, roles, handler });

route('GET', /^\/health$/, null, async (req, res) => {
  json(res, { ok: true, mode: APP_MODE, model: AI_CONFIGURED ? AI_MODEL : null, demo: !AI_CONFIGURED && DEMO_AI_ENABLED, time: nowIso(), db: 'sqlite' });
});

route('GET', /^\/login$/, null, async (req, res) => {
  const u = currentUser(req);
  if (u) return redirect(res, '/dashboard');
  const { err } = flash(req);
  const point = (t, d) => `<li><i>${svg('tick')}</i><div><b>${t}</b>：${d}</div></li>`;
  send(res, 200, layout({
    user: null, title: '登录', shell: 'auth', body: `
  <div class="auth">
    <section class="auth-brand">
      <div class="auth-top">
        <span class="lg">${svg('layers')}</span>
        <div><b>星禾数智</b><span>Talent Intelligence Platform</span></div>
      </div>
      <div class="auth-hero">
        <span class="auth-eyebrow">AI 辅助招聘 · v2.0</span>
        <h1>让每一次筛选<br>都有据可依</h1>
        <p>AI 只提供证据，决策始终由人做出。四类角色各司其职，三级授权逐层收敛，全流程操作留痕可审计。</p>
        <ul class="auth-points">
          ${point('AI 出证据', '每条结论必须附简历原文引用，引用无法定位即降级为「信息不足」')}
          ${point('职责不重叠', 'P1–P13 每个页面唯一归属一个角色，越权访问即时拦截并写入留痕')}
          ${point('分级授权', 'L1 岗位级 / L2 管理级 / L3 系统级，管理员默认看不到候选人材料')}
        </ul>
      </div>
      <div class="auth-foot">星禾数智 · AI 辅助招聘平台 v2.0 · 内部演示环境</div>
    </section>
    <section class="auth-form">
      <div class="auth-card">
        <h2>登录工作台</h2>
        <p class="sub">使用企业账号登录，账号由系统管理员在 P10 统一发放。</p>
        ${err ? `<div class="err">${esc(err)}</div>` : ''}
        <form method="post" action="/login">
          <label>登录名</label><input name="login" autocomplete="username" required placeholder="如 liqiang" autofocus>
          <label>密码</label><input name="password" type="password" autocomplete="current-password" required placeholder="请输入密码">
          <button class="p" type="submit">登录</button>
        </form>
        <div class="auth-demo">
          <span>演示账号 · 密码均为 Passw0rd!</span>
          <table>
            <thead><tr><th>账号</th><th>姓名</th><th>角色</th><th>层级</th></tr></thead>
            <tbody>
              <tr><td><code>liqiang</code></td><td>李强</td><td>用人经理</td><td>L1</td></tr>
              <tr><td><code>wangmin</code></td><td>王敏</td><td>招聘专员</td><td>L1</td></tr>
              <tr><td><code>zhangwei</code></td><td>张伟</td><td>招聘经理</td><td>L2</td></tr>
              <tr><td><code>admin</code></td><td>管理员</td><td>系统管理员</td><td>L3</td></tr>
            </tbody>
          </table>
        </div>
        <p class="auth-note">首次登录强制改密尚未实现；演示环境请勿录入真实个人信息。</p>
      </div>
    </section>
  </div>`,
  }));
});

route('POST', /^\/login$/, null, async (req, res) => {
  const f = await parseForm(req);
  const u = db.prepare('SELECT * FROM users WHERE login=?').get(String(f.login || '').trim());
  if (!u || !verifyPassword(String(f.password || ''), u.pwd)) return redirect(res, '/login', null, '登录名或密码错误');
  if (u.status !== 'active') return redirect(res, '/login', null, '账号已停用');
  const token = createSession(u.id);
  audit(u, u.role, '登录成功', 'user', u.id);
  res.writeHead(302, { location: '/dashboard', 'set-cookie': `sid=${token}; HttpOnly; Path=/; SameSite=Lax; Max-Age=28800` });
  res.end();
});

route('GET', /^\/logout$/, null, async (req, res) => {
  destroySession(req);
  res.writeHead(302, { location: '/login', 'set-cookie': 'sid=; Path=/; Max-Age=0' });
  res.end();
});

route('GET', /^\/dashboard$/, ['yr', 'zy', 'jl', 'sys'], async (req, res, user) => {
  const entry = (href, ic, t, d) =>
    `<a class="entry" href="${href}"><span class="ic">${svg(ic)}</span><div><b>${esc(t)}</b><span>${esc(d)}</span></div><span class="ar">${svg('chev')}</span></a>`;
  const entries = (list) => `<div class="entries">${list.join('')}</div>`;
  let body = '';

  if (user.role === 'yr') {
    const my = ownedJobs(user);
    const ids = my.map((j) => j.id);
    const ph = ids.map(() => '?').join(',');
    const q1 = (sql) => (ids.length ? db.prepare(sql).get(...ids).c : 0);
    const recs = q1(`SELECT COUNT(*) c FROM applications WHERE job_id IN (${ph}) AND status='已推荐'`);
    const doing = q1(`SELECT COUNT(*) c FROM applications WHERE job_id IN (${ph}) AND status NOT IN ('已终止','已入职')`);
    const hired = q1(`SELECT COUNT(*) c FROM applications WHERE job_id IN (${ph}) AND status='已入职'`);
    body = `<h1>我的待办</h1><div class="sub">${LEVEL[user.role]} · 数据范围：本人提出的岗位 · 只提出需求与接收推荐，不参与前期筛选</div>
      <div class="grid g4">${stat('我的岗位', my.length, '本部门在册岗位')}${stat('待我反馈', recs, '专员已推荐，等你结论')}${stat('进行中', doing, '面试与入职推进中')}${stat('已入职', hired, '已核实实际入职')}</div>
      <div class="card"><h3>快捷入口</h3>${entries([
        entry('/jobs', 'doc', 'P1 岗位需求', '提出、确认与关闭本部门岗位需求'),
        entry('/dept', 'check', 'P5 推荐与反馈', '查看推荐材料，给出是否面试的结论'),
      ])}</div>`;
  } else if (user.role === 'zy') {
    const mine = db.prepare('SELECT COUNT(*) c FROM applications WHERE owner_zy=?').get(user.id).c;
    const todo = db.prepare("SELECT COUNT(*) c FROM applications WHERE owner_zy=? AND status='待核对'").get(user.id).c;
    const track = db.prepare("SELECT COUNT(*) c FROM applications WHERE owner_zy=? AND status IN ('面试中','待入职')").get(user.id).c;
    const hired = db.prepare("SELECT COUNT(*) c FROM applications WHERE owner_zy=? AND status='已入职'").get(user.id).c;
    body = `<h1>我的待办</h1><div class="sub">${LEVEL[user.role]} · 数据范围：本人负责岗位 · 一岗一主责，转交后原专员立即失权</div>
      <div class="grid g4">${stat('我的候选人', mine, '名下在册简历')}${stat('待核对', todo, 'AI 已出证据，待你确认')}${stat('待登记结果', track, '面试中与待入职')}${stat('已入职', hired, '累计入职')}</div>
      <div class="card"><h3>快捷入口</h3>${entries([
        entry('/upload', 'upload', 'P3 简历上传', '上传简历并调用 AI 逐条对照'),
        entry('/check', 'check', 'P4 核对与推荐', '修正 AI 结论，决定是否推荐'),
        entry('/track', 'clock', 'P6 进度与结果', '登记面试结果与实际入职'),
      ])}</div>`;
  } else if (user.role === 'jl') {
    const open = db.prepare("SELECT COUNT(*) c FROM reminders WHERE status='open'").get().c;
    const blocked = db.prepare("SELECT COUNT(*) c FROM applications WHERE status='已推荐'").get().c;
    const unassigned = db.prepare("SELECT COUNT(*) c FROM jobs WHERE owner_zy IS NULL AND status!='closed'").get().c;
    const active = db.prepare("SELECT COUNT(*) c FROM jobs WHERE status!='closed'").get().c;
    body = `<h1>管理视图</h1><div class="sub">${LEVEL[user.role]} · 数据范围：全部岗位业务数据 · 负责分派、监控、催办与业务口径</div>
      <div class="grid g4">${stat('在招岗位', active, '未结束的岗位')}${stat('未分配岗位', unassigned, '需指定唯一主责专员')}${stat('待处理提醒', open, '超时或待闭环')}${stat('等部门反馈', blocked, '已推荐待用人经理回复')}</div>
      <div class="card"><h3>快捷入口</h3>${entries([
        entry('/assign', 'swap', 'P2 岗位分配', '为一岗指定唯一主责专员'),
        entry('/board', 'board', 'P7 流程看板', '五阶段停留时长与卡点'),
        entry('/reminders', 'bell', 'P8 提醒中心', '闭环处理与双人复核审批'),
        entry('/audit', 'list', 'P9 留痕统计', '操作留痕与四项指标'),
        entry('/config/biz', 'sliders', 'P12 业务规则', '阈值、渠道、去重与审批开关'),
      ])}</div>`;
  } else {
    body = `<h1>系统视图</h1><div class="sub">${LEVEL[user.role]} · 数据范围：账号 / 参数 / 数据 / 审计 · 默认不可查看候选人材料</div>
      <div class="grid g4">${stat('账号数', db.prepare('SELECT COUNT(*) c FROM users').get().c, '含停用账号')}${stat('停用账号', db.prepare("SELECT COUNT(*) c FROM users WHERE status='disabled'").get().c, '即时失效会话')}${stat('留痕条数', db.prepare('SELECT COUNT(*) c FROM audit_logs').get().c, '追加式，不可修改')}${stat('岗位 / 候选人', db.prepare('SELECT COUNT(*) c FROM jobs').get().c + ' / ' + db.prepare('SELECT COUNT(*) c FROM applications').get().c, '仅计数，不含内容')}</div>
      <div class="card"><h3>快捷入口</h3>${entries([
        entry('/users', 'user', 'P10 账号与角色', '创建账号、变更角色、停用'),
        entry('/data', 'db', 'P11 数据治理', '导出、清理与全量审计'),
        entry('/config/sys', 'sliders', 'P13 系统参数', '大模型接入、脱敏与留痕'),
      ])}</div>`;
  }
  const llmHint = user.role === 'sys'
    ? ` · <a href="/config/sys">查看大模型设置</a>`
    : ' · 模型接入由系统管理员在 P13 维护';
  body += `<div class="card"><h3>能力与限制</h3><div class="note">模型状态：<b>${esc(APP_MODE)}</b>${AI_CONFIGURED ? `（${esc(AI_INFO.model)} @ ${esc(AI_INFO.baseHost)}）` : ''}${llmHint}；${AI_CONFIGURED ? '' : '未配置 API Key 时由本地演示引擎做字面匹配，结果标注「演示」，不代表大模型能力；'}PDF 仅解析文字层，扫描件需改传文本；邮件汇总尚未接入（模拟）；当前为 SQLite 开发档，生产按 ADR-001 切 PostgreSQL。</div></div>`;
  send(res, 200, page(req, user, '总览', '/dashboard', body));
});

/* ---------- P1 岗位需求 ---------- */
route('GET', /^\/jobs$/, ['yr'], async (req, res, user) => {
  const jobs = ownedJobs(user);
  const rows = jobs.map((j) => {
    const n = db.prepare('SELECT COUNT(*) c FROM applications WHERE job_id=?').get(j.id).c;
    return `<tr><td><b>${esc(j.title)}</b><div class="sub">${esc(j.code)} · v${j.version}</div></td>
      <td><span class="pill ${BADGE(j.status)}">${JOB_ST[j.status]}</span></td>
      <td>${n}</td><td>${esc(j.dept || '')}</td>
      <td>${j.status !== 'closed' ? `<form class="inline" method="post" action="/jobs/${j.id}/close" onsubmit="return confirm('确认关闭该需求？')"><button class="d">关闭需求</button></form>` : '<span class="sub">已结束</span>'}</td></tr>`;
  }).join('');
  send(res, 200, page(req, user, 'P1 岗位需求', '/jobs', `
    <h1>P1 岗位需求</h1><div class="sub">唯一归属：用人经理 · 提交后专员侧可见条件与权重</div>
    <div class="card"><h3>新建需求</h3>
      <div class="sub">必备条件至少 1 条；权重合计必须 = 100；每行格式 <span class="mono">条件描述|权重</span></div>
      <form method="post" action="/jobs">
        <label>岗位名称 *</label><input name="title" required>
        <label>用人部门</label><input name="dept" value="数据产品部">
        <label>岗位职责 *</label><textarea name="duty" required placeholder="写清这个岗位实际做什么，不要直接套行业模板"></textarea>
        <label>必备条件 *（每行一条）</label><textarea name="must" required>5 年以上前端研发经验，主导过中大型 Web 项目|40
精通 TypeScript 与 React 技术栈|30
具备复杂数据可视化落地经验|20</textarea>
        <label>加分项（每行一条，可空）</label><textarea name="plus">有组件库从 0 到 1 建设经验|10</textarea>
        <div class="row" style="margin-top:12px"><button class="p" name="action" value="confirm">提交并确认</button><button name="action" value="draft">存为草稿</button></div>
      </form></div>
    <div class="card"><h3>我的岗位（${jobs.length}）</h3><table><thead><tr><th>岗位</th><th>状态</th><th>候选人</th><th>部门</th><th>操作</th></tr></thead><tbody>${rows || '<tr><td colspan="5" class="sub">暂无</td></tr>'}</tbody></table></div>`));
});

route('POST', /^\/jobs$/, ['yr'], async (req, res, user) => {
  const f = await parseForm(req);
  const parseItems = (raw, type) => String(raw || '').split('\n').map((l) => l.trim()).filter(Boolean).map((l) => {
    const [c, w] = l.split('|');
    return { type, content: (c || '').trim(), weight: Number((w || '0').trim()) || 0 };
  });
  const must = parseItems(f.must, 'must');
  const plus = parseItems(f.plus, 'plus');
  const title = String(f.title || '').trim();
  const duty = String(f.duty || '').trim();
  const sum = [...must, ...plus].reduce((s, x) => s + x.weight, 0);
  if (!title || !duty) return redirect(res, '/jobs', null, '岗位名称与职责不能为空');
  if (!must.filter((x) => x.content).length) return redirect(res, '/jobs', null, '必备条件至少 1 条');
  if (f.action !== 'draft' && sum !== 100) return redirect(res, '/jobs', null, `权重合计须为 100，当前 ${sum}`);
  const t = nowIso();
  const code = 'JR-' + Date.now().toString().slice(-6);
  const r = db.prepare('INSERT INTO jobs (code,title,dept,duty,status,owner_yr,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?)')
    .run(code, title, String(f.dept || ''), duty, f.action === 'draft' ? 'draft' : 'confirmed', user.id, t, t);
  const jobId = Number(r.lastInsertRowid);
  const ins = db.prepare('INSERT INTO job_items (job_id,type,content,weight) VALUES (?,?,?,?)');
  [...must, ...plus].filter((x) => x.content).forEach((x) => ins.run(jobId, x.type, x.content, x.weight));
  audit(user, user.role, (f.action === 'draft' ? '创建草稿需求：' : '创建并确认需求：') + title, 'job', jobId);
  redirect(res, '/jobs', f.action === 'draft' ? '已存草稿' : '需求已确认，等待招聘经理分配专员');
});

route('POST', /^\/jobs\/(\d+)\/close$/, ['yr'], async (req, res, user, id) => {
  const job = db.prepare('SELECT * FROM jobs WHERE id=?').get(Number(id));
  if (!job) return redirect(res, '/jobs', null, '岗位不存在');
  if (job.owner_yr !== user.id) return redirect(res, '/jobs', null, '仅需求提出人可关闭');
  db.prepare("UPDATE jobs SET status='closed', updated_at=? WHERE id=?").run(nowIso(), job.id);
  audit(user, user.role, '关闭需求：' + job.title, 'job', job.id);
  redirect(res, '/jobs', '需求已关闭');
});

/* ---------- P2 分配 ---------- */
route('GET', /^\/assign$/, ['jl'], async (req, res, user) => {
  const jobs = db.prepare(`SELECT j.*, u.name zy_name FROM jobs j LEFT JOIN users u ON u.id=j.owner_zy ORDER BY j.id DESC`).all();
  const zys = db.prepare("SELECT * FROM users WHERE role='zy' AND status='active'").all();
  const opts = zys.map((z) => `<option value="${z.id}">${esc(z.name)}</option>`).join('');
  const rows = jobs.map((j) => `<tr><td><b>${esc(j.title)}</b><div class="sub">${esc(j.code)}</div></td>
    <td><span class="pill ${BADGE(j.status)}">${JOB_ST[j.status]}</span></td>
    <td>${esc(j.zy_name || '未分配')}</td>
    <td>${j.status !== 'closed' ? `<form class="inline row" method="post" action="/assign/${j.id}"><select name="zy" style="width:130px">${opts}</select><button class="p">${j.owner_zy ? '转交' : '分配'}</button></form>` : '<span class="sub">已结束</span>'}</td></tr>`).join('');
  send(res, 200, page(req, user, 'P2 岗位分配', '/assign', `
    <h1>P2 岗位分配</h1><div class="sub">唯一归属：招聘经理 · 一岗一主责，转交会留痕且原专员立即失权</div>
    <div class="card"><table><thead><tr><th>岗位</th><th>状态</th><th>负责专员</th><th>操作</th></tr></thead><tbody>${rows}</tbody></table></div>
    <div class="note">决策：C3 一岗一主责 + 经理转交；不做多人同时编辑同一候选人。</div>`));
});

route('POST', /^\/assign\/(\d+)$/, ['jl'], async (req, res, user, id) => {
  const f = await parseForm(req);
  const job = db.prepare('SELECT * FROM jobs WHERE id=?').get(Number(id));
  if (!job) return redirect(res, '/assign', null, '岗位不存在');
  const zy = Number(f.zy);
  const target = db.prepare("SELECT * FROM users WHERE id=? AND role='zy' AND status='active'").get(zy);
  if (!target) return redirect(res, '/assign', null, '专员无效');
  const old = job.owner_zy;
  db.prepare('UPDATE jobs SET owner_zy=?, status=CASE WHEN status=\'confirmed\' THEN \'screening\' ELSE status END, updated_at=? WHERE id=?').run(zy, nowIso(), job.id);
  db.prepare('UPDATE applications SET owner_zy=? WHERE job_id=?').run(zy, job.id);
  audit(user, user.role, `分配负责专员：${old ? (db.prepare('SELECT name FROM users WHERE id=?').get(old)?.name + ' → ') : ''}${target.name}`, 'job', job.id);
  redirect(res, '/assign', '已分配：' + target.name);
});

/* ---------- P3 上传 ---------- */
route('GET', /^\/upload$/, ['zy'], async (req, res, user) => {
  const jobs = ownedJobs(user).filter((j) => ['confirmed', 'screening'].includes(j.status));
  if (!jobs.length) return send(res, 200, page(req, user, 'P3 简历上传', '/upload', `<h1>P3 简历上传</h1><div class="card"><div class="note">暂无你负责的岗位，请让招聘经理在 P2 分配。</div></div>`));
  const sorted = [...jobs].sort((a, b) => b.id - a.id);
  const sel = sorted.map((j) => `<option value="${j.id}">${esc(j.title)}（${esc(j.code)}）</option>`).join('');
  send(res, 200, page(req, user, 'P3 简历上传', '/upload', `
    <h1>P3 简历上传与 AI 分析</h1><div class="sub">唯一归属：招聘专员 · PDF 仅解析文字层，扫描件请改用文本</div>
    <div class="card"><h3>新增简历</h3>
      <form method="post" action="/upload" enctype="multipart/form-data">
        <label>岗位</label><select name="jobId">${sel}</select>
        <label>候选人姓名 *</label><input name="name" required>
        <label>上传文件（.txt/.md/.pdf）</label><input type="file" name="file" accept=".txt,.md,.pdf">
        <label>或直接粘贴简历文本 *</label><textarea name="text" style="min-height:160px" placeholder="粘贴简历正文，含工作年限、技术栈、项目经历…"></textarea>
        <div class="row" style="margin-top:10px"><button class="p" name="go" value="1">上传并分析</button></div>
      </form>
      <div class="note">AI 状态：<b>${esc(APP_MODE)}</b>${AI_CONFIGURED ? `（模型 ${esc(AI_INFO.model)}）` : DEMO_AI_ENABLED ? '（本地演示引擎：只做字面匹配并引用原文，结果标注「演示」）' : '（未配置模型时将以"人工对照模式"入库，不产生虚假分数）'}</div>
    </div>`));
});

route('POST', /^\/upload$/, ['zy'], async (req, res, user) => {
  const f = await parseForm(req);
  const job = db.prepare('SELECT * FROM jobs WHERE id=?').get(Number(f.jobId));
  if (!job || job.owner_zy !== user.id) return redirect(res, '/upload', null, '岗位不存在或不在你名下');
  if (job.status === 'closed') return redirect(res, '/upload', null, '该岗位已结束，不可新增简历');
  const name = String(f.name || '').trim();
  if (!name) return redirect(res, '/upload', null, '姓名必填');

  let text = String(f.text || '').trim();
  let fileName = '';
  const file = f.file__file;
  if (file && file.filename) {
    fileName = file.filename;
    if (/\.(txt|md)$/i.test(fileName)) {
      text = file.data.toString('utf8').trim();
    } else if (/\.pdf$/i.test(fileName)) {
      const parsed = extractPdfText(file.data);
      if (!parsed) return redirect(res, '/upload', null, 'PDF 未检测到文字层（可能是扫描件），请改传文本版或人工录入');
      text = parsed;
    } else {
      return redirect(res, '/upload', null, '仅支持 PDF / txt / md');
    }
  }
  if (text.replace(/\s/g, '').length < 20) return redirect(res, '/upload', null, '简历内容过短，请确认已粘贴正文');

  const t = nowIso();
  let app = db.prepare('SELECT * FROM applications WHERE job_id=? AND name=?').get(job.id, name);
  let verNo = 1;
  let dupNote = '';
  if (app) {
    verNo = db.prepare('SELECT MAX(version_no) m FROM resume_versions WHERE app_id=?').get(app.id).m + 1;
    db.prepare('UPDATE applications SET version=?, status=?, outdated=0 WHERE id=?').run(verNo, '待核对', app.id);
    dupNote = `已生成新版本 v${verNo}（疑似重复仅提示，不自动合并，旧版本与旧分析保留）`;
  } else {
    const r = db.prepare('INSERT INTO applications (job_id,name,stage,status,owner_zy,created_at,uploaded_by) VALUES (?,?,?,?,?,?,?)')
      .run(job.id, name, '简历初筛', '待核对', job.owner_zy, t, user.id);
    app = { id: Number(r.lastInsertRowid) };
  }
  const rv = db.prepare('INSERT INTO resume_versions (app_id,version_no,file_name,text,created_by,created_at) VALUES (?,?,?,?,?,?)')
    .run(app.id, verNo, fileName || (name + '.txt'), text, user.id, t);
  logStatus(app.id, null, '待核对', user);
  audit(user, user.role, `上传简历 ${name}（v${verNo}）`, 'application', app.id);

  // 立即分析
  const jobItems = db.prepare('SELECT * FROM job_items WHERE job_id=? ORDER BY id').all(job.id);
  const ai = await analyzeResume({ items: jobItems.map((x) => ({ ...x, content: x.content, weight: x.weight, type: x.type })), resume: text });
  const m = db.prepare('INSERT INTO analyses (app_id,rv_id,score,model,status,created_at) VALUES (?,?,?,?,?,?)');
  if (ai.ok) {
    const an = m.run(app.id, Number(rv.lastInsertRowid), ai.score, ai.model, ai.status, nowIso());
    const insI = db.prepare('INSERT INTO analysis_items (analysis_id,cond,type,weight,conclusion,quote,to_verify,source) VALUES (?,?,?,?,?,?,?,?)');
    ai.items.forEach((it) => insI.run(Number(an.lastInsertRowid), it.content, it.type, it.weight, it.conclusion, it.quote, it.to_verify, 'ai'));
    audit(user, user.role, `${ai.demo ? '演示引擎' : 'AI'} 分析完成：${name}，参考分 ${ai.score}${ai.dropped ? `，${ai.dropped} 条因缺少引用被降级` : ''}`, 'application', app.id);
    redirect(res, '/check/' + app.id, (dupNote ? dupNote + '；' : '') + (ai.demo ? `演示引擎完成对照（未接大模型），参考分 ${ai.score}` : `AI 分析完成，参考分 ${ai.score}`));
  } else {
    // 降级：生成人工对照骨架（结论待人工填写，不给分数）
    const an = m.run(app.id, Number(rv.lastInsertRowid), null, AI_MODEL || '未接入', 'degraded', nowIso());
    const insI = db.prepare('INSERT INTO analysis_items (analysis_id,cond,type,weight,conclusion,quote,to_verify,source) VALUES (?,?,?,?,?,?,?,?)');
    jobItems.forEach((it) => insI.run(Number(an.lastInsertRowid), it.content, it.type, it.weight, '信息不足', '', 'AI 不可用，请人工判断', 'ai'));
    audit(user, user.role, `AI 不可用转人工对照：${name}（${ai.reason}）`, 'application', app.id);
    redirect(res, '/check/' + app.id, null, 'AI 暂不可用，已转人工对照模式：' + ai.reason);
  }
});

/* 重新分析 */
route('POST', /^\/applications\/(\d+)\/analyze$/, ['zy'], async (req, res, user, id) => {
  const app = assertCanSeeApp(user, appRow(Number(id)));
  const rv = db.prepare('SELECT * FROM resume_versions WHERE app_id=? ORDER BY version_no DESC LIMIT 1').get(app.id);
  const jobItems = db.prepare('SELECT * FROM job_items WHERE job_id=? ORDER BY id').all(app.job_id);
  const ai = await analyzeResume({ items: jobItems, resume: rv.text });
  if (!ai.ok) return redirect(res, '/check/' + app.id, null, '分析失败：' + ai.reason);
  const an = db.prepare('INSERT INTO analyses (app_id,rv_id,score,model,status,created_at) VALUES (?,?,?,?,?,?)')
    .run(app.id, rv.id, ai.score, ai.model, ai.status, nowIso());
  const insI = db.prepare('INSERT INTO analysis_items (analysis_id,cond,type,weight,conclusion,quote,to_verify,source) VALUES (?,?,?,?,?,?,?,?)');
  ai.items.forEach((it) => insI.run(Number(an.lastInsertRowid), it.content, it.type, it.weight, it.conclusion, it.quote, it.to_verify, 'ai'));
  audit(user, user.role, `${ai.demo ? '演示引擎重新对照' : '重新分析'}：${app.name}，参考分 ${ai.score}`, 'application', app.id);
  redirect(res, '/check/' + app.id, (ai.demo ? '演示引擎已重新对照，参考分 ' : '已重新分析，参考分 ') + ai.score);
});

/* ---------- P4 核对 ---------- */
route('GET', /^\/check$/, ['zy'], async (req, res, user) => {
  const rows = db.prepare(`SELECT a.*, j.title job_title FROM applications a JOIN jobs j ON j.id=a.job_id
    WHERE a.owner_zy=? AND a.status IN ('待核对','已核对','已推荐') ORDER BY a.id DESC`).all(user.id);
  const list = rows.map((a) => {
    const an = latestAnalysis(a.id);
    return `<tr><td><b>${esc(a.name)}</b><div class="sub">${esc(a.job_title)} · v${a.version}</div></td>
      <td>${an?.score ?? '—'}</td><td><span class="pill ${BADGE(a.status)}">${a.status}</span></td>
      <td>${a.handle_hours ? a.handle_hours + ' 小时' : '—'}</td>
      <td><a href="/check/${a.id}"><button class="p">核对</button></a></td></tr>`;
  }).join('');
  send(res, 200, page(req, user, 'P4 核对与推荐', '/check', `
    <h1>P4 核对与推荐</h1><div class="sub">唯一归属：招聘专员 · AI 只给依据，推荐由人决定</div>
    <div class="card"><table><thead><tr><th>候选人</th><th>参考分</th><th>状态</th><th>处理时长</th><th>操作</th></tr></thead><tbody>${list || '<tr><td colspan="5" class="sub">暂无待核对简历</td></tr>'}</tbody></table></div>`));
});

route('GET', /^\/check\/(\d+)$/, ['zy'], async (req, res, user, id) => {
  const app = assertCanSeeApp(user, appRow(Number(id)));
  const rv = db.prepare('SELECT * FROM resume_versions WHERE app_id=? ORDER BY version_no DESC LIMIT 1').get(app.id);
  const an = latestAnalysis(app.id);
  const items = an ? itemsOf(an.id) : [];
  const sumW = items.reduce((s, x) => s + x.weight, 0);
  const rec = db.prepare("SELECT * FROM recommendations WHERE app_id=? AND status IN ('active','delete_pending') ORDER BY id DESC LIMIT 1").get(app.id);
  const ev = items.map((it) => `
    <div style="border:1px solid var(--bd);border-radius:8px;padding:10px;margin-bottom:8px">
      <div class="row"><span class="pill ${it.conclusion === '匹配' ? 'g' : it.conclusion === '不符合' ? 'r' : 'a'}">${esc(it.conclusion)}</span>
        <span class="pill n">${it.type === 'must' ? '必备' : '加分'} · 权重 ${it.weight}</span>
        <b>${esc(it.cond)}</b>${it.source === 'human_added' ? '<span class="pill b">核对时新增</span>' : ''}${it.edited ? '<span class="pill b">人工修正</span>' : ''}</div>
      <div class="quote">${it.quote ? esc(it.quote) : '简历未在相应位置体现（信息不足）'}</div>
      <div class="sub" style="margin:4px 0 0">待核实：${esc(it.to_verify || '—')}</div>
      <form class="row" method="post" action="/check/${app.id}/item/${it.id}" style="margin-top:6px">
        <select name="conclusion" style="width:120px">${['匹配', '信息不足', '不符合'].map((x) => `<option ${x === it.conclusion ? 'selected' : ''}>${x}</option>`).join('')}</select>
        <input name="note" placeholder="修正说明（可选）" style="width:200px">
        <button>修正结论</button>
      </form>
      <form class="row" method="post" action="/check/${app.id}/weight" style="margin-top:6px">
        <input type="hidden" name="itemId" value="${it.id}">
        <input type="number" name="weight" value="${it.weight}" min="0" max="100" style="width:80px">
        <input name="reason" placeholder="调整理由（≥10 字，必填）" style="width:260px">
        <button>保存权重</button>
      </form>
    </div>`).join('');

  const canRec = ['待核对', '已核对'].includes(app.status);
  const recBlock = rec
    ? `<div class="ok">已提交推荐（${rec.status === 'delete_pending' ? '删除审批中' : '生效中'}）<br>理由：${esc(rec.reason)}<br>差距：${esc(rec.gap || '无')}<br>待核实：${esc(rec.to_verify || '—')}</div>
       ${rec.status === 'active' ? `<form method="post" action="/check/${app.id}/delete-request" onsubmit="return confirm('提交删除申请？需招聘经理审批')">
         <label>删除原因 *</label><input name="reason" required placeholder="例：推荐对象选错（重复录入）">
         <div class="row" style="margin-top:8px"><button class="d">发起删除申请</button></div></form>` : '<div class="note">删除申请等待招聘经理审批，审批前数据不变。</div>'}`
    : canRec ? `<form method="post" action="/check/${app.id}/recommend">
        <label>推荐理由 *（≥6 字）</label><textarea name="reason" required></textarea>
        <label>差距说明（必备条件未满足或信息不足时必填）</label><textarea name="gap" style="min-height:56px"></textarea>
        <label>待核实问题</label><textarea name="toVerify" style="min-height:56px"></textarea>
        <div class="row" style="margin-top:10px"><button class="p">提交推荐</button></div>
      </form>`
    : `<div class="note">当前状态「${app.status}」不可再编辑推荐。</div>`;

  send(res, 200, page(req, user, '核对与推荐', '/check', `
    <h1>核对与推荐</h1><div class="sub">${esc(app.name)} · ${esc(app.job_title)} · ${esc(rv?.version_no ? 'v' + rv.version_no : '')} · 状态 ${esc(app.status)}</div>
    <div class="grid g2">
      <div class="card fill"><h3>简历原文</h3><div class="doc">${esc(rv?.text || '')}</div></div>
      <div>
        <div class="card"><div class="row"><h3>AI 逐项对照</h3><span class="pill ${an?.status === 'ok' ? 'g' : an?.status === 'demo' ? 'a' : 'r'}">${esc(an?.status === 'demo' ? '演示引擎' : an?.status || '无')}</span>
          ${an ? `<span class="sub">参考分 <b>${an.score ?? '—'}</b> · 权重合计 ${sumW}</span>` : ''}</div>
          <div class="sub">${an?.status === 'demo'
            ? '演示引擎（本地规则，未接大模型）：只做字面匹配，引用均取自简历原文；请逐条人工判断后修正结论'
            : an?.status === 'degraded'
              ? 'AI 不可用或引用缺失，已降级：请人工判断并修正结论'
              : '每条结论必须附简历原文引用；未体现只能标"信息不足"'}</div>
          ${ev || '<div class="note">暂无分析结果</div>'}
          <form class="row" method="post" action="/check/${app.id}/plus">
            <input name="content" placeholder="新增加分项（例：有招聘系统项目经验）" style="flex:1;min-width:200px">
            <input type="number" name="weight" value="10" style="width:80px">
            <label style="margin:0;display:flex;gap:5px;align-items:center;font-weight:400"><input type="checkbox" name="sync" value="1" style="width:auto"> 同步到岗位</label>
            <button>添加</button>
          </form>
          <div class="row" style="margin-top:8px">
            <form method="post" action="/applications/${app.id}/analyze"><button>重新调用 AI 分析</button></form>
            ${['待核对', '已核对'].includes(app.status) ? `<form method="post" action="/check/${app.id}/done"><button>仅完成核对</button></form>` : ''}
          </div>
        </div>
        <div class="card"><h3>我的决策（人工）</h3>${recBlock}</div>
      </div>
    </div>`));
});

route('POST', /^\/check\/(\d+)\/weight$/, ['zy'], async (req, res, user, id) => {
  const app = assertCanSeeApp(user, appRow(Number(id)));
  const f = await parseForm(req);
  const item = db.prepare('SELECT * FROM analysis_items WHERE id=?').get(Number(f.itemId));
  const reason = String(f.reason || '').trim();
  if (!item) return redirect(res, '/check/' + app.id, null, '条件不存在');
  if (reason.length < 10) return redirect(res, '/check/' + app.id, null, '请填写调整理由（不少于 10 字）');
  const nw = Math.max(0, Math.min(100, Number(f.weight) || 0));
  db.prepare('UPDATE analysis_items SET weight=? WHERE id=?').run(nw, item.id);
  db.prepare('INSERT INTO weight_changes (app_id,item_id,old_w,new_w,reason,actor_id,created_at) VALUES (?,?,?,?,?,?,?)')
    .run(app.id, item.id, item.weight, nw, reason, user.id, nowIso());
  const score = recalc(latestAnalysis(app.id).id);
  audit(user, user.role, `调整条件权重：${item.cond}（${item.weight} → ${nw}），参考分 ${score}；理由：${reason}`, 'application', app.id);
  redirect(res, '/check/' + app.id, `权重已更新，参考分重算为 ${score}`);
});

route('POST', /^\/check\/(\d+)\/plus$/, ['zy'], async (req, res, user, id) => {
  const app = assertCanSeeApp(user, appRow(Number(id)));
  const f = await parseForm(req);
  const an = latestAnalysis(app.id);
  const content = String(f.content || '').trim();
  if (!an) return redirect(res, '/check/' + app.id, null, '请先完成分析');
  if (content.length < 3) return redirect(res, '/check/' + app.id, null, '加分项描述过短');
  const w = Math.max(0, Math.min(100, Number(f.weight) || 0));
  db.prepare('INSERT INTO analysis_items (analysis_id,cond,type,weight,conclusion,quote,to_verify,source) VALUES (?,?,?,?,?,?,?,?)')
    .run(an.id, content, 'plus', w, '信息不足', '', '核对时新增的加分项，需人工判断或补充核实', 'human_added');
  if (f.sync) {
    db.prepare('INSERT INTO job_items (job_id,type,content,weight,source) VALUES (?,?,?,?,?)').run(app.job_id, 'plus', content, w, 'check_added');
    db.prepare('UPDATE jobs SET version=version+1, updated_at=? WHERE id=?').run(nowIso(), app.job_id);
  }
  const score = recalc(an.id);
  audit(user, user.role, `核对时新增加分项：${content}（权重 ${w}${f.sync ? '，已同步岗位' : ''}）`, 'application', app.id);
  redirect(res, '/check/' + app.id, '已添加，参考分更新为 ' + score);
});

route('POST', /^\/check\/(\d+)\/item\/(\d+)$/, ['zy'], async (req, res, user, id, itemId) => {
  const app = assertCanSeeApp(user, appRow(Number(id)));
  const f = await parseForm(req);
  const item = db.prepare('SELECT * FROM analysis_items WHERE id=?').get(Number(itemId));
  if (!item) return redirect(res, '/check/' + app.id, null, '条件不存在');
  const c = ['匹配', '信息不足', '不符合'].includes(f.conclusion) ? f.conclusion : '信息不足';
  db.prepare('UPDATE analysis_items SET conclusion=?, edited=1, to_verify=? WHERE id=?')
    .run(c, String(f.note || '人工修正').trim(), item.id);
  const score = recalc(latestAnalysis(app.id).id);
  audit(user, user.role, `修正 AI 结论：${item.cond}（${item.conclusion} → ${c}）${f.note ? '：' + f.note : ''}`, 'application', app.id);
  redirect(res, '/check/' + app.id, `已修正，参考分 ${score}`);
});

route('POST', /^\/check\/(\d+)\/done$/, ['zy'], async (req, res, user, id) => {
  const app = assertCanSeeApp(user, appRow(Number(id)));
  const h = hoursSince(app.created_at);
  db.prepare("UPDATE applications SET status='已核对', checked_at=?, handle_hours=? WHERE id=?").run(nowIso(), Number(h.toFixed(1)), app.id);
  logStatus(app.id, app.status, '已核对', user);
  audit(user, user.role, '完成核对（未推荐）：' + app.name, 'application', app.id);
  redirect(res, '/check', '已标记核对完成');
});

route('POST', /^\/check\/(\d+)\/recommend$/, ['zy'], async (req, res, user, id) => {
  const app = assertCanSeeApp(user, appRow(Number(id)));
  const f = await parseForm(req);
  const reason = String(f.reason || '').trim();
  const gap = String(f.gap || '').trim();
  const an = latestAnalysis(app.id);
  const items = an ? itemsOf(an.id) : [];
  const mustFail = items.some((x) => x.type === 'must' && x.conclusion !== '匹配');
  if (reason.length < 6) return redirect(res, '/check/' + app.id, null, '推荐理由必填（不少于 6 字）');
  if (mustFail && gap.length < 4) return redirect(res, '/check/' + app.id, null, '存在必备条件未满足或信息不足，请填写差距说明');
  const t = nowIso();
  db.prepare('INSERT INTO recommendations (app_id,reason,gap,to_verify,status,submitted_at) VALUES (?,?,?,?,?,?)')
    .run(app.id, reason, gap, String(f.toVerify || '').trim(), 'active', t);
  const h = hoursSince(app.created_at);
  db.prepare("UPDATE applications SET status='已推荐', stage='部门对接', checked_at=COALESCE(checked_at,?), handle_hours=COALESCE(handle_hours,?) WHERE id=?")
    .run(t, Number(h.toFixed(1)), app.id);
  logStatus(app.id, app.status, '已推荐', user);
  audit(user, user.role, '提交推荐：' + app.name, 'application', app.id);
  addReminder('①', app.job_id, app.id, `简历通过初筛，可对接用人部门推送 ${app.name}`);
  redirect(res, '/check', '推荐已提交，已触发提醒①');
});

route('POST', /^\/check\/(\d+)\/delete-request$/, ['zy'], async (req, res, user, id) => {
  const app = assertCanSeeApp(user, appRow(Number(id)));
  const f = await parseForm(req);
  const rec = db.prepare("SELECT * FROM recommendations WHERE app_id=? AND status='active' ORDER BY id DESC LIMIT 1").get(app.id);
  const reason = String(f.reason || '').trim();
  if (!rec) return redirect(res, '/check/' + app.id, null, '没有可删除的推荐');
  if (!reason) return redirect(res, '/check/' + app.id, null, '删除原因必填');
  if (db.prepare('SELECT id FROM feedback WHERE app_id=?').get(app.id)) return redirect(res, '/check/' + app.id, null, '部门已反馈，不可删除');
  if (CFG('delete_requires_approval') === 'false') {
    db.prepare("UPDATE recommendations SET status='deleted', deleted_at=?, deleted_reason=?, delete_requested_by=? WHERE id=?").run(nowIso(), reason, user.id, rec.id);
    db.prepare("UPDATE applications SET status='已核对', stage='简历初筛' WHERE id=?").run(app.id);
    db.prepare("UPDATE reminders SET status='ignored', handle_note='推荐删除自动关闭' WHERE app_id=? AND status='open'").run(app.id);
    audit(user, user.role, `删除推荐：${app.name}（原因：${reason}）`, 'application', app.id);
    return redirect(res, '/check/' + app.id, '推荐已删除');
  }
  db.prepare("UPDATE recommendations SET status='delete_pending', deleted_reason=?, delete_requested_by=? WHERE id=?").run(reason, user.id, rec.id);
  audit(user, user.role, `发起删除推荐申请：${app.name}（原因：${reason}），等待经理审批`, 'application', app.id);
  redirect(res, '/check/' + app.id, '删除申请已提交，等待招聘经理审批');
});

route('POST', /^\/recommendations\/(\d+)\/decide$/, ['jl'], async (req, res, user, id) => {
  const f = await parseForm(req);
  const rec = db.prepare('SELECT * FROM recommendations WHERE id=?').get(Number(id));
  if (!rec) return redirect(res, '/reminders', null, '推荐不存在');
  const app = appRow(rec.app_id);
  if (f.decision === 'approve') {
    db.prepare("UPDATE recommendations SET status='deleted', deleted_at=?, delete_decided_by=? WHERE id=?").run(nowIso(), user.id, rec.id);
    db.prepare("UPDATE applications SET status='已核对', stage='简历初筛' WHERE id=?").run(app.id);
    db.prepare("UPDATE reminders SET status='ignored', handle_note='推荐删除自动关闭' WHERE app_id=? AND status='open'").run(app.id);
    logStatus(app.id, app.status, '已核对', user);
    audit(user, user.role, `审批通过删除推荐：${app.name}（申请人=${rec.delete_requested_by}，原因：${rec.deleted_reason || ''}）`, 'application', app.id);
    redirect(res, '/reminders', '已批准删除，候选人回到已核对');
  } else {
    db.prepare("UPDATE recommendations SET status='active', delete_decided_by=? WHERE id=?").run(user.id, rec.id);
    audit(user, user.role, `驳回删除推荐：${app.name}`, 'application', app.id);
    redirect(res, '/reminders', '已驳回，推荐保持生效');
  }
});

/* ---------- P5 部门反馈 ---------- */
route('GET', /^\/dept$/, ['yr'], async (req, res, user) => {
  const jobs = ownedJobs(user).map((j) => j.id);
  const wait = jobs.length ? db.prepare(`SELECT a.*, j.title job_title FROM applications a JOIN jobs j ON j.id=a.job_id
    WHERE a.job_id IN (${jobs.map(() => '?').join(',')}) AND a.status='已推荐' ORDER BY a.id`).all(...jobs) : [];
  const done = jobs.length ? db.prepare(`SELECT a.*, f.result, f.reason, f.created_at fdate FROM applications a
    JOIN feedback f ON f.app_id=a.id JOIN jobs j ON j.id=a.job_id WHERE a.job_id IN (${jobs.map(() => '?').join(',')}) ORDER BY f.id DESC`).all(...jobs) : [];
  const cards = wait.map((a) => {
    const rec = db.prepare("SELECT * FROM recommendations WHERE app_id=? AND status='active' ORDER BY id DESC LIMIT 1").get(a.id);
    const over = rec && hoursSince(rec.submitted_at) > SLA();
    return `<div class="card"><div class="row"><b>${esc(a.name)}</b><span class="pill b">参考分 ${latestAnalysis(a.id)?.score ?? '—'}</span>
      <span class="pill n">${esc(a.job_title)}</span>${over ? `<span class="pill r">已超 ${SLA()}h</span>` : ''}
      <span style="flex:1"></span><span class="sub">推荐于 ${esc(rec?.submitted_at || '')}</span></div>
      <div class="sub" style="margin-top:6px"><b>推荐理由：</b>${esc(rec?.reason || '')}<br><b>差距：</b>${esc(rec?.gap || '无')}<br><b>待核实：</b>${esc(rec?.to_verify || '—')}</div>
      <div class="row" style="margin-top:8px">
        <form method="post" action="/applications/${a.id}/feedback"><input type="hidden" name="result" value="同意面试"><button class="p">同意面试</button></form>
        <form method="post" action="/applications/${a.id}/feedback"><input type="hidden" name="result" value="要求补充"><button>要求补充</button></form>
      </div>
      <form method="post" action="/applications/${a.id}/feedback" style="margin-top:8px">
        <input type="hidden" name="result" value="不面试">
        <div class="row"><input name="reason" placeholder="不面试原因（必填）" style="flex:1;min-width:220px"><button class="d">不面试</button></div>
      </form></div>`;
  }).join('');
  const doneRows = done.map((a) => `<tr><td>${esc(a.name)}</td><td><span class="pill ${a.result === '同意面试' ? 'g' : 'r'}">${esc(a.result)}</span></td>
    <td>${esc(a.reason || '—')}</td><td>${esc(a.fdate)}</td></tr>`).join('');
  send(res, 200, page(req, user, 'P5 推荐与反馈', '/dept', `
    <h1>P5 推荐接收与面试反馈</h1><div class="sub">唯一归属：用人经理 · 只看本人岗位；不面试必须填原因</div>
    ${cards || '<div class="card"><div class="sub">暂无待反馈推荐</div></div>'}
    <div class="card"><h3>已反馈</h3><table><thead><tr><th>候选人</th><th>结果</th><th>原因</th><th>时间</th></tr></thead><tbody>${doneRows || '<tr><td colspan="4" class="sub">暂无</td></tr>'}</tbody></table></div>`));
});

route('POST', /^\/applications\/(\d+)\/feedback$/, ['yr'], async (req, res, user, id) => {
  const app = assertCanSeeApp(user, appRow(Number(id)));
  const f = await parseForm(req);
  const result = String(f.result || '');
  const reason = String(f.reason || '').trim();
  if (!['同意面试', '要求补充', '不面试'].includes(result)) return redirect(res, '/dept', null, '反馈类型无效');
  if (result === '不面试' && !reason) return redirect(res, '/dept', null, '不面试必须填写原因');
  const existing = db.prepare('SELECT * FROM feedback WHERE app_id=?').get(app.id);
  if (existing) return redirect(res, '/dept', null, '该推荐已有反馈（并发保护）');

  if (result === '要求补充') {
    db.prepare("UPDATE applications SET status='已核对', stage='简历初筛' WHERE id=?").run(app.id);
    db.prepare("UPDATE recommendations SET status='superseded' WHERE app_id=? AND status='active'").run(app.id);
    logStatus(app.id, app.status, '已核对', user);
    audit(user, user.role, '反馈：要求补充材料（退回专员）· ' + app.name, 'application', app.id);
    return redirect(res, '/dept', '已退回专员补充');
  }
  db.prepare('INSERT INTO feedback (app_id,result,reason,created_at,created_by) VALUES (?,?,?,?,?)').run(app.id, result, reason, nowIso(), user.id);
  const rec = db.prepare('SELECT * FROM recommendations WHERE app_id=? ORDER BY id DESC LIMIT 1').get(app.id);
  const wait = rec ? Number(hoursSince(rec.submitted_at).toFixed(1)) : null;
  if (result === '同意面试') {
    db.prepare("UPDATE applications SET status='面试中', stage='面试推进', wait_hours=? WHERE id=?").run(wait, app.id);
    logStatus(app.id, app.status, '面试中', user);
    addReminder('②', app.job_id, app.id, '用人部门已同意继续发展，请对接部门确认后续安排');
    audit(user, user.role, `反馈：同意面试 · ${app.name}（等待 ${wait} 小时）`, 'application', app.id);
    return redirect(res, '/dept', '已同意面试，触发提醒②');
  }
  db.prepare("UPDATE applications SET status='已终止', stage='简历初筛', wait_hours=? WHERE id=?").run(wait, app.id);
  logStatus(app.id, app.status, '已终止', user);
  audit(user, user.role, `反馈：不面试（${reason}）· ${app.name}`, 'application', app.id);
  redirect(res, '/dept', '已记录不面试及原因');
});

/* ---------- P6 结果 ---------- */
route('GET', /^\/track$/, ['zy'], async (req, res, user) => {
  const rows = db.prepare(`SELECT a.*, j.title job_title FROM applications a JOIN jobs j ON j.id=a.job_id
    WHERE a.owner_zy=? AND a.status IN ('已推荐','面试中','待入职','已入职','已终止') ORDER BY a.id DESC`).all(user.id);
  const list = rows.map((a) => {
    const acts = a.status === '面试中'
      ? `<form class="inline" method="post" action="/applications/${a.id}/result"><input type="hidden" name="result" value="pass"><button class="p">回填面试通过</button></form>
         <form class="inline" method="post" action="/applications/${a.id}/result"><input type="hidden" name="result" value="fail"><button class="d">未通过</button></form>`
      : a.status === '待入职'
        ? `<form class="inline" method="post" action="/applications/${a.id}/result"><input type="hidden" name="result" value="hire"><button class="p">核实实际入职并登记</button></form>
           <form class="inline" method="post" action="/applications/${a.id}/result"><input type="hidden" name="result" value="drop"><button>候选人放弃</button></form>`
        : '';
    return `<tr><td><b>${esc(a.name)}</b><div class="sub">${esc(a.job_title)}</div></td>
      <td><span class="pill ${BADGE(a.status)}">${a.status}</span></td><td>${esc(a.stage)}</td>
      <td>${a.wait_hours ?? '—'}</td><td>${a.hired_at ? esc(a.hired_at) : '—'}</td><td><div class="row">${acts}</div></td></tr>`;
  }).join('');
  send(res, 200, page(req, user, 'P6 进度与结果', '/track', `
    <h1>P6 进度与结果登记</h1><div class="sub">唯一归属：招聘专员 · 面试在飞书进行，这里只登记结果</div>
    <div class="note">"接受 Offer / 约定日期"不算入职：只有"核实实际入职并登记"才会把状态置为已入职。</div>
    <div class="card"><table><thead><tr><th>候选人</th><th>状态</th><th>阶段</th><th>等待(小时)</th><th>入职时间</th><th>操作</th></tr></thead><tbody>${list || '<tr><td colspan="6" class="sub">暂无</td></tr>'}</tbody></table></div>`));
});

route('POST', /^\/applications\/(\d+)\/result$/, ['zy'], async (req, res, user, id) => {
  const app = assertCanSeeApp(user, appRow(Number(id)));
  const f = await parseForm(req);
  const r = String(f.result || '');
  if (r === 'pass') {
    db.prepare("UPDATE applications SET status='待入职', stage='入职推进' WHERE id=?").run(app.id);
    logStatus(app.id, app.status, '待入职', user);
    addReminder('③', app.job_id, app.id, '面试通过并完成筛选确认，请对接应聘者推进入职');
    audit(user, user.role, '回填面试结果：通过 · ' + app.name, 'application', app.id);
    return redirect(res, '/track', '已回填，触发提醒③');
  }
  if (r === 'fail') {
    db.prepare("UPDATE applications SET status='已终止' WHERE id=?").run(app.id);
    logStatus(app.id, app.status, '已终止', user);
    audit(user, user.role, '回填面试结果：未通过 · ' + app.name, 'application', app.id);
    return redirect(res, '/track', '已登记未通过');
  }
  if (r === 'hire') {
    if (app.status !== '待入职') return redirect(res, '/track', null, '仅"待入职"可登记入职');
    db.prepare("UPDATE applications SET status='已入职', hired_at=? WHERE id=?").run(nowIso(), app.id);
    logStatus(app.id, app.status, '已入职', user);
    audit(user, user.role, '核实实际入职并登记 · ' + app.name, 'application', app.id);
    return redirect(res, '/track', '已登记为已入职');
  }
  if (r === 'drop') {
    db.prepare("UPDATE applications SET status='已终止' WHERE id=?").run(app.id);
    db.prepare("UPDATE reminders SET status='ignored', handle_note='候选人放弃' WHERE app_id=? AND status='open'").run(app.id);
    logStatus(app.id, app.status, '已终止', user);
    audit(user, user.role, '登记候选人放弃 · ' + app.name, 'application', app.id);
    return redirect(res, '/track', '已登记放弃');
  }
  redirect(res, '/track', null, '未知操作');
});

/* ---------- P7 看板 ---------- */
route('GET', /^\/board$/, ['jl'], async (req, res, user) => {
  const stages = ['人员需求', '简历初筛', '部门对接', '面试推进', '入职推进'];
  const apps = db.prepare(`SELECT a.*, j.title job_title, u.name owner_name FROM applications a
    JOIN jobs j ON j.id=a.job_id LEFT JOIN users u ON u.id=a.owner_zy WHERE a.status!='已终止'`).all();
  const cols = stages.map((st) => {
    const arr = apps.filter((a) => a.stage === st);
    const cards = arr.map((a) => {
      const rec = db.prepare("SELECT * FROM recommendations WHERE app_id=? AND status='active' ORDER BY id DESC LIMIT 1").get(a.id);
      const blocked = (a.status === '已推荐' && rec && hoursSince(rec.submitted_at) > SLA()) || (a.status === '待入职' && hoursSince(a.created_at) > SLA() * 2);
      const stay = a.status === '已推荐' && rec ? hTxt(hoursSince(rec.submitted_at)) : hTxt(hoursSince(a.created_at));
      return `<div class="ci ${blocked ? 'bl' : ''}"><b>${esc(a.name)}</b><div class="sub">${esc(a.job_title)} · ${esc(a.owner_name || '未分配')}</div>
        <div class="row" style="margin-top:4px"><span class="pill ${BADGE(a.status)}">${a.status}</span><span class="sub">停留 ${stay}${blocked ? ' · 卡点' : ''}</span></div></div>`;
    }).join('');
    return `<div class="col"><b>${st}<em>${arr.length}</em></b>${cards || '<div class="sub" style="margin-top:6px">—</div>'}</div>`;
  }).join('');
  const blockedCount = apps.filter((a) => a.status === '已推荐' && hoursSince(db.prepare("SELECT submitted_at FROM recommendations WHERE app_id=? AND status='active' ORDER BY id DESC LIMIT 1").get(a.id)?.submitted_at) > SLA()).length;
  send(res, 200, page(req, user, 'P7 流程看板', '/board', `
    <h1>P7 招聘流程看板</h1><div class="sub">唯一归属：招聘经理 · 卡点阈值 ${SLA()} 小时（P12 可调）</div>
    <div class="grid g4">${stat('进行中', apps.length)}${stat('卡点', blockedCount)}${stat('待反馈', apps.filter((a) => a.status === '已推荐').length)}${stat('待处理提醒', db.prepare("SELECT COUNT(*) c FROM reminders WHERE status='open'").get().c)}</div>
    <div class="card"><div class="kb">${cols}</div></div>`));
});

/* ---------- P8 提醒 ---------- */
route('GET', /^\/reminders$/, ['jl'], async (req, res, user) => {
  const open = db.prepare("SELECT * FROM reminders WHERE status='open' ORDER BY id DESC").all();
  const done = db.prepare("SELECT * FROM reminders WHERE status!='open' ORDER BY id DESC LIMIT 20").all();
  const pendingRec = db.prepare("SELECT r.*, a.name app_name FROM recommendations r JOIN applications a ON a.id=r.app_id WHERE r.status='delete_pending'").all();
  const accessReq = db.prepare("SELECT ar.*, u.name admin_name FROM access_requests ar JOIN users u ON u.id=ar.admin_id WHERE ar.status='pending'").all();
  const typeName = { '①': '① 对接部门（初筛通过）', '②': '② 对接部门（同意继续）', '③': '③ 对接应聘者（面试通过）' };
  const openHtml = open.map((r) => `<div class="card"><div class="row"><b>${esc(typeName[r.type] || r.type)}</b><span class="pill a">${r.type}</span>
      <span style="flex:1"></span><span class="sub">${esc(r.created_at)} · ${hTxt(hoursSince(r.created_at))}前</span></div>
      <div class="sub">${esc(r.text)}</div>
      <form class="row" method="post" action="/reminders/${r.id}/handle" style="margin-top:6px">
        <select name="note" style="width:280px"><option>已与用人部门沟通，安排面试</option><option>已与应聘者沟通，确认入职意向</option><option>已确认后续安排（时间/面试官）</option><option>对方暂未响应，改为电话跟进</option></select>
        <button class="p">标记已处理</button></form>
      <form class="inline" method="post" action="/reminders/${r.id}/ignore"><button>忽略</button></form></div>`).join('');
  const doneHtml = done.map((r) => `<div class="sub">${esc(r.type)} ${esc(r.text)} — <b>${esc(r.status)}</b>${r.handle_note ? '：' + esc(r.handle_note) : ''}</div>`).join('');
  const recHtml = pendingRec.map((r) => `<div class="card"><b>删除推荐审批：${esc(r.app_name)}</b>
      <div class="sub">原因：${esc(r.deleted_reason || '')}</div>
      <div class="row"><form method="post" action="/recommendations/${r.id}/decide"><input type="hidden" name="decision" value="approve"><button class="p">批准删除</button></form>
      <form method="post" action="/recommendations/${r.id}/decide"><input type="hidden" name="decision" value="reject"><button>驳回</button></form></div></div>`).join('');
  const accHtml = accessReq.map((r) => `<div class="card"><b>管理员查看简历申请</b><div class="sub">申请人：${esc(r.admin_name)} · 原因：${esc(r.reason)}</div>
      <form class="inline" method="post" action="/access/${r.id}/decide"><input type="hidden" name="decision" value="approve"><button class="p">批准（30 分钟只读）</button></form>
      <form class="inline" method="post" action="/access/${r.id}/decide"><input type="hidden" name="decision" value="reject"><button>拒绝</button></form></div>`).join('');
  send(res, 200, page(req, user, 'P8 提醒中心', '/reminders', `
    <h1>P8 提醒中心</h1><div class="sub">唯一归属：招聘经理 · 渠道：${esc(CFG('channel'))}（邮件汇总为模拟）</div>
    <div class="card"><h3>待处理（${open.length}）</h3>${openHtml || '<div class="sub">暂无</div>'}</div>
    <div class="card"><h3>审批事项</h3>${recHtml || accHtml ? recHtml + accHtml : '<div class="sub">暂无待审批</div>'}</div>
    <div class="card"><h3>已闭环</h3>${doneHtml || '<div class="sub">暂无</div>'}</div>`));
});

route('POST', /^\/reminders\/(\d+)\/handle$/, ['jl'], async (req, res, user, id) => {
  const f = await parseForm(req);
  const r = db.prepare('SELECT * FROM reminders WHERE id=?').get(Number(id));
  if (!r) return redirect(res, '/reminders', null, '提醒不存在');
  db.prepare("UPDATE reminders SET status='handled', handled_at=?, handle_note=? WHERE id=?").run(nowIso(), String(f.note || '已处理'), r.id);
  audit(user, user.role, `处理提醒 ${r.type}：${r.text}（${f.note}）`, 'reminder', r.id);
  redirect(res, '/reminders', '提醒已闭环');
});

route('POST', /^\/reminders\/(\d+)\/ignore$/, ['jl'], async (req, res, user, id) => {
  const r = db.prepare('SELECT * FROM reminders WHERE id=?').get(Number(id));
  if (!r) return redirect(res, '/reminders', null, '提醒不存在');
  db.prepare("UPDATE reminders SET status='ignored', handled_at=?, handle_note='经理忽略' WHERE id=?").run(nowIso(), r.id);
  audit(user, user.role, `忽略提醒 ${r.type}：${r.text}`, 'reminder', r.id);
  redirect(res, '/reminders', '已忽略（留痕）');
});

/* ---------- P9 留痕 ---------- */
route('GET', /^\/audit$/, ['jl'], async (req, res, user) => {
  const logs = db.prepare('SELECT * FROM audit_logs ORDER BY id DESC LIMIT 200').all();
  const rows = logs.map((l) => `<div><span style="color:var(--ink-400)">${esc(l.at)}</span> <b>${esc(l.actor)}（${esc(ROLE_NAME[l.role] || l.role)}）</b> ${esc(l.action)} <span style="color:var(--ink-400)">[${esc(l.obj_type)}:${esc(l.obj_id)}]</span></div>`).join('');
  const handled = db.prepare('SELECT AVG(handle_hours) a FROM applications WHERE handle_hours IS NOT NULL').get().a;
  const waited = db.prepare('SELECT AVG(wait_hours) a FROM applications WHERE wait_hours IS NOT NULL').get().a;
  const waits = db.prepare('SELECT wait_hours w FROM applications WHERE wait_hours IS NOT NULL').all().map((x) => x.w);
  const median = waits.length ? waits.sort((a, b) => a - b)[Math.floor(waits.length / 2)] : null;
  const remTotal = db.prepare('SELECT COUNT(*) c FROM reminders').get().c;
  const remDone = db.prepare("SELECT COUNT(*) c FROM reminders WHERE status!='open'").get().c;
  // 卡点口径与看板一致：已推荐且等待反馈超过 SLA
  const recRows = db.prepare("SELECT a.id, (SELECT submitted_at FROM recommendations r WHERE r.app_id=a.id AND r.status='active' ORDER BY r.id DESC LIMIT 1) sub FROM applications a WHERE a.status='已推荐'").all();
  const blockedCount = recRows.filter((x) => x.sub && hoursSince(x.sub) > SLA()).length;
  const handleN = db.prepare('SELECT COUNT(*) c FROM applications WHERE handle_hours IS NOT NULL').get().c;
  const waitN = waits.length;
  const fmtAvg = (v, n) => (n === 0 ? '—' : n < 5 ? '—（样本不足 ' + n + '）' : Number(v).toFixed(1) + ' h');
  send(res, 200, page(req, user, 'P9 留痕与统计', '/audit', `
    <h1>P9 操作留痕与统计</h1><div class="sub">唯一归属：招聘经理 · 业务留痕（管理动作在 P11 由管理员查看）</div>
    <div class="grid g4">
      ${stat('平均处理时长', fmtAvg(handled, handleN), '自然时长口径（样本<5 不显示均值）')}
      ${stat('平均等待反馈', fmtAvg(waited, waitN), median ? '中位数 ' + median + ' h' : '无样本')}
      ${stat('当前卡点', blockedCount, '与 P7 同口径（>' + SLA() + 'h）')}
      ${stat('提醒处理率', remTotal ? Math.round((remDone / remTotal) * 100) + '%' : '—', remDone + '/' + remTotal)}
    </div>
    <div class="card"><h3>操作留痕（最近 200 条，追加式不可改）</h3><div class="audit">${rows || '<div class="sub">暂无</div>'}</div></div>`));
});

/* ---------- P10 账号 ---------- */
route('GET', /^\/users$/, ['sys'], async (req, res, user) => {
  const us = db.prepare('SELECT * FROM users ORDER BY id').all();
  const rows = us.map((u) => `<tr><td><b>${esc(u.name)}</b><div class="sub mono">${esc(u.login)}</div></td>
    <td><span class="pill n">${ROLE_NAME[u.role]}</span></td><td>${esc(u.dept || '')}</td>
    <td><span class="pill ${u.status === 'active' ? 'g' : 'r'}">${u.status === 'active' ? '正常' : '已停用'}</span></td>
    <td><div class="row">
      <form class="inline" method="post" action="/users/${u.id}/toggle"><button>${u.status === 'active' ? '停用' : '启用'}</button></form>
      <form class="inline row" method="post" action="/users/${u.id}/role">
        <select name="role" style="width:110px">${Object.entries(ROLE_NAME).map(([k, v]) => `<option value="${k}" ${k === u.role ? 'selected' : ''}>${v}</option>`).join('')}</select>
        <button>改角色</button></form></div></td></tr>`).join('');
  send(res, 200, page(req, user, 'P10 账号与角色', '/users', `
    <h1>P10 账号与角色</h1><div class="sub">唯一归属：系统管理员 · 至少保留 1 个可用管理员</div>
    <div class="card"><h3>新建账号</h3><form class="row" method="post" action="/users">
      <input name="name" placeholder="姓名" required style="width:130px"><input name="login" placeholder="登录名" required style="width:130px">
      <select name="role" style="width:120px">${Object.entries(ROLE_NAME).map(([k, v]) => `<option value="${k}">${v}</option>`).join('')}</select>
      <input name="dept" placeholder="部门" style="width:150px"><button class="p">创建</button></form>
      <div class="note">初始密码统一为 Passw0rd!；<b>未实现</b>首次登录强制改密（待办，见未完成项）。</div></div>
    <div class="card"><table><thead><tr><th>姓名/登录名</th><th>角色</th><th>部门</th><th>状态</th><th>操作</th></tr></thead><tbody>${rows}</tbody></table></div>`));
});

route('POST', /^\/users$/, ['sys'], async (req, res, user) => {
  const f = await parseForm(req);
  const login = String(f.login || '').trim();
  const name = String(f.name || '').trim();
  if (!login || !name) return redirect(res, '/users', null, '姓名与登录名必填');
  if (db.prepare('SELECT id FROM users WHERE login=?').get(login)) return redirect(res, '/users', null, '登录名已存在');
  const role = ROLE_NAME[f.role] ? f.role : 'zy';
  db.prepare('INSERT INTO users (name,login,pwd,role,dept,created_at) VALUES (?,?,?,?,?,?)')
    .run(name, login, hashPassword('Passw0rd!'), role, String(f.dept || ''), nowIso());
  audit(user, user.role, `新增账号：${name}（${ROLE_NAME[role]}，${login}）`, 'user', login);
  redirect(res, '/users', '账号已创建');
});

route('POST', /^\/users\/(\d+)\/toggle$/, ['sys'], async (req, res, user, id) => {
  const u = db.prepare('SELECT * FROM users WHERE id=?').get(Number(id));
  if (!u) return redirect(res, '/users', null, '账号不存在');
  if (u.role === 'sys' && u.status === 'active' && db.prepare("SELECT COUNT(*) c FROM users WHERE role='sys' AND status='active'").get().c <= 1)
    return redirect(res, '/users', null, '不可停用唯一的系统管理员');
  if (u.id === user.id) return redirect(res, '/users', null, '不可停用当前登录账号');
  const next = u.status === 'active' ? 'disabled' : 'active';
  db.prepare('UPDATE users SET status=? WHERE id=?').run(next, u.id);
  if (next === 'disabled') db.prepare('DELETE FROM sessions WHERE user_id=?').run(u.id);
  audit(user, user.role, `${next === 'disabled' ? '停用' : '启用'}账号：${u.name}`, 'user', u.login);
  redirect(res, '/users', '已' + (next === 'disabled' ? '停用' : '启用'));
});

route('POST', /^\/users\/(\d+)\/role$/, ['sys'], async (req, res, user, id) => {
  const f = await parseForm(req);
  const u = db.prepare('SELECT * FROM users WHERE id=?').get(Number(id));
  const role = f.role;
  if (!u || !ROLE_NAME[role]) return redirect(res, '/users', null, '参数无效');
  if (u.role === 'sys' && role !== 'sys' && db.prepare("SELECT COUNT(*) c FROM users WHERE role='sys' AND status='active'").get().c <= 1)
    return redirect(res, '/users', null, '必须保留至少 1 个可用管理员');
  db.prepare('UPDATE users SET role=? WHERE id=?').run(role, u.id);
  audit(user, user.role, `变更角色：${u.name}（${ROLE_NAME[u.role]} → ${ROLE_NAME[role]}）`, 'user', u.login);
  redirect(res, '/users', '角色已更新');
});

/* ---------- P11 数据治理 ---------- */
route('GET', /^\/data$/, ['sys'], async (req, res, user) => {
  const size = (() => { try { return (readFileSync('data/app.db').length / 1024).toFixed(1); } catch { return '?'; } })();
  const reqs = db.prepare('SELECT ar.*, u.name admin_name FROM access_requests ar JOIN users u ON u.id=ar.admin_id ORDER BY ar.id DESC LIMIT 10').all();
  const reqRows = reqs.map((r) => `<tr><td>${esc(r.admin_name)}</td><td>${esc(r.reason)}</td><td><span class="pill ${BADGE(r.status)}">${r.status}</span></td>
    <td>${r.expires_at ? new Date(r.expires_at).toLocaleString('zh-CN') : '—'}</td></tr>`).join('');
  send(res, 200, page(req, user, 'P11 数据治理', '/data', `
    <h1>P11 数据治理与审计</h1><div class="sub">唯一归属：系统管理员 · 默认不可查看候选人材料</div>
    <div class="grid g4">${stat('岗位', db.prepare('SELECT COUNT(*) c FROM jobs').get().c)}${stat('应聘记录', db.prepare('SELECT COUNT(*) c FROM applications').get().c)}${stat('留痕', db.prepare('SELECT COUNT(*) c FROM audit_logs').get().c)}${stat('库大小', size + ' KB')}</div>
    <div class="card"><h3>导出</h3><div class="row"><a href="/data/export.json"><button class="p">导出全量 JSON</button></a><a href="/data/export.csv"><button>导出留痕 CSV</button></a></div>
      <div class="note">导出含个人信息，导出动作写入审计（未实现审批前置，标为未完成项）。</div></div>
    <div class="card"><h3>排障查看简历（双人复核）</h3>
      <form class="row" method="post" action="/access/request"><input name="reason" placeholder="申请原因（必填，例：核对解析失败）" style="flex:1;min-width:240px"><button class="p">提交申请</button></form>
      <div class="sub" style="margin-top:6px">需招聘经理批准，批准后 30 分钟内只读可看（带审计）。</div>
      <table style="margin-top:8px"><thead><tr><th>申请人</th><th>原因</th><th>状态</th><th>有效期</th></tr></thead><tbody>${reqRows || '<tr><td colspan="4" class="sub">暂无申请</td></tr>'}</tbody></table></div>
    <div class="card"><h3>全量审计（含管理动作）</h3><div class="audit">${db.prepare('SELECT * FROM audit_logs ORDER BY id DESC LIMIT 80').all().map((l) => `<div><span style="color:var(--ink-400)">${esc(l.at)}</span> <b>${esc(l.actor)}</b> ${esc(l.action)}</div>`).join('') || '<div class="sub">暂无</div>'}</div></div>
    <div class="card"><h3>清理已结束数据</h3><form method="post" action="/data/clean" onsubmit="return confirm('仅清理已结束岗位及其已终止候选人，确认？')"><button class="d">执行清理</button></form></div>`));
});

route('GET', /^\/data\/export\.json$/, ['sys'], async (req, res, user) => {
  const dump = {};
  for (const t of ['jobs', 'job_items', 'applications', 'resume_versions', 'analyses', 'analysis_items', 'recommendations', 'feedback', 'reminders', 'audit_logs', 'configs']) dump[t] = db.prepare(`SELECT * FROM ${t}`).all();
  audit(user, user.role, '导出全量 JSON 备份', 'config', 'EXPORT');
  res.writeHead(200, { 'content-type': 'application/json; charset=utf-8', 'content-disposition': 'attachment; filename="hire-backup.json"' });
  res.end(JSON.stringify(dump, null, 2));
});

route('GET', /^\/data\/export\.csv$/, ['sys'], async (req, res, user) => {
  const rows = db.prepare('SELECT * FROM audit_logs ORDER BY id').all();
  const head = ['at', 'actor', 'role', 'action', 'obj_type', 'obj_id'];
  const csv = '\uFEFF' + [head.join(','), ...rows.map((r) => head.map((h) => `"${String(r[h] ?? '').replace(/"/g, '""')}"`).join(','))].join('\r\n');
  audit(user, user.role, `导出留痕 CSV（${rows.length} 条）`, 'config', 'EXPORT');
  res.writeHead(200, { 'content-type': 'text/csv; charset=utf-8', 'content-disposition': 'attachment; filename="audit.csv"' });
  res.end(csv);
});

route('POST', /^\/data\/clean$/, ['sys'], async (req, res, user) => {
  const ids = db.prepare("SELECT id FROM jobs WHERE status='closed'").all().map((x) => x.id);
  if (ids.length) {
    const ph = ids.map(() => '?').join(',');
    db.prepare(`DELETE FROM applications WHERE job_id IN (${ph}) AND status='已终止'`).run(...ids);
    db.prepare(`DELETE FROM jobs WHERE id IN (${ph})`).run(...ids);
  }
  audit(user, user.role, `清理已结束岗位（${ids.length} 个）`, 'config', 'CLEAN');
  redirect(res, '/data', `已清理 ${ids.length} 个已结束岗位`);
});

route('POST', /^\/access\/request$/, ['sys'], async (req, res, user) => {
  const f = await parseForm(req);
  const reason = String(f.reason || '').trim();
  if (!reason) return redirect(res, '/data', null, '申请原因必填');
  const r = db.prepare('INSERT INTO access_requests (admin_id,reason,status,created_at) VALUES (?,?,?,?)').run(user.id, reason, 'pending', nowIso());
  audit(user, user.role, '申请查看候选人材料：' + reason, 'access', r.lastInsertRowid);
  redirect(res, '/data', '申请已提交，等待招聘经理批准');
});

route('POST', /^\/access\/(\d+)\/decide$/, ['jl'], async (req, res, user, id) => {
  const f = await parseForm(req);
  const r = db.prepare('SELECT * FROM access_requests WHERE id=?').get(Number(id));
  if (!r) return redirect(res, '/reminders', null, '申请不存在');
  if (f.decision === 'approve') {
    db.prepare("UPDATE access_requests SET status='approved', approver_id=?, expires_at=? WHERE id=?").run(user.id, Date.now() + 30 * 60_000, r.id);
    audit(user, user.role, '批准管理员查看简历（30 分钟只读）', 'access', r.id);
    redirect(res, '/reminders', '已批准，30 分钟内有效');
  }
  db.prepare("UPDATE access_requests SET status='rejected', approver_id=? WHERE id=?").run(user.id, r.id);
  audit(user, user.role, '拒绝管理员查看简历', 'access', r.id);
  redirect(res, '/reminders', '已拒绝');
});

route('GET', /^\/applications\/(\d+)\/resume$/, ['sys'], async (req, res, user, id) => {
  const reqId = Number(q(req).get('req'));
  const r = db.prepare('SELECT * FROM access_requests WHERE id=? AND admin_id=? AND status=?').get(reqId, user.id, 'approved');
  if (!r || !r.expires_at || r.expires_at < Date.now()) return send(res, 403, layout({ user, title: '403', body: '<div class="card"><h1>403 · 无有效授权</h1><div class="sub">需要招聘经理批准的 30 分钟只读授权。</div></div>' }));
  const app = db.prepare('SELECT * FROM applications WHERE id=?').get(Number(id));
  const rv = db.prepare('SELECT * FROM resume_versions WHERE app_id=? ORDER BY version_no DESC LIMIT 1').get(app.id);
  audit(user, user.role, `管理员查看候选人材料（授权单 #${r.id}）`, 'application', app.id);
  send(res, 200, page(req, user, '只读查看', '', `<div class="card"><h1>只读查看（授权单 #${r.id}）</h1>
    <div class="note">水印：管理员 ${esc(user.name)} · ${esc(nowIso())} · 禁止下载与复制</div>
    <div class="doc">${esc(rv?.text || '')}</div></div>`));
});

/* ---------- P12/P13 配置 ---------- */
route('GET', /^\/config\/biz$/, ['jl'], async (req, res, user) => {
  const c = Object.fromEntries(db.prepare("SELECT key,value FROM configs WHERE scope='biz'").all().map((x) => [x.key, x.value]));
  send(res, 200, page(req, user, 'P12 业务规则', '/config/biz', `
    <h1>P12 业务规则配置</h1><div class="sub">唯一归属：招聘经理 · 只放业务口径</div>
    <div class="card"><form method="post" action="/config/biz">
      <label>部门反馈超时阈值（小时）</label><input type="number" name="sla_hours" value="${esc(c.sla_hours || '24')}" min="1" max="240">
      <label>启用超时兜底提醒</label><select name="auto_timeout"><option value="false" ${c.auto_timeout !== 'true' ? 'selected' : ''}>关闭</option><option value="true" ${c.auto_timeout === 'true' ? 'selected' : ''}>开启</option></select>
      <label>提醒渠道</label><input name="channel" value="${esc(c.channel || '站内信+每日邮件')}">
      <label>同类提醒去重</label><select name="dedupe"><option value="true" ${c.dedupe !== 'false' ? 'selected' : ''}>开启</option><option value="false" ${c.dedupe === 'false' ? 'selected' : ''}>关闭</option></select>
      <label>删除推荐是否需经理审批</label><select name="delete_requires_approval"><option value="true" ${c.delete_requires_approval !== 'false' ? 'selected' : ''}>需要</option><option value="false" ${c.delete_requires_approval === 'false' ? 'selected' : ''}>不需要</option></select>
      <div class="row" style="margin-top:12px"><button class="p">保存业务配置</button></div></form></div>
    <div class="note">系统口径（脱敏、留痕期限、会话）在 P13，由系统管理员维护；两页互不可见。</div>`));
});

route('POST', /^\/config\/biz$/, ['jl'], async (req, res, user) => {
  const f = await parseForm(req);
  const set = db.prepare('UPDATE configs SET value=?, updated_by=?, updated_at=? WHERE key=?');
  for (const k of ['sla_hours', 'auto_timeout', 'channel', 'dedupe', 'delete_requires_approval']) {
    if (f[k] !== undefined) set.run(String(f[k]), user.id, nowIso(), k);
  }
  audit(user, user.role, `修改业务配置：阈值 ${f.sla_hours}h，超时兜底 ${f.auto_timeout}`, 'config', 'BIZ');
  redirect(res, '/config/biz', '业务配置已保存并生效');
});

/* ---------- P13 大模型接入（只读视图 + 连通性自检） ---------- */
const cnTime = (iso) => {
  try {
    return new Intl.DateTimeFormat('zh-CN', {
      timeZone: 'Asia/Shanghai', year: 'numeric', month: '2-digit', day: '2-digit',
      hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false,
    }).format(new Date(iso)).replace(/\//g, '-');
  } catch { return String(iso || ''); }
};
function llmCard() {
  let last = null;
  try { last = JSON.parse(CFG('llm_last_check') || 'null'); } catch { last = null; }
  const statePill = AI_INFO.configured
    ? '<span class="pill g">已接入</span>'
    : DEMO_AI_ENABLED
      ? '<span class="pill a">未接入 · 演示引擎</span>'
      : '<span class="pill a">未接入 · 人工对照</span>';
  const lastHtml = last
    ? `<div class="${last.ok ? 'ok' : 'err'}" style="margin-top:12px">上次自检：<b>${last.ok ? '连通正常' : '失败'}</b>
        · ${esc(cnTime(last.at))} · ${esc(String(last.ms ?? '-'))} ms
        ${last.reply ? ` · 模型回复「${esc(last.reply)}」` : ''}${last.model ? ` · 实返模型 ${esc(last.model)}` : ''}
        ${last.reason ? `<br>${esc(last.reason)}` : ''}</div>`
    : '<div class="note" style="margin-top:12px">尚未执行连通性自检。点击按钮会真实请求一次模型（约 1~3 秒），用于确认密钥、地址与模型名同时有效。</div>';
  return `<div class="card">
    <div class="row"><div><h3>大模型接入</h3><div class="sub">只读视图 · 密钥仅存于服务器端，页面与接口均不下发完整值</div></div><div>${statePill}</div></div>
    <table><thead><tr><th style="width:150px">项目</th><th>当前值</th></tr></thead><tbody>
      <tr><td>服务地址</td><td><span class="mono">${esc(AI_INFO.baseHost || '未配置')}</span><div class="sub">${esc(AI_INFO.protocol)}</div></td></tr>
      <tr><td>模型名称</td><td><span class="mono">${esc(AI_INFO.model)}</span></td></tr>
      <tr><td>API 密钥</td><td><span class="mono">${esc(AI_INFO.keyMasked)}</span> ${AI_INFO.keyPresent ? '<span class="pill g">已配置</span>' : '<span class="pill r">缺失</span>'}</td></tr>
      <tr><td>配置来源</td><td>${esc(AI_INFO.source)}<div class="sub">修改密钥或模型需编辑服务端配置并重启服务，页面不提供写入入口</div></td></tr>
      <tr><td>单次调用超时</td><td><span class="mono">${AI_INFO.timeoutMs / 1000} s</span><div class="sub">超时即降级为人工对照，不产生虚假分数</div></td></tr>
      <tr><td>降级策略</td><td>结论缺少可定位原文引用时，该条自动降级为「信息不足」并标记 degraded${!AI_INFO.configured && DEMO_AI_ENABLED ? '；当前未接入模型，分析由<b>本地演示引擎</b>处理，结果标记 demo（字面匹配，非大模型）' : ''}</td></tr>
    </tbody></table>
    <div class="row" style="margin-top:14px"><form class="inline" method="post" action="/config/sys/test-llm"><button class="p">测试连通性</button></form><span class="sub">不会上传任何简历内容</span></div>
    ${lastHtml}
  </div>`;
}

/* ---------- AI 质量评测：裁判模型与最近一次评测 ---------- */
function latestEvalSummary() {
  try {
    const base = 'eval/runs';
    const dirs = readdirSync(base, { withFileTypes: true })
      .filter((d) => d.isDirectory()).map((d) => d.name).sort();
    if (!dirs.length) return null;
    const id = dirs[dirs.length - 1];
    const s = JSON.parse(readFileSync(`${base}/${id}/summary.json`, 'utf8'));
    return { id, ...s };
  } catch { return null; }
}

function judgeCard() {
  let last = null;
  try { last = JSON.parse(CFG('judge_last_check') || 'null'); } catch { last = null; }
  const ev = latestEvalSummary();

  const statePill = JUDGE_INFO.configured
    ? '<span class="pill g">已接入</span>'
    : '<span class="pill a">未接入 · 评测不可用</span>';
  const sep = JUDGE_INFO.configured
    ? (JUDGE_INFO.sameAsTarget
      ? '<span class="pill r">与业务模型相同</span><div class="sub">评测纪律要求裁判 ≠ 被评，否则通过率会虚高</div>'
      : '<span class="pill g">已分离</span><div class="sub">裁判与被评不是同一个模型</div>')
    : '<span class="pill n">—</span>';

  const evalHtml = ev
    ? `<table style="margin-top:6px"><thead><tr><th>评测批次</th><th>样本</th><th>通过</th><th>部分通过</th><th>失败</th><th>结论一致率</th><th>证据支持率</th></tr></thead><tbody>
        <tr><td><span class="mono">${esc(ev.id)}</span></td><td>${esc(String(ev.n ?? ''))}</td>
          <td><span class="pill g">${esc(String(ev.pass ?? ''))}</span></td>
          <td><span class="pill a">${esc(String(ev.partial ?? ''))}</span></td>
          <td><span class="pill r">${esc(String(ev.fail ?? ''))}</span></td>
          <td>${ev.overall?.conclusion_accuracy != null ? (ev.overall.conclusion_accuracy * 100).toFixed(1) + '%' : '—'}</td>
          <td>${ev.evidence_supports != null ? (ev.evidence_supports * 100).toFixed(1) + '%' : '—'}</td></tr>
      </tbody></table>
      <div class="sub">裁判模型 ${esc(ev.judge?.model || '')} · 被测模型 ${esc(ev.evaluated_model || '')} · 明细见 eval/runs/${esc(ev.id)}/</div>`
    : '<div class="note" style="margin-top:6px">尚无评测批次。运行 <span class="mono">eval/run_eval.py</span> 后这里会显示最近一次结果。</div>';

  return `<div class="card">
    <div class="row"><div><h3>AI 质量评测 · 裁判模型</h3><div class="sub">裁判模型只用于给 AI 输出打分，不参与业务判断</div></div><div>${statePill}</div></div>
    <table><thead><tr><th style="width:150px">项目</th><th>当前值</th></tr></thead><tbody>
      <tr><td>服务地址</td><td><span class="mono">${esc(JUDGE_INFO.baseHost || '未配置')}</span></td></tr>
      <tr><td>裁判模型</td><td><span class="mono">${esc(JUDGE_INFO.model)}</span>${JUDGE_INFO.configured ? '<span class="pill n" style="margin-left:6px">judge</span>' : ''}</td></tr>
      <tr><td>被测模型</td><td><span class="mono">${esc(JUDGE_INFO.targetModel)}</span><span class="pill n" style="margin-left:6px">target</span></td></tr>
      <tr><td>角色分离</td><td>${sep}</td></tr>
      <tr><td>API 密钥</td><td><span class="mono">${esc(JUDGE_INFO.keyMasked)}</span> ${JUDGE_INFO.keyShared ? '<span class="pill n">复用业务密钥</span>' : '<span class="pill g">独立密钥</span>'}</td></tr>
      <tr><td>测试集</td><td><span class="mono">${esc(JUDGE_INFO.dataset)}</span><div class="sub">27 条人工标注样本，覆盖结论准确性、证据可靠性、关键词陷阱、提示注入、阈值边界五个维度</div></td></tr>
    </tbody></table>
    <div class="row" style="margin-top:14px"><form class="inline" method="post" action="/config/sys/test-judge"><button class="p">测试裁判模型连通性</button></form><span class="sub">只发一次极短请求，不涉及任何简历数据</span></div>
    ${last ? `<div class="${last.ok ? 'ok' : 'err'}" style="margin-top:12px">上次裁判自检：<b>${last.ok ? '连通正常' : '失败'}</b> · ${esc(cnTime(last.at))} · ${esc(String(last.ms ?? '-'))} ms${last.model ? ` · 实返模型 ${esc(last.model)}` : ''}${last.reason ? `<br>${esc(last.reason)}` : ''}</div>` : ''}
    <h3 style="margin-top:18px">最近一次评测</h3>
    ${evalHtml}
  </div>`;
}

route('GET', /^\/config\/sys$/, ['sys'], async (req, res, user) => {
  const c = Object.fromEntries(db.prepare("SELECT key,value FROM configs WHERE scope='sys'").all().map((x) => [x.key, x.value]));
  send(res, 200, page(req, user, 'P13 系统参数', '/config/sys', `
    <h1>P13 系统参数配置</h1><div class="sub">唯一归属：系统管理员 · 只放系统口径；"管理员看简历"已改为双人复核</div>
    ${llmCard()}
    ${judgeCard()}
    <div class="card"><form method="post" action="/config/sys">
      <label>候选人联系方式脱敏</label><select name="mask_contact"><option value="true" ${c.mask_contact !== 'false' ? 'selected' : ''}>脱敏</option><option value="false" ${c.mask_contact === 'false' ? 'selected' : ''}>明文（不建议）</option></select>
      <label>留痕保留期限</label><input name="retention" value="${esc(c.retention || '')}">
      <label>数据导出是否需要审批（未实现，仅记录配置）</label><select name="export_approval"><option value="true" ${c.export_approval !== 'false' ? 'selected' : ''}>需要</option><option value="false" ${c.export_approval === 'false' ? 'selected' : ''}>不需要</option></select>
      <label>登录会话有效期（小时）</label><input type="number" name="session_hours" value="${esc(c.session_hours || '8')}" min="1" max="72">
      <div class="row" style="margin-top:12px"><button class="p">保存系统配置</button></div></form></div>
    <div class="note">业务口径（阈值/渠道/去重/审批开关）在 P12，由招聘经理维护。</div>`));
});

route('POST', /^\/config\/sys\/test-llm$/, ['sys'], async (req, res, user) => {
  const r = await pingLLM();
  const rec = { ...r, at: new Date().toISOString() };
  db.prepare("INSERT OR REPLACE INTO configs (key,value,scope,updated_by,updated_at) VALUES ('llm_last_check',?,'sys',?,?)")
    .run(JSON.stringify(rec), user.id, nowIso());
  audit(user, user.role, `大模型连通性自检：${r.ok ? '通过' : '失败'}${r.ok ? `，${r.ms}ms` : `，${String(r.reason || '').slice(0, 120)}`}`, 'config', 'LLM');
  redirect(res, '/config/sys', r.ok ? `连通正常，耗时 ${r.ms} ms，模型 ${r.model || AI_INFO.model}` : null, r.ok ? null : String(r.reason || '自检失败').slice(0, 160));
});

route('POST', /^\/config\/sys\/test-judge$/, ['sys'], async (req, res, user) => {
  const r = await pingJudge();
  const rec = { ...r, at: new Date().toISOString() };
  db.prepare("INSERT OR REPLACE INTO configs (key,value,scope,updated_by,updated_at) VALUES ('judge_last_check',?,'sys',?,?)")
    .run(JSON.stringify(rec), user.id, nowIso());
  audit(user, user.role, `裁判模型连通性自检：${r.ok ? '通过' : '失败'}${r.ok ? `，${r.ms}ms` : `，${String(r.reason || '').slice(0, 120)}`}`, 'config', 'JUDGE');
  redirect(res, '/config/sys', r.ok ? `裁判模型连通正常，耗时 ${r.ms} ms，模型 ${r.model || JUDGE_INFO.model}` : null, r.ok ? null : String(r.reason || '自检失败').slice(0, 160));
});

route('POST', /^\/config\/sys$/, ['sys'], async (req, res, user) => {
  const f = await parseForm(req);
  const set = db.prepare('UPDATE configs SET value=?, updated_by=?, updated_at=? WHERE key=?');
  for (const k of ['mask_contact', 'retention', 'export_approval', 'session_hours']) if (f[k] !== undefined) set.run(String(f[k]), user.id, nowIso(), k);
  audit(user, user.role, `修改系统配置：脱敏 ${f.mask_contact}，会话 ${f.session_hours}h`, 'config', 'SYS');
  redirect(res, '/config/sys', '系统配置已保存');
});

/* ---------- 服务 ---------- */
const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, 'http://x');
    const path = url.pathname;
    if (path === '/') return redirect(res, currentUser(req) ? '/dashboard' : '/login');
    const user = currentUser(req);
    if (!user && path !== '/login' && path !== '/health') return redirect(res, '/login', null, '请先登录');

    for (const r of routes) {
      if (r.method !== req.method) continue;
      const m = r.pattern.exec(path);
      if (!m) continue;
      if (r.roles) requireRole(user, r.roles, path);
      return await r.handler(req, res, user, ...m.slice(1));
    }
    send(res, 404, layout({ user, title: '404', body: '<div class="card"><h1>404</h1><div class="sub">页面不存在</div></div>' }));
  } catch (e) {
    const status = e.status || 500;
    if (status === 401) return redirect(res, '/login');
    if (status === 403) {
      const user = currentUser(req);
      return send(res, 403, layout({ user, title: '403', body: `<div class="card"><h1>403 · 无权限访问</h1>
        <div class="sub">${esc(e.message)}</div><div class="note">职责不重叠：每个业务只有一个归属角色，越权尝试已留痕。</div></div>` }));
    }
    console.error(e);
    send(res, status, layout({ user: null, title: '错误', body: `<div class="card"><h1>出错了</h1><div class="sub">${esc(e.message)}</div></div>` }));
  }
});

server.listen(PORT, () => {
  console.log(`[hire] listening http://127.0.0.1:${PORT}  mode=${APP_MODE} model=${AI_MODEL || '-'} db=sqlite`);
});
