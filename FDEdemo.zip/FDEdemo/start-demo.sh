#!/usr/bin/env bash
# 一键启动（Linux / macOS 终端）：bash start-demo.sh
set -e
cd "$(dirname "$0")"

if ! command -v node >/dev/null 2>&1; then
  echo ""
  echo "  [提示] 没有检测到 Node.js（需要 22.5+）。"
  echo "  安装：https://nodejs.org/  或  brew install node"
  echo "  也可以先看免安装的静态原型：AI辅助招聘平台_原型_v2.0.html"
  echo ""
  (xdg-open "AI辅助招聘平台_原型_v2.0.html" 2>/dev/null || open "AI辅助招聘平台_原型_v2.0.html" 2>/dev/null || true)
  exit 1
fi

exec node start-demo.mjs "$@"
