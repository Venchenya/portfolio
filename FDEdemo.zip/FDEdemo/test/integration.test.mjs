// 集成测试：真实启动服务（独立临时库），覆盖核心链路、权限、异常与持久化
// 运行：node --test test/integration.test.mjs
import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import { DatabaseSync } from 'node:sqlite';
import { rmSync, writeFileSync } from 'node:fs';
import { setTimeout as sleep } from 'node:timers/promises';

const PORT = 3199;
const BASE = `http://127.0.0.1:${PORT}`;
const DB_PATH = 'data/test-integration.db';
let child;
let db;

const PWD = 'Passw0rd!';

function cookieOf(res) {
  const sc = res.headers.get('set-cookie') || '';
  const m = /sid=([^;]+)/.exec(sc);
  return m ? 'sid=' + m[1] : '';
}
async function login(login) {
  const res = await fetch(BASE + '/login', {
    method: 'POST', redirect: 'manual',
    headers: { 'content-type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({ login, password: PWD }),
  });
  assert.equal(res.status, 302);
  return cookieOf(res);
}
async function get(path, cookie) {
  return fetch(BASE + path, { redirect: 'manual', headers: cookie ? { cookie } : {} });
}
async function post(path, cookie, data = {}, raw) {
  if (raw) {
    return fetch(BASE + path, { method: 'POST', redirect: 'manual', headers: { cookie, ...raw.headers }, body: raw.body });
  }
  return fetch(BASE + path, {
    method: 'POST', redirect: 'manual',
    headers: { cookie, 'content-type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams(data),
  });
}
const loc = (res) => res.headers.get('location') || '';

before(async () => {
  try { rmSync(DB_PATH); } catch {}
  child = spawn(process.execPath, ['server/app.mjs'], { env: { ...process.env, PORT: String(PORT), DB_PATH }, stdio: 'pipe' });
  child.stderr.on('data', (d) => process.env.DEBUG && process.stderr.write(d));
  for (let i = 0; i < 60; i++) {
    try { const r = await fetch(BASE + '/health'); if (r.ok) break; } catch {}
    await sleep(150);
  }
  db = new DatabaseSync(DB_PATH);
  await sleep(200);
});
after(() => { child?.kill(); try { db?.close(); } catch {} });

test('健康检查：真实模型已接入', async () => {
  const r = await fetch(BASE + '/health');
  const j = await r.json();
  assert.equal(j.ok, true);
  assert.equal(j.db, 'sqlite');
  assert.ok(['真实模型', '演示引擎', '模拟/未配置'].includes(j.mode));
});

test('登录：错误密码拒绝，正确密码进入总览', async () => {
  const bad = await fetch(BASE + '/login', { method: 'POST', redirect: 'manual', headers: { 'content-type': 'application/x-www-form-urlencoded' }, body: new URLSearchParams({ login: 'wangmin', password: 'wrong' }) });
  assert.ok(loc(bad).includes('err='));
  const c = await login('wangmin');
  const dash = await get('/dashboard', c);
  assert.equal(dash.status, 200);
});

test('权限：跨角色页面 403 且不泄露', async () => {
  const zy = await login('wangmin');
  const r1 = await get('/users', zy);
  assert.equal(r1.status, 403);
  const yr = await login('liqiang');
  const r2 = await get('/board', yr);
  assert.equal(r2.status, 403);
  const jl = await login('zhangwei');
  const r3 = await get('/config/sys', jl);
  assert.equal(r3.status, 403);
});

test('P1：权重≠100 被拒，=100 通过并进入已确认', async () => {
  const yr = await login('liqiang');
  const bad = await post('/jobs', yr, { title: '测试岗位A', duty: '负责测试工作内容描述', must: '条件一|60\n条件二|30', plus: '', action: 'confirm' });
  assert.ok(decodeURIComponent(loc(bad)).includes('err='));
  // 三条必备条件里刻意留一条简历未体现的（团队管理），让"必备未满足→要差距说明"始终可验证，
  // 不依赖模型这次恰好给出什么结论
  const ok = await post('/jobs', yr, { title: '测试岗位A', duty: '负责测试工作内容描述', must: '5 年以上前端研发经验|50\n精通 TypeScript 与 React|30\n3 年以上团队管理经验|20', plus: '', action: 'confirm' });
  assert.ok(!loc(ok).includes('err='));
  const j = db.prepare("SELECT * FROM jobs WHERE title='测试岗位A'").get();
  assert.equal(j.status, 'confirmed');
  assert.equal(db.prepare('SELECT SUM(weight) s FROM job_items WHERE job_id=?').get(j.id).s, 100);
});

test('P2：分配后岗位进入筛选中且专员获得数据权限', async () => {
  const jl = await login('zhangwei');
  const j = db.prepare("SELECT * FROM jobs WHERE title='测试岗位A'").get();
  const zy = db.prepare("SELECT id FROM users WHERE login='wangmin'").get();
  const r = await post(`/assign/${j.id}`, jl, { zy: String(zy.id) });
  assert.equal(r.status, 302);
  const after = db.prepare('SELECT * FROM jobs WHERE id=?').get(j.id);
  assert.equal(after.owner_zy, zy.id);
  assert.equal(after.status, 'screening');
});

test('P3：上传文本 → 真实 AI 分析，结论必须有原文引用或标信息不足', async () => {
  const zy = await login('wangmin');
  const j = db.prepare("SELECT * FROM jobs WHERE title='测试岗位A'").get();
  const resume = '张三\n前端工程师 / 6 年经验\n技术栈：TypeScript、React、Vue\n主导过中大型 Web 项目，负责性能优化\n';
  const r = await post('/upload', zy, { jobId: String(j.id), name: '张三', text: resume });
  assert.equal(r.status, 302);
  assert.ok(loc(r).includes('/check/'));
  const app = db.prepare("SELECT * FROM applications WHERE name='张三'").get();
  const an = db.prepare('SELECT * FROM analyses WHERE app_id=? ORDER BY id DESC').get(app.id);
  assert.ok(an, '应产生分析记录');
  assert.ok(['ok', 'degraded', 'demo'].includes(an.status), '状态必须是 ok / degraded / demo（未接入模型时走演示引擎）');
  const items = db.prepare('SELECT * FROM analysis_items WHERE analysis_id=?').all(an.id);
  assert.ok(items.length >= 2);
  for (const it of items) {
    assert.ok(['匹配', '信息不足', '不符合'].includes(it.conclusion));
    if (it.conclusion !== '信息不足') assert.ok((it.quote || '').length > 0, '非信息不足必须附原文引用');
  }
});

test('P3：PDF 文字层可解析；扫描件（无文字层）被拒', async () => {
  const zy = await login('wangmin');
  const j = db.prepare("SELECT * FROM jobs WHERE title='测试岗位A'").get();
  const pdf = makePdf('Resume of Li Si, 6 years frontend experience with TypeScript and React projects.');
  const fd = new FormData();
  fd.set('jobId', String(j.id));
  fd.set('name', '李四');
  fd.set('file', new Blob([pdf], { type: 'application/pdf' }), 'lisi.pdf');
  const r = await fetch(BASE + '/upload', { method: 'POST', redirect: 'manual', headers: { cookie: zy }, body: fd });
  assert.equal(r.status, 302);
  assert.ok(loc(r).includes('/check/') || decodeURIComponent(loc(r)).includes('未检测到文字层'));

  const emptyPdf = makePdf('');
  const fd2 = new FormData();
  fd2.set('jobId', String(j.id));
  fd2.set('name', '王五');
  fd2.set('file', new Blob([emptyPdf], { type: 'application/pdf' }), 'empty.pdf');
  const r2 = await fetch(BASE + '/upload', { method: 'POST', redirect: 'manual', headers: { cookie: zy }, body: fd2 });
  assert.ok(decodeURIComponent(loc(r2)).includes('未检测到文字层'));
});

test('P4：推荐理由必填；必备未满足需差距说明；成功后触发提醒①', async () => {
  const zy = await login('wangmin');
  const app = db.prepare("SELECT * FROM applications WHERE name='张三'").get();
  const r1 = await post(`/check/${app.id}/recommend`, zy, { reason: '短', gap: '', toVerify: '' });
  assert.ok(decodeURIComponent(loc(r1)).includes('err='));
  const r2 = await post(`/check/${app.id}/recommend`, zy, { reason: '经历与技术栈匹配该岗位要求', gap: '', toVerify: '核实项目角色' });
  const mustFail = db.prepare("SELECT COUNT(*) c FROM analysis_items ai JOIN analyses a ON a.id=ai.analysis_id WHERE a.app_id=? AND ai.type='must' AND ai.conclusion!='匹配'").get(app.id).c > 0;
  if (mustFail) assert.ok(decodeURIComponent(loc(r2)).includes('差距说明'));
  const r3 = await post(`/check/${app.id}/recommend`, zy, { reason: '经历与技术栈匹配该岗位要求', gap: '年限略短，建议面试核实实际能力', toVerify: '核实项目角色' });
  assert.ok(loc(r3).includes('/check'));
  const a2 = db.prepare('SELECT * FROM applications WHERE id=?').get(app.id);
  assert.equal(a2.status, '已推荐');
  assert.equal(db.prepare("SELECT COUNT(*) c FROM reminders WHERE app_id=? AND type='①'").get(app.id).c, 1);
});

test('P4：权重调整必须填理由（≥10 字）；改后分数重算', async () => {
  const zy = await login('wangmin');
  const app = db.prepare("SELECT * FROM applications WHERE name='张三'").get();
  const an = db.prepare('SELECT * FROM analyses WHERE app_id=? ORDER BY id DESC').get(app.id);
  const item = db.prepare('SELECT * FROM analysis_items WHERE analysis_id=? ORDER BY id LIMIT 1').get(an.id);
  const r1 = await post(`/check/${app.id}/weight`, zy, { itemId: String(item.id), weight: String(item.weight + 10), reason: '理由太短' });
  assert.ok(decodeURIComponent(loc(r1)).replace(/\+/g,' ').includes('不少于 10 字'));
  const before = db.prepare('SELECT score FROM analyses WHERE id=?').get(an.id).score;
  const r2 = await post(`/check/${app.id}/weight`, zy, { itemId: String(item.id), weight: String(item.weight + 10), reason: '该条件对岗位更关键，需要提高权重' });
  assert.ok(!loc(r2).includes('err='));
  const after = db.prepare('SELECT score FROM analyses WHERE id=?').get(an.id).score;
  assert.notEqual(before, after);
  assert.equal(db.prepare('SELECT COUNT(*) c FROM weight_changes WHERE app_id=?').get(app.id).c, 1);
});

test('P5：不面试必须填原因；同意面试进入面试中并触发提醒②', async () => {
  const yr = await login('liqiang');
  const app = db.prepare("SELECT * FROM applications WHERE name='张三'").get();
  const r1 = await post(`/applications/${app.id}/feedback`, yr, { result: '不面试', reason: '' });
  assert.ok(decodeURIComponent(loc(r1)).includes('原因'));
  const r2 = await post(`/applications/${app.id}/feedback`, yr, { result: '同意面试', reason: '' });
  assert.ok(loc(r2).includes('/dept'));
  const a = db.prepare('SELECT * FROM applications WHERE id=?').get(app.id);
  assert.equal(a.status, '面试中');
  assert.equal(db.prepare("SELECT COUNT(*) c FROM reminders WHERE app_id=? AND type='②'").get(app.id).c, 1);
  const r3 = await post(`/applications/${app.id}/feedback`, yr, { result: '同意面试', reason: '' });
  assert.equal(db.prepare('SELECT COUNT(*) c FROM feedback WHERE app_id=?').get(app.id).c, 1, '并发/重复反馈只允许一条');
});

test('P6：面试通过→待入职（提醒③），接受 Offer 不算入职，核验后入职', async () => {
  const zy = await login('wangmin');
  const app = db.prepare("SELECT * FROM applications WHERE name='张三'").get();
  await post(`/applications/${app.id}/result`, zy, { result: 'pass' });
  assert.equal(db.prepare('SELECT status FROM applications WHERE id=?').get(app.id).status, '待入职');
  assert.equal(db.prepare("SELECT COUNT(*) c FROM reminders WHERE app_id=? AND type='③'").get(app.id).c, 1);
  await post(`/applications/${app.id}/result`, zy, { result: 'hire' });
  const a = db.prepare('SELECT * FROM applications WHERE id=?').get(app.id);
  assert.equal(a.status, '已入职');
  assert.ok(a.hired_at);
});

test('P8：提醒可处理并留痕；重复触发不重复建', async () => {
  const jl = await login('zhangwei');
  const r = db.prepare("SELECT * FROM reminders WHERE status='open' ORDER BY id LIMIT 1").get();
  if (!r) return;
  await post(`/reminders/${r.id}/handle`, jl, { note: '已与用人部门沟通，安排面试' });
  assert.equal(db.prepare('SELECT status FROM reminders WHERE id=?').get(r.id).status, 'handled');
  assert.ok(db.prepare("SELECT COUNT(*) c FROM audit_logs WHERE action LIKE '处理提醒%'").get().c >= 1);
});

test('删除推荐：审批前数据不变，审批通过后回到已核对', async () => {
  const zy = await login('wangmin');
  const jl = await login('zhangwei');
  const job = db.prepare("SELECT * FROM jobs WHERE title='测试岗位A'").get();
  const resume = '赵六\n前端工程师 / 7 年经验\n技术栈：TypeScript、React\n主导过大型项目\n';
  await post('/upload', zy, { jobId: String(job.id), name: '赵六', text: resume });
  const app = db.prepare("SELECT * FROM applications WHERE name='赵六'").get();
  await post(`/check/${app.id}/recommend`, zy, { reason: '技术栈与项目经历匹配岗位要求', gap: '年限与必备条件存在差距，建议面试核实', toVerify: '无' });
  const rec = db.prepare('SELECT * FROM recommendations WHERE app_id=? ORDER BY id DESC').get(app.id);
  await post(`/check/${app.id}/delete-request`, zy, { reason: '推荐对象选错需要更正' });
  assert.equal(db.prepare('SELECT status FROM recommendations WHERE id=?').get(rec.id).status, 'delete_pending');
  assert.equal(db.prepare('SELECT status FROM applications WHERE id=?').get(app.id).status, '已推荐');
  await post(`/recommendations/${rec.id}/decide`, jl, { decision: 'approve' });
  assert.equal(db.prepare('SELECT status FROM recommendations WHERE id=?').get(rec.id).status, 'deleted');
  assert.equal(db.prepare('SELECT status FROM applications WHERE id=?').get(app.id).status, '已核对');
});

test('P10：账号保护规则（不可停用自己、不可删最后管理员）', async () => {
  const sys = await login('admin');
  const me = db.prepare("SELECT * FROM users WHERE login='admin'").get();
  const r1 = await post(`/users/${me.id}/toggle`, sys, {});
  assert.ok(decodeURIComponent(loc(r1)).replace(/\+/g,' ').includes('不可停用'));
  const r2 = await post('/users', sys, { name: '测试专员', login: 'tester1', role: 'zy', dept: '人力资源部' });
  assert.ok(loc(r2).includes('/users'));
  assert.ok(db.prepare("SELECT id FROM users WHERE login='tester1'").get());
});

test('P13/P12：配置分离且即时生效', async () => {
  const jl = await login('zhangwei');
  await post('/config/biz', jl, { sla_hours: '12', auto_timeout: 'false', channel: '站内信+每日邮件', dedupe: 'true', delete_requires_approval: 'true' });
  assert.equal(db.prepare("SELECT value FROM configs WHERE key='sla_hours'").get().value, '12');
  const sys = await login('admin');
  await post('/config/sys', sys, { mask_contact: 'true', retention: '1 年', export_approval: 'true', session_hours: '12' });
  assert.equal(db.prepare("SELECT value FROM configs WHERE key='session_hours'").get().value, '12');
});

test('持久化：重新登录后数据仍在（无本地缓存的单点验证）', async () => {
  const zy = await login('wangmin');
  const r = await get('/check?', zy);
  assert.equal(r.status, 200);
  const html = await r.text();
  assert.ok(html.includes('张三') || html.includes('赵六'));
});

/* 生成含文字层的最小 PDF（不压缩，便于解析器直接读取） */
function makePdf(text) {
  const content = text ? `BT /F1 12 Tf 72 720 Td (${text.replace(/[()\\]/g, '\\$&')}) Tj ET` : '';
  const objs = [
    '<< /Type /Catalog /Pages 2 0 R >>',
    '<< /Type /Pages /Kids [3 0 R] /Count 1 >>',
    '<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Contents 4 0 R /Resources << /Font << /F1 5 0 R >> >> >>',
    `<< /Length ${content.length} >>\nstream\n${content}\nendstream`,
    '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>',
  ];
  let pdf = '%PDF-1.4\n';
  const offsets = [0];
  objs.forEach((o, i) => {
    offsets.push(pdf.length);
    pdf += `${i + 1} 0 obj\n${o}\nendobj\n`;
  });
  const xref = pdf.length;
  pdf += `xref\n0 ${objs.length + 1}\n0000000000 65535 f \n`;
  for (let i = 1; i <= objs.length; i++) pdf += String(offsets[i]).padStart(10, '0') + ' 00000 n \n';
  pdf += `trailer\n<< /Size ${objs.length + 1} /Root 1 0 R >>\nstartxref\n${xref}\n%%EOF\n`;
  return Buffer.from(pdf, 'latin1');
}
