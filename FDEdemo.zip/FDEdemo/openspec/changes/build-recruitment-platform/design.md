# Design

## 1. 基线材料与判断

| 材料 | 版本/时间 | 用途 | 可信度 |
| --- | --- | --- | --- |
| `第五组-产品需求文档_PRD_v2.0.docx / .md` | v2.0，2026-10-24 | 功能、规则、权限、验收口径的**唯一业务依据** | 高（经客户评审的分级与四角色） |
| `业务需求文档_总册_v2.0.docx / .md` | v2.0，2026-10-24 | 需求溯源、风险、待确认项 | 高 |
| `AI辅助招聘平台_原型_v2.0.html` | v2.0，16:25 | **交互与字段参照**，非实现基线 | 中（前端 demo，数据在 localStorage） |
| `openspec/config.yaml` | 1.15.0 / spec-driven / zh-CN | 工作流与产物语言 | 高 |

判断：PRD 是"要什么"，原型是"长什么样"，两者冲突时**以 PRD 为准**。

**本轮已对 C1~C10 作出决策**（见 `notes/ADR-001-决策记录.md`），本文以下章节按决策后的确定口径书写；文中标注"待确认"的仅剩 3 项非阻塞事项。

## 2. 关键设计选择

### 2.1 架构：Node.js 单体 + PostgreSQL + 对象存储（已定，ADR-001 C4）

| 层 | 选定技术 | 理由 |
| --- | --- | --- |
| 前端 | React + TypeScript + Vite（原型可直接迁移组件） | 与后端同语言、生态成熟 |
| 后端 | Node.js 20 LTS + TypeScript + **NestJS** | 模块化 + 守卫/拦截器天然适配 RBAC 与审计 |
| ORM/迁移 | Prisma | schema 即文档、迁移可审阅 |
| 数据库 | PostgreSQL 16 | 事务、唯一约束、JSONB 存证据快照 |
| 文件 | S3 兼容对象存储（本地 MinIO） | 简历原件与解析文本分离，便于按权限授权 |
| 队列/定时 | Redis + BullMQ（或 Nest 定时任务） | 提醒去重、邮件汇总、AI 重试 |
| 部署 | 单体内网部署（Docker Compose） | 0-1 阶段不上微服务 |

**放弃的方案**：继续单文件 HTML（无多用户/审计不可信）、微服务（团队规模不匹配）。

### 2.2 数据模型（核心表）

| 表 | 关键字段 | 说明 |
| --- | --- | --- |
| `user` | id, name, login(unique), role, dept, status, pwd_changed_at | 角色枚举：yr/zy/jl/sys |
| `job_requirement` | id, title, dept, duty, status, owner_yr, owner_zy, version, created_at | status：草稿/已确认/筛选中/已结束 |
| `requirement_item` | id, jr_id, type(must/plus), content, weight | 权重为整数，P1 校验合计=100 |
| `candidate` | id, name, contact_enc | 联系方式加密存储 |
| `resume_version` | id, candidate_id, jr_id, version_no, file_key, text_snapshot, uploaded_by, uploaded_at | 版本不覆盖；文本快照用于回看与重析 |
| `analysis` | id, rv_id, score, model, status(success/failed/degraded), created_at | 参考分仅参考 |
| `analysis_item` | id, analysis_id, cond, type, conclusion, quote, to_verify, weight, source(ai/human_added), edited | quote 非空约束 |
| `application` | id, jr_id, candidate_id, stage, status, owner_zy, entered_at, version(乐观锁) | 一岗位一候选人唯一 |
| `recommendation` | id, app_id, reason, gap, to_verify, submitted_at, deleted_at, deleted_reason | 删除为软删 + 留痕 |
| `dept_feedback` | id, app_id(unique), result, reject_reason, created_at | 唯一约束防重复反馈 |
| `status_log` | id, app_id, from_stage, to_stage, operator, created_at | 轨迹 |
| `reminder` | id, type, job_id, app_id, status, dedupe_key(unique), triggered_at, handled_at, handle_note | dedupe_key = job+app+type+open |
| `audit_log` | id, at, actor, role, action, obj_type, obj_id, meta(json) | 仅插入，无 update/delete 权限 |
| `config` | key, value, scope(biz/sys), updated_by, updated_at | biz 仅经理，sys 仅管理员 |

### 2.3 AI 证据契约（防"无依据输出"）

- **合规**：送模型前做 PII 脱敏（姓名/电话/邮箱/公司名→占位符），原文不落第三方日志；模型与 prompt 版本随分析结果入库，便于归因（ADR-001 C6）。
- 模型输出强制 JSON：`{items:[{cond_id, conclusion, quote, to_verify}], score_hint}`；`quote` 必须能在简历文本中定位（子串匹配，允许去空白）。
- 服务端校验：`quote` 为空或定位失败 → 该条丢弃，记 `analysis.status=degraded` 并提示人工核对；**不落库**。
- 结论枚举仅三值；超过枚举或出现"不具备"等措辞 → 归一化为"信息不足"。
- 超时 30s、重试 1 次；仍失败 → 人工对照模式（空白结论表单），参考分显示"—"。
- 参考分由服务端按权重计算，不采用模型自评分，避免"模型既当裁判又当选手"。

### 2.4 权重与加分项的边界

- P1 提交：合计必须 = 100（硬校验）。
- P4 调整：允许改动后 ≠100，按实际合计归一化，界面提示但不阻断（与原型一致）。
- 决策（C2）：P1 强校验 =100；P4 允许临时偏离但**必须填理由（≥10 字）**，且默认不回写岗位（勾选同步才回写并升版本）；`weight_strict_on_check` 保留为配置项（默认 false），用于个别企业要求"核对时也=100"的场景。

### 2.5 权限实现

- 路由级：页面 → 唯一角色白名单（与 PRD 12.2 一致），非白名单直接 403。
- 接口级：`requireRole` + `requireScope`（job.owner_zy / job.owner_yr / all / sys）。
- 数据级：所有查询强制拼接 scope 条件，禁止"查全表再过滤"。
- 管理员：默认 `sys` 无候选人读权限，**无自助开关**；排障走双人复核（申请人=管理员，审批人=HR/合规负责人），授权 30 分钟、只读、水印、逐次审计（C7）。
- 越权：统一 403 + `audit_log(action=cross_role_denied)`，响应体不含对象是否存在的信息。

### 2.6 状态机

`application.status`：待核对 → 已核对 → 已推荐 → 等部门反馈 → 面试中 → 待入职 → 已入职；旁路：已终止。
`job_requirement.status`：草稿 → 已确认 → 筛选中 → 已结束。
`reminder.status`：未处理 → 已处理 / 已忽略。
所有流转写 `status_log`，非法流转（如 已终止 → 面试中）一律拒绝并记异常。

### 2.7 提醒引擎

- 事件驱动：推荐提交 / 部门同意 / 面试通过三个事件直接生成提醒。
- 去重：`dedupe_key` 唯一索引，避免并发重复。
- 超时兜底：定时任务（5 分钟）扫描超阈值且无未处理提醒的记录，`config.auto_timeout=true` 时生成；默认关闭。
- 渠道：一期站内信 + 每日 09:00 邮件汇总（仅招聘经理；收件范围可配）；IM（企业微信/飞书）二期，需白名单与审批（C5）。
- 闭环：处理需写 `handle_note`；忽略也留痕；处理率 = 已处理 / 全部已触发。

### 2.8 配置分组

| 组 | 键 | 维护角色 | 生效方式 |
| --- | --- | --- | --- |
| 业务 | sla_hours, auto_timeout, channel, dedupe, split_reminders, weight_strict_on_check, email_digest(on/off/收件范围), delete_requires_approval | 招聘经理 | 即时（读缓存失效） |
| 系统 | mask_contact, retention, export_approval, session_hours, model_version, prompt_version | 系统管理员 | 即时；导出审批需二次校验 |

> 移除 `admin_view_resume` 开关（C7：改为双人复核审批流）。

## 3. 测试与验收策略

- 场景即用例：spec 中每个 `#### Scenario` 直接转成一条自动化用例（GIVEN 构造数据、WHEN 调接口、THEN 断言状态与留痕）。
- 分层：单元（参考分、去重键、脱敏、状态机）、集成（接口 + 权限矩阵）、端到端（一个岗位完整走一遍，即 PRD 4.2 验收口径）。
- 必测异常：越权 403、并发反馈、重复上传、刷新后数据不丢、AI 超时降级、删除推荐后提醒关闭。
- 验收证据：每个场景对应测试报告条目；未覆盖项必须在报告中列明（不得写"正常运行"）。
- 指标口径（C9）：主口径为自然时长（小时）；冗余记录工作时长（工作日 9:00–18:00）；均值样本 <5 时显示"—（样本不足）"并给中位数；口径脚注随报表导出。

## 4. 假设与未验证项

| 编号 | 假设 | 验证方式 | 责任方 |
| --- | --- | --- | --- |
| ~~A1~~ | **已定**：Node 20 + TypeScript + NestJS + PostgreSQL 16 + Prisma + MinIO + Redis，内网 Docker 部署 | — | ADR-001 C4 |
| ~~A2~~ | **已定**：文本型 PDF 解析后存文本快照，扫描件一期不支持；原件存对象存储 | — | ADR-001 C1 |
| ~~A3~~ | **已定**：合规网关/内网模型，PII 脱敏后送模型，超时 30s、重试 1 次 | — | ADR-001 C6 |
| ~~A4~~ | **已定**：一期站内信 + 每日邮件汇总；IM 二期 | — | ADR-001 C5 |
| A5 | 本规格仍未验证：真实 PDF 解析准确率、并发压测、浏览器兼容、移动端 | 实施阶段补测 | 研发/测试 |

## 5. 材料 → 规格 → 任务映射

| PRD | 原型 | 能力规格 | 任务组 |
| --- | --- | --- | --- |
| S1（10.2.1）/ P1、P2 | P1、P2 | `job-requirement` | T1 |
| S2、S3（10.2.2、10.2.3）/ P3、P4 | P3、P4 | `resume-screening` | T2、T3 |
| S4（10.2.4）/ P5 | P5 | `department-feedback` | T4 |
| S5（10.2.5）/ P6 | P6 | `progress-tracking` | T5 |
| S6（10.2.6）/ P7、P8 | P7、P8 | `process-visibility` | T6 |
| S6、S7 / P9 | P9 | `audit-and-metrics` | T7 |
| 12 章 / 权限 | 导航与 403 | `access-control` | T0、T8 |
| 10.2.8 / P10~P13 | P10~P13 | `system-administration` | T8 |
