#!/bin/bash
# 一键启动（macOS 双击）：不需要 npm install，没有 API Key 也能跑
cd "$(dirname "$0")" || exit 1

if ! command -v node >/dev/null 2>&1; then
  echo ""
  echo "  [提示] 没有检测到 Node.js，无法启动完整应用。"
  echo ""
  echo "  1) 安装 Node.js 22+（https://nodejs.org/ 选 LTS），再双击本文件即可体验完整流程（无需 API Key）"
  echo "  2) 现在先看免安装的交互原型（单文件网页）"
  echo ""
  open "AI辅助招聘平台_原型_v2.0.html" 2>/dev/null
  read -n 1 -s -r -p "  按任意键关闭…"
  exit 0
fi

node start-demo.mjs "$@"
status=$?

echo ""
if [ $status -ne 0 ]; then
  echo "  启动异常（退出码 $status），请把上面的错误信息截图反馈。"
fi
read -n 1 -s -r -p "  按任意键关闭…"
exit $status
